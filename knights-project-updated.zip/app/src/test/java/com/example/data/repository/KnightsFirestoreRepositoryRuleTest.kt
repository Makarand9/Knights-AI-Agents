package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.AgentTaskRecordDoc
import com.example.data.model.CustomAgentConfigDoc
import com.example.data.model.UserMemoryItemDoc
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.UUID

class KnightsFirestoreRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun saveAgentConfig_and_getAgentConfig_succeedForOwner_and_failForCrossUser() = runBlocking {
        val aliceUid = signInTestUser("alice@test.com")
        val repository = KnightsFirestoreRepository(firestore)
        val agentDocId = "aegis_${UUID.randomUUID()}"

        val config = CustomAgentConfigDoc(
            userId = aliceUid,
            agentId = agentDocId,
            codename = "Knight I • Vanguard Scout",
            squadron = "youtube",
            description = "Multi-Domain Coordinator & Trend Intelligence",
            instruction = "Coordinate all 9 agents seamlessly across any domain.",
            internetEnabled = true,
            localModelId = "gemma-3-nano-4b-q4",
            capabilities = "Web Search, Code Synthesis, Task Delegation",
            lastTaskSummary = "Initial verification"
        )

        withTimeout(5000L) {
            repository.saveAgentConfig(aliceUid, agentDocId, config)
        }

        val fetched = withTimeout(5000L) {
            repository.getAgentConfig(aliceUid, agentDocId)
        }
        assertNotNull(fetched)
        assertEquals("Knight I • Vanguard Scout", fetched?.codename)
        assertEquals("gemma-3-nano-4b-q4", fetched?.localModelId)

        // Sign in as Bob and verify cross-user write is rejected with PERMISSION_DENIED
        val bobUid = signInTestUser("bob@test.com")
        var denied = false
        try {
            withTimeout(5000L) {
                repository.saveAgentConfig(aliceUid, agentDocId, config.copy(userId = bobUid, codename = "Hacked"))
            }
        } catch (e: Exception) {
            denied = true
            assertTrue(e.message?.contains("PERMISSION_DENIED") == true)
        }
        assertTrue("Expected PERMISSION_DENIED when Bob writes to Alice's agent collection", denied)
    }

    @Test
    fun saveMemory_saveTaskRecord_and_unauthenticatedRejection() = runBlocking {
        val aliceUid = signInTestUser("alice@test.com")
        val repository = KnightsFirestoreRepository(firestore)
        val memId = "mem_${UUID.randomUUID()}"
        val taskId = "task_${UUID.randomUUID()}"

        val memory = UserMemoryItemDoc(
            userId = aliceUid,
            content = "Use dark black Gemini theme and enable live web grounding.",
            category = "Preference",
            enabled = true
        )
        withTimeout(5000L) {
            repository.saveMemory(aliceUid, memId, memory)
        }

        val task = AgentTaskRecordDoc(
            userId = aliceUid,
            agentId = "sentinel_critic_knight",
            agentCodename = "Knight IX • Sentinel Auditor",
            prompt = "Audit the authentication flow and verify zero-trust rules",
            status = "completed",
            output = "Completed full security audit with live CVE grounding.",
            usedInternet = true,
            executionEngine = "gemma-3-nano-4b-q4"
        )
        withTimeout(5000L) {
            repository.saveTaskRecord(aliceUid, taskId, task)
        }

        // Unauthenticated negative test
        auth.signOut()
        var unauthDenied = false
        try {
            withTimeout(3000L) {
                repository.observeMemories(aliceUid).first()
            }
        } catch (e: Exception) {
            unauthDenied = true
        }
        assertTrue("Expected unauthenticated listener to fail", unauthDenied)
    }
}
