package com.example

import com.example.data.model.DefaultKnightsOrder
import com.example.data.model.SquadronType
import com.example.data.model.YouTubeFunnelParams
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testAll9KnightsRegistered() {
        val knights = DefaultKnightsOrder.ALL_9_KNIGHTS
        assertEquals(9, knights.size)

        val youtubeKnights = knights.filter { it.isYouTube }
        val universalKnights = knights.filter { it.isUniversal }

        assertEquals(5, youtubeKnights.size)
        assertEquals(4, universalKnights.size)
    }

    @Test
    fun testYouTubeFunnelMath() {
        val params = YouTubeFunnelParams(
            views = 100_000L,
            rpmUsd = 10.0,
            ctrPercent = 5.0,
            avgViewDurationMins = 6.0
        )

        // Revenue: (100,000 / 1000) * 10 = $1,000.00
        assertEquals(1000.0, params.estimatedAdRevenueUsd, 0.01)

        // Watch Time: (100,000 * 6.0) / 60 = 10,000 hours
        assertEquals(10000.0, params.projectedWatchTimeHours, 0.01)
        assertTrue(params.isMonetizationEligible)

        // Impressions: 100,000 / 0.05 = 2,000,000
        assertEquals(2_000_000L, params.requiredImpressions)
    }

    @Test
    fun testSquadronsConfiguration() {
        val ytSquadron = SquadronType.YOUTUBE_PIPELINE
        assertEquals(4, ytSquadron.stages.size)

        val universalSquadron = SquadronType.UNIVERSAL_PIPELINE
        assertEquals(3, universalSquadron.stages.size)

        val grandOrder = SquadronType.GRAND_ORDER
        assertEquals(4, grandOrder.stages.size)
    }
}
