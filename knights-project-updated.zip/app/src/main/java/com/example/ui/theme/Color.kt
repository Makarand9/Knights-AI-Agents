package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Knights UI Design Tokens (Prompts A–E Specification)
// Background: pure black #000000 with soft bottom glow on Home screen:
// Chat mode navy (#0B1A5C), Task mode violet-indigo (#3A2F9E)
val KnightsPureBlack = Color(0xFF000000)
val KnightsChatGlowNavy = Color(0xFF0B1A5C)
val KnightsTaskGlowViolet = Color(0xFF3A2F9E)

// Cards and pills: #1E1E1E, fully rounded or 28.dp corners. List icon circles: #1C1C1C.
val KnightsCardPill = Color(0xFF1E1E1E)
val KnightsIconCircle = Color(0xFF1C1C1C)
val KnightsInputPill = Color(0xFF1F1F1F)
val KnightsChatSendIndigo = Color(0xFF1F2E85)
val KnightsTaskSendViolet = Color(0xFF3A2A9C)
val KnightsSecondaryGray = Color(0xFF9AA0A6)

// Harmonized Tokens across all screens
val GeminiDarkBg = Color(0xFF000000)          // Pure black #000000 canvas
val GeminiSurface = Color(0xFF1E1E1E)         // Cards & pills #1E1E1E
val GeminiSurfaceHigh = Color(0xFF1F1F1F)     // Input bar & elevated pills #1F1F1F
val GeminiSurfaceBright = Color(0xFF28282B)   // Selected / active pill state
val GeminiBorder = Color(0xFF2A2B2E)          // Subtle hairline border

// Knights Brand Gradient & Accents (Blue -> Violet -> Pink)
val GeminiBlue = Color(0xFF8AB4F8)
val GeminiLightBlue = Color(0xFFA8C7FA)
val GeminiPurple = Color(0xFFC58AF9)
val GeminiRose = Color(0xFFF28B82)
val GeminiSparkle = Color(0xFFD3E3FD)

// Backward-compatible aliases
val KnightDeepBg = Color(0xFF000000)
val KnightSurface = Color(0xFF1E1E1E)
val KnightSurfaceCard = Color(0xFF1E1E1E)
val KnightSurfaceElevated = Color(0xFF1F1F1F)
val KnightBorderGlow = Color(0xFF2A2B2E)

val KnightIndigo = Color(0xFF8AB4F8)
val KnightViolet = Color(0xFFC58AF9)
val KnightCyan = Color(0xFFA8C7FA)
val KnightRose = Color(0xFFF28B82)
val KnightEmerald = Color(0xFF81C995)
val KnightAmber = Color(0xFFFDD663)
val KnightRed = Color(0xFFF28B82)

// Terminal specific colors
val TerminalBg = Color(0xFF070708)
val TerminalText = Color(0xFFE3E3E3)
val TerminalPrompt = Color(0xFFA8C7FA)
val TerminalCyan = Color(0xFFA8C7FA)
val TerminalGreen = Color(0xFF81C995)
val TerminalYellow = Color(0xFFFDD663)
val TerminalPurple = Color(0xFFC58AF9)
val TerminalMuted = Color(0xFF9AA0A6)

// Material 3 Pure Black Mappings
val PrimaryDark = Color(0xFFA8C7FA)
val OnPrimaryDark = Color(0xFF062E6F)
val PrimaryContainerDark = Color(0xFF1F2E85)
val OnPrimaryContainerDark = Color(0xFFD3E3FD)

val SecondaryDark = Color(0xFFC58AF9)
val OnSecondaryDark = Color(0xFF2A1442)
val SecondaryContainerDark = Color(0xFF3A2A9C)
val OnSecondaryContainerDark = Color(0xFFEADDFF)

val TertiaryDark = Color(0xFF81C995)
val OnTertiaryDark = Color(0xFF0D381E)
val TertiaryContainerDark = Color(0xFF14291D)
val OnTertiaryContainerDark = Color(0xFFD1FAE5)

val BackgroundDark = Color(0xFF000000)
val OnBackgroundDark = Color(0xFFFFFFFF)
val SurfaceDark = Color(0xFF1E1E1E)
val OnSurfaceDark = Color(0xFFFFFFFF)
val SurfaceVariantDark = Color(0xFF1C1C1C)
val OnSurfaceVariantDark = Color(0xFF9AA0A6)
