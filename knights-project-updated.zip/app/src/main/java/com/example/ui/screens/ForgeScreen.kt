package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.AutoFixHigh
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.ContentPaste
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.SmartDisplay
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ConnectorItem
import com.example.data.model.DEFAULT_CONNECTORS
import com.example.data.model.DEFAULT_INSTALLED_SKILLS
import com.example.data.model.DEFAULT_LOCAL_AI_MODELS
import com.example.data.model.DEFAULT_SKILL_PACKS
import com.example.data.model.InstalledSkillItem
import com.example.data.model.LocalAiModel
import com.example.data.model.SkillPackItem
import com.example.ui.theme.GeminiBorder
import com.example.ui.theme.GeminiLightBlue
import com.example.ui.theme.GeminiPurple
import com.example.ui.theme.KnightEmerald
import com.example.ui.theme.KnightsCardPill
import com.example.ui.theme.KnightsChatSendIndigo
import com.example.ui.theme.KnightsIconCircle
import com.example.ui.theme.KnightsPureBlack
import com.example.ui.theme.KnightsSecondaryGray

/**
 * Prompt C: Customize screen (skills, APIs, packs) + On-Device Local AI Hub.
 * - Three chip tabs at the top: Discover (selected pill), Connectors, Skills.
 * - Title "Customize your chats" in 34.sp with a gray subtitle.
 * - Discover: sections "Everyday tools" and "Business essentials", each a list of rows
 *   (52.dp dark circle icon #1C1C1C, 20.sp title, one-line gray description with ellipsis, "+" on the right)
 *   for skill packs such as YouTube Studio, Research, Writing style, Meeting prep.
 * - Connectors: import an API by OpenAPI URL or add an MCP server URL.
 * - Skills: list installed skills with enable switches; buttons "Import from GitHub URL",
 *   "Paste SKILL.md", and "Create with prompt" (the Skill Smith agent drafts a SKILL.md,
 *   shows a preview, and saves only after the user approves).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ForgeScreen(
    blueprintJson: String,
    localAiModels: List<LocalAiModel> = DEFAULT_LOCAL_AI_MODELS,
    selectedSubTab: String = "Discover",
    skillPacks: List<SkillPackItem> = DEFAULT_SKILL_PACKS,
    installedSkills: List<InstalledSkillItem> = DEFAULT_INSTALLED_SKILLS,
    connectors: List<ConnectorItem> = DEFAULT_CONNECTORS,
    skillDraftName: String? = null,
    skillDraftMarkdown: String? = null,
    onSubTabSelected: (String) -> Unit = {},
    onToggleSkillPack: (String) -> Unit = {},
    onAddConnector: (name: String, type: String, url: String) -> Unit = { _, _, _ -> },
    onRemoveConnector: (String) -> Unit = {},
    onToggleInstalledSkill: (String) -> Unit = {},
    onImportSkillFromGithub: (String) -> Unit = {},
    onPasteSkillMarkdown: (name: String, markdown: String) -> Unit = { _, _ -> },
    onDraftSkillWithPrompt: (String) -> Unit = {},
    onApproveSkillDraft: () -> Unit = {},
    onDiscardSkillDraft: () -> Unit = {},
    onInstallLocalModel: (String) -> Unit = {},
    onUninstallLocalModel: (String) -> Unit = {},
    onBindLocalModelToAll: (String) -> Unit = {},
    onForgeCustomKnight: (id: String, codename: String, description: String, prompt: String) -> Unit,
    onSaveBlueprint: (String) -> Unit,
    onResetBlueprint: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val tabs = listOf("Discover", "Connectors", "Skills")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(KnightsPureBlack)
            .verticalScroll(scrollState)
            .padding(horizontal = 8.dp, vertical = 8.dp)
    ) {
        // Three chip tabs at the top: Discover (selected pill), Connectors, Skills
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            tabs.forEach { tab ->
                val isSelected = selectedSubTab == tab
                Box(
                    modifier = Modifier
                        .defaultMinSize(minHeight = 42.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(if (isSelected) KnightsCardPill else Color.Transparent)
                        .border(
                            width = 1.dp,
                            color = if (isSelected) Color.Transparent else GeminiBorder,
                            shape = RoundedCornerShape(24.dp)
                        )
                        .clickable { onSubTabSelected(tab) }
                        .testTag("customize_tab_${tab.lowercase()}")
                        .padding(horizontal = 20.dp, vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tab,
                        fontSize = 14.5.sp,
                        fontWeight = if (isSelected) FontWeight.Medium else FontWeight.Light,
                        color = if (isSelected) Color.White else KnightsSecondaryGray
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(22.dp))

        // Title "Customize your chats" in 34.sp with a gray subtitle
        Text(
            text = "Customize your chats",
            fontSize = 34.sp,
            lineHeight = 40.sp,
            fontWeight = FontWeight.Light,
            color = Color.White,
            modifier = Modifier.testTag("customize_screen_title")
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Equip your 9 Knights with skill packs, OpenAPI & MCP connectors, custom SKILL.md modules, and on-device Local AI.",
            fontSize = 14.5.sp,
            color = KnightsSecondaryGray,
            lineHeight = 20.sp
        )

        Spacer(modifier = Modifier.height(24.dp))

        when (selectedSubTab) {
            "Discover" -> {
                DiscoverTabContent(
                    skillPacks = skillPacks,
                    localAiModels = localAiModels,
                    onToggleSkillPack = onToggleSkillPack,
                    onInstallLocalModel = onInstallLocalModel,
                    onUninstallLocalModel = onUninstallLocalModel,
                    onBindLocalModelToAll = onBindLocalModelToAll
                )
            }

            "Connectors" -> {
                ConnectorsTabContent(
                    connectors = connectors,
                    onAddConnector = onAddConnector,
                    onRemoveConnector = onRemoveConnector
                )
            }

            "Skills" -> {
                SkillsTabContent(
                    installedSkills = installedSkills,
                    skillDraftName = skillDraftName,
                    skillDraftMarkdown = skillDraftMarkdown,
                    blueprintJson = blueprintJson,
                    onToggleInstalledSkill = onToggleInstalledSkill,
                    onImportSkillFromGithub = onImportSkillFromGithub,
                    onPasteSkillMarkdown = onPasteSkillMarkdown,
                    onDraftSkillWithPrompt = onDraftSkillWithPrompt,
                    onApproveSkillDraft = onApproveSkillDraft,
                    onDiscardSkillDraft = onDiscardSkillDraft,
                    onForgeCustomKnight = onForgeCustomKnight,
                    onSaveBlueprint = onSaveBlueprint,
                    onResetBlueprint = onResetBlueprint
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))
    }
}

@Composable
private fun DiscoverTabContent(
    skillPacks: List<SkillPackItem>,
    localAiModels: List<LocalAiModel>,
    onToggleSkillPack: (String) -> Unit,
    onInstallLocalModel: (String) -> Unit,
    onUninstallLocalModel: (String) -> Unit,
    onBindLocalModelToAll: (String) -> Unit
) {
    val everydayTools = skillPacks.filter { it.section == "Everyday tools" }
    val businessEssentials = skillPacks.filter { it.section == "Business essentials" }

    Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
        // Section 1: "Everyday tools"
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                text = "Everyday tools",
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = KnightsSecondaryGray
            )
            everydayTools.forEach { pack ->
                SkillPackRow(
                    pack = pack,
                    onToggle = { onToggleSkillPack(pack.id) }
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Section 2: "Business essentials"
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                text = "Business essentials",
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = KnightsSecondaryGray
            )
            businessEssentials.forEach { pack ->
                SkillPackRow(
                    pack = pack,
                    onToggle = { onToggleSkillPack(pack.id) }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        HorizontalDivider(color = GeminiBorder)
        Spacer(modifier = Modifier.height(4.dp))

        // Section 3: On-Device Local AI Engine Hub
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Outlined.Memory,
                    contentDescription = null,
                    tint = GeminiPurple,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "On-Device Local AI Models",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Normal,
                    color = Color.White
                )
            }
            Text(
                text = "Install local neural models inside Knights and bind them to any of the 9 agents for offline or hybrid execution.",
                fontSize = 13.sp,
                color = KnightsSecondaryGray
            )

            localAiModels.forEach { model ->
                LocalAiModelCard(
                    model = model,
                    onInstall = { onInstallLocalModel(model.id) },
                    onUninstall = { onUninstallLocalModel(model.id) },
                    onBindToAll = { onBindLocalModelToAll(model.id) }
                )
            }
        }
    }
}

@Composable
private fun SkillPackRow(
    pack: SkillPackItem,
    onToggle: () -> Unit
) {
    val icon = when (pack.iconKey) {
        "video" -> Icons.Outlined.SmartDisplay
        "search" -> Icons.Outlined.Search
        "edit" -> Icons.Outlined.EditNote
        "calendar" -> Icons.Outlined.CalendarMonth
        "code" -> Icons.Outlined.Code
        else -> Icons.Outlined.Analytics
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 68.dp)
            .clip(RoundedCornerShape(28.dp))
            .clickable { onToggle() }
            .testTag("skill_pack_row_${pack.id}")
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // 52.dp dark circle icon (#1C1C1C)
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(KnightsIconCircle),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = pack.title,
                tint = Color.White,
                modifier = Modifier.size(24.dp)
            )
        }

        Spacer(modifier = Modifier.width(16.dp))

        // 20.sp title, one-line gray description with ellipsis
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = pack.title,
                fontSize = 20.sp,
                fontWeight = FontWeight.Normal,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = pack.description,
                fontSize = 14.sp,
                color = KnightsSecondaryGray,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        // "+" on the right (or checkmark when added)
        IconButton(
            onClick = onToggle,
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(if (pack.isAdded) KnightsCardPill else Color.Transparent)
        ) {
            Icon(
                imageVector = if (pack.isAdded) Icons.Outlined.Check else Icons.Outlined.Add,
                contentDescription = if (pack.isAdded) "Added" else "Add ${pack.title}",
                tint = if (pack.isAdded) KnightEmerald else Color.White,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@Composable
private fun ConnectorsTabContent(
    connectors: List<ConnectorItem>,
    onAddConnector: (name: String, type: String, url: String) -> Unit,
    onRemoveConnector: (String) -> Unit
) {
    var connectorName by remember { mutableStateOf("") }
    var openApiUrl by remember { mutableStateOf("") }
    var mcpServerUrl by remember { mutableStateOf("") }

    Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
        // Import an API by OpenAPI URL
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(KnightsCardPill)
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Link, contentDescription = null, tint = GeminiLightBlue, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Import API by OpenAPI URL",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Normal,
                    color = Color.White
                )
            }
            OutlinedTextField(
                value = connectorName,
                onValueChange = { connectorName = it },
                placeholder = { Text("Connector name (optional)", color = KnightsSecondaryGray, fontSize = 13.5.sp) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GeminiLightBlue,
                    unfocusedBorderColor = GeminiBorder,
                    focusedContainerColor = KnightsPureBlack,
                    unfocusedContainerColor = KnightsPureBlack,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = openApiUrl,
                onValueChange = { openApiUrl = it },
                placeholder = { Text("https://api.example.com/openapi.json", color = KnightsSecondaryGray, fontSize = 13.5.sp) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GeminiLightBlue,
                    unfocusedBorderColor = GeminiBorder,
                    focusedContainerColor = KnightsPureBlack,
                    unfocusedContainerColor = KnightsPureBlack,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("openapi_url_input")
            )
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 48.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(KnightsChatSendIndigo)
                    .clickable {
                        onAddConnector(connectorName, "OpenAPI", openApiUrl)
                        connectorName = ""
                        openApiUrl = ""
                    }
                    .testTag("import_openapi_button")
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Import OpenAPI Spec",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White
                )
            }
        }

        // Add an MCP server URL
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(KnightsCardPill)
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Hub, contentDescription = null, tint = GeminiPurple, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Add MCP Server URL",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Normal,
                    color = Color.White
                )
            }
            OutlinedTextField(
                value = mcpServerUrl,
                onValueChange = { mcpServerUrl = it },
                placeholder = { Text("https://mcp.server.dev/sse", color = KnightsSecondaryGray, fontSize = 13.5.sp) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GeminiPurple,
                    unfocusedBorderColor = GeminiBorder,
                    focusedContainerColor = KnightsPureBlack,
                    unfocusedContainerColor = KnightsPureBlack,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("mcp_server_url_input")
            )
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 48.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(KnightsChatSendIndigo)
                    .clickable {
                        onAddConnector("MCP Server", "MCP Server", mcpServerUrl)
                        mcpServerUrl = ""
                    }
                    .testTag("add_mcp_server_button")
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Connect MCP Server",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White
                )
            }
        }

        // Active Connectors
        Text(
            text = "Connected APIs & MCP Servers",
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            color = KnightsSecondaryGray
        )

        connectors.forEach { conn ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(KnightsCardPill)
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = conn.name,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White
                    )
                    Text(
                        text = "${conn.type} • ${conn.endpointUrl}",
                        fontSize = 12.sp,
                        color = KnightsSecondaryGray,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(
                    onClick = { onRemoveConnector(conn.id) },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.DeleteOutline,
                        contentDescription = "Remove connector",
                        tint = KnightsSecondaryGray
                    )
                }
            }
        }
    }
}

@Composable
private fun SkillsTabContent(
    installedSkills: List<InstalledSkillItem>,
    skillDraftName: String?,
    skillDraftMarkdown: String?,
    blueprintJson: String,
    onToggleInstalledSkill: (String) -> Unit,
    onImportSkillFromGithub: (String) -> Unit,
    onPasteSkillMarkdown: (name: String, markdown: String) -> Unit,
    onDraftSkillWithPrompt: (String) -> Unit,
    onApproveSkillDraft: () -> Unit,
    onDiscardSkillDraft: () -> Unit,
    onForgeCustomKnight: (id: String, codename: String, description: String, prompt: String) -> Unit,
    onSaveBlueprint: (String) -> Unit,
    onResetBlueprint: () -> Unit
) {
    var activeSkillAction by remember { mutableStateOf<String?>(null) } // "GITHUB", "PASTE", "PROMPT"
    var githubUrlInput by remember { mutableStateOf("") }
    var pastedSkillName by remember { mutableStateOf("") }
    var pastedSkillMd by remember { mutableStateOf("") }
    var skillPromptInput by remember { mutableStateOf("") }

    var knightId by remember { mutableStateOf("") }
    var codename by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }
    var jsonText by remember(blueprintJson) { mutableStateOf(blueprintJson) }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        // Three action buttons: "Import from GitHub URL", "Paste SKILL.md", and "Create with prompt"
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SkillActionPillButton(
                icon = Icons.Outlined.Link,
                label = "Import from GitHub URL",
                selected = activeSkillAction == "GITHUB",
                testTag = "skill_action_github",
                onClick = { activeSkillAction = if (activeSkillAction == "GITHUB") null else "GITHUB" }
            )
            SkillActionPillButton(
                icon = Icons.Outlined.ContentPaste,
                label = "Paste SKILL.md",
                selected = activeSkillAction == "PASTE",
                testTag = "skill_action_paste",
                onClick = { activeSkillAction = if (activeSkillAction == "PASTE") null else "PASTE" }
            )
            SkillActionPillButton(
                icon = Icons.Outlined.AutoFixHigh,
                label = "Create with prompt",
                selected = activeSkillAction == "PROMPT",
                testTag = "skill_action_prompt",
                onClick = { activeSkillAction = if (activeSkillAction == "PROMPT") null else "PROMPT" }
            )
        }

        // Expandable input panels for the 3 Skill actions
        AnimatedVisibility(visible = activeSkillAction == "GITHUB") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(KnightsCardPill)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = githubUrlInput,
                    onValueChange = { githubUrlInput = it },
                    placeholder = { Text("https://github.com/org/repo/blob/main/SKILL.md", color = KnightsSecondaryGray, fontSize = 13.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GeminiLightBlue,
                        unfocusedBorderColor = GeminiBorder,
                        focusedContainerColor = KnightsPureBlack,
                        unfocusedContainerColor = KnightsPureBlack,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 48.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(KnightsChatSendIndigo)
                        .clickable {
                            onImportSkillFromGithub(githubUrlInput)
                            githubUrlInput = ""
                            activeSkillAction = null
                        }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Import Skill", color = Color.White, fontWeight = FontWeight.Medium)
                }
            }
        }

        AnimatedVisibility(visible = activeSkillAction == "PASTE") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(KnightsCardPill)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = pastedSkillName,
                    onValueChange = { pastedSkillName = it },
                    placeholder = { Text("Skill name (e.g. seo-auditor)", color = KnightsSecondaryGray, fontSize = 13.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GeminiLightBlue,
                        unfocusedBorderColor = GeminiBorder,
                        focusedContainerColor = KnightsPureBlack,
                        unfocusedContainerColor = KnightsPureBlack,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = pastedSkillMd,
                    onValueChange = { pastedSkillMd = it },
                    placeholder = { Text("Paste SKILL.md YAML frontmatter and instructions...", color = KnightsSecondaryGray, fontSize = 13.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GeminiLightBlue,
                        unfocusedBorderColor = GeminiBorder,
                        focusedContainerColor = KnightsPureBlack,
                        unfocusedContainerColor = KnightsPureBlack,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 100.dp)
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 48.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(KnightsChatSendIndigo)
                        .clickable {
                            onPasteSkillMarkdown(pastedSkillName, pastedSkillMd)
                            pastedSkillName = ""
                            pastedSkillMd = ""
                            activeSkillAction = null
                        }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Save SKILL.md", color = Color.White, fontWeight = FontWeight.Medium)
                }
            }
        }

        AnimatedVisibility(visible = activeSkillAction == "PROMPT") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(KnightsCardPill)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Skill Smith Agent will draft a SKILL.md for your review before saving.",
                    fontSize = 12.5.sp,
                    color = KnightsSecondaryGray
                )
                OutlinedTextField(
                    value = skillPromptInput,
                    onValueChange = { skillPromptInput = it },
                    placeholder = { Text("Describe the skill to build (e.g. Analyze YouTube retention graphs)...", color = KnightsSecondaryGray, fontSize = 13.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GeminiLightBlue,
                        unfocusedBorderColor = GeminiBorder,
                        focusedContainerColor = KnightsPureBlack,
                        unfocusedContainerColor = KnightsPureBlack,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("skill_smith_prompt_input")
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 48.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(KnightsChatSendIndigo)
                        .clickable {
                            onDraftSkillWithPrompt(skillPromptInput)
                            skillPromptInput = ""
                        }
                        .testTag("draft_skill_button")
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Draft SKILL.md Preview", color = Color.White, fontWeight = FontWeight.Medium)
                }
            }
        }

        // Skill Smith Draft Preview & Approval Card
        if (skillDraftMarkdown != null) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(KnightsCardPill)
                    .border(1.dp, GeminiLightBlue.copy(alpha = 0.6f), RoundedCornerShape(28.dp))
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Skill Smith Preview • ${skillDraftName ?: "SKILL.md"}",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    color = GeminiLightBlue
                )
                Text(
                    text = skillDraftMarkdown,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color.White,
                    lineHeight = 17.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(KnightsPureBlack)
                        .padding(12.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 48.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .background(KnightsChatSendIndigo)
                            .clickable { onApproveSkillDraft() }
                            .testTag("approve_skill_draft_button")
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Approve & Save", color = Color.White, fontWeight = FontWeight.Medium)
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 48.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .background(KnightsPureBlack)
                            .border(1.dp, GeminiBorder, RoundedCornerShape(24.dp))
                            .clickable { onDiscardSkillDraft() }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Discard", color = KnightsSecondaryGray)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = "Installed Skills (${installedSkills.size})",
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            color = KnightsSecondaryGray
        )

        installedSkills.forEach { skill ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(KnightsCardPill)
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = skill.name,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Normal,
                        color = Color.White
                    )
                    Text(
                        text = skill.source,
                        fontSize = 12.sp,
                        color = KnightsSecondaryGray
                    )
                }
                Switch(
                    checked = skill.isEnabled,
                    onCheckedChange = { onToggleInstalledSkill(skill.id) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = KnightsPureBlack,
                        checkedTrackColor = KnightEmerald,
                        uncheckedThumbColor = KnightsSecondaryGray,
                        uncheckedTrackColor = KnightsPureBlack
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        HorizontalDivider(color = GeminiBorder)
        Spacer(modifier = Modifier.height(8.dp))

        // Custom Agent Forge & 9-Agent Blueprint
        Text(
            text = "Create a Custom Knight Agent",
            fontSize = 18.sp,
            fontWeight = FontWeight.Normal,
            color = Color.White
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(KnightsCardPill)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = knightId,
                    onValueChange = { knightId = it },
                    label = { Text("Agent ID", fontSize = 11.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GeminiLightBlue,
                        unfocusedBorderColor = GeminiBorder,
                        focusedContainerColor = KnightsPureBlack,
                        unfocusedContainerColor = KnightsPureBlack,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = codename,
                    onValueChange = { codename = it },
                    label = { Text("Display Name", fontSize = 11.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GeminiLightBlue,
                        unfocusedBorderColor = GeminiBorder,
                        focusedContainerColor = KnightsPureBlack,
                        unfocusedContainerColor = KnightsPureBlack,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f)
                )
            }
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Role Description", fontSize = 11.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GeminiLightBlue,
                    unfocusedBorderColor = GeminiBorder,
                    focusedContainerColor = KnightsPureBlack,
                    unfocusedContainerColor = KnightsPureBlack,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = prompt,
                onValueChange = { prompt = it },
                label = { Text("System Instructions", fontSize = 11.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GeminiLightBlue,
                    unfocusedBorderColor = GeminiBorder,
                    focusedContainerColor = KnightsPureBlack,
                    unfocusedContainerColor = KnightsPureBlack,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            )
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 48.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(KnightsChatSendIndigo)
                    .clickable {
                        onForgeCustomKnight(knightId, codename, description, prompt)
                        knightId = ""
                        codename = ""
                        description = ""
                        prompt = ""
                    }
                    .testTag("forge_custom_knight_button")
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("+ Create Custom Knight", color = Color.White, fontWeight = FontWeight.Medium)
            }
        }

        // Blueprint Save / Reset
        OutlinedTextField(
            value = jsonText,
            onValueChange = { jsonText = it },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GeminiLightBlue,
                unfocusedBorderColor = GeminiBorder,
                focusedContainerColor = KnightsCardPill,
                unfocusedContainerColor = KnightsCardPill,
                focusedTextColor = Color.White,
                unfocusedTextColor = KnightsSecondaryGray
            ),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp),
            textStyle = MaterialTheme.typography.bodySmall.copy(
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp
            )
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
                modifier = Modifier
                    .weight(2f)
                    .defaultMinSize(minHeight = 48.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(KnightsCardPill)
                    .clickable { onSaveBlueprint(jsonText) }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Save Blueprint", color = GeminiLightBlue, fontWeight = FontWeight.Medium)
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .defaultMinSize(minHeight = 48.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(KnightsCardPill)
                    .clickable { onResetBlueprint() }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Reset", color = KnightsSecondaryGray)
            }
        }
    }
}

@Composable
private fun SkillActionPillButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 54.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(KnightsCardPill)
            .border(
                width = 1.dp,
                color = if (selected) GeminiLightBlue else Color.Transparent,
                shape = RoundedCornerShape(28.dp)
            )
            .clickable(onClick = onClick)
            .testTag(testTag)
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = Color.White,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            text = label,
            fontSize = 16.sp,
            fontWeight = FontWeight.Normal,
            color = Color.White
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun LocalAiModelCard(
    model: LocalAiModel,
    onInstall: () -> Unit,
    onUninstall: () -> Unit,
    onBindToAll: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(KnightsCardPill)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = model.name,
                    fontWeight = FontWeight.Medium,
                    fontSize = 16.sp,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${model.parameters} • ${model.quantization} • ${model.sizeMb} MB",
                    fontSize = 12.sp,
                    color = KnightsSecondaryGray
                )
            }

            if (model.isInstalled) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Outlined.CheckCircle,
                        contentDescription = "Installed",
                        tint = KnightEmerald,
                        modifier = Modifier.size(18.dp)
                    )
                    IconButton(
                        onClick = onUninstall,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.DeleteOutline,
                            contentDescription = "Remove local model",
                            tint = KnightsSecondaryGray,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = model.description,
            fontSize = 12.5.sp,
            color = KnightsSecondaryGray,
            lineHeight = 17.sp
        )

        Spacer(modifier = Modifier.height(10.dp))

        if (model.isInstalling) {
            LinearProgressIndicator(
                progress = { model.installProgress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = GeminiLightBlue,
                trackColor = KnightsPureBlack
            )
        } else if (model.isInstalled) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 44.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(KnightsPureBlack)
                    .clickable { onBindToAll() }
                    .testTag("bind_local_model_${model.id}")
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Bind ${model.name} to All 9 Knights",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = GeminiLightBlue
                )
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 44.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(KnightsChatSendIndigo)
                    .clickable { onInstall() }
                    .testTag("install_local_model_${model.id}")
                    .padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Outlined.Download,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Install Local AI (${model.sizeMb} MB)",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White
                )
            }
        }
    }
}
