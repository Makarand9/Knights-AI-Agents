package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.AutoFixHigh
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.GraphicEq
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.KeyboardArrowUp
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.SmartDisplay
import androidx.compose.material.icons.outlined.Terminal
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AgentStatus
import com.example.data.model.DEFAULT_LOCAL_AI_MODELS
import com.example.data.model.KnightAgent
import com.example.data.model.KnightExecutionState
import com.example.data.model.LogLevel
import com.example.data.model.SquadronType
import com.example.data.model.TerminalMode
import com.example.ui.components.KnightsShieldStarMark
import com.example.ui.theme.GeminiBorder
import com.example.ui.theme.GeminiDarkBg
import com.example.ui.theme.GeminiLightBlue
import com.example.ui.theme.GeminiPurple
import com.example.ui.theme.GeminiRose
import com.example.ui.theme.GeminiSurface
import com.example.ui.theme.GeminiSurfaceBright
import com.example.ui.theme.GeminiSurfaceHigh
import com.example.ui.theme.KnightEmerald
import com.example.ui.theme.KnightsCardPill
import com.example.ui.theme.KnightsChatGlowNavy
import com.example.ui.theme.KnightsChatSendIndigo
import com.example.ui.theme.KnightsIconCircle
import com.example.ui.theme.KnightsInputPill
import com.example.ui.theme.KnightsPureBlack
import com.example.ui.theme.KnightsSecondaryGray
import com.example.ui.theme.KnightsTaskGlowViolet
import com.example.ui.theme.KnightsTaskSendViolet
import com.example.ui.viewmodel.KnightsUiState

@Composable
fun TerminalScreen(
    uiState: KnightsUiState,
    onCommandChanged: (String) -> Unit,
    onSquadronSelected: (SquadronType) -> Unit,
    onSoloKnightSelected: (String) -> Unit,
    onModeChanged: (TerminalMode) -> Unit,
    onDeployClicked: () -> Unit,
    onClearLogsClicked: () -> Unit,
    onTaskModeChanged: (Boolean) -> Unit = {},
    onToggleGridList: () -> Unit = {},
    onSquadronFilterChanged: (String) -> Unit = {},
    onToggleTerminalConsole: (Boolean?) -> Unit = {},
    onTriggerAgentTask: (agentId: String) -> Unit = { onSoloKnightSelected(it) },
    onCustomizeAgent: (agentId: String) -> Unit = {},
    onOpenMemorySettings: () -> Unit = {},
    onOpenLocalAiHub: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val scrollState = rememberScrollState()

    var forceMentionPopup by remember { mutableStateOf(false) }
    val showMentionPopup = forceMentionPopup || uiState.commandInput.endsWith("@")

    val selectedKnight = remember(uiState.allKnights, uiState.selectedSoloKnightId) {
        uiState.allKnights.find { it.id == uiState.selectedSoloKnightId }
            ?: uiState.allKnights.firstOrNull()
    }

    val bottomGlowColor = if (uiState.isTaskMode) KnightsTaskGlowViolet else KnightsChatGlowNavy

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(KnightsPureBlack)
    ) {
        // Soft bottom glow on the Home screen: Chat mode navy (#0B1A5C), Task mode violet-indigo (#3A2F9E)
        Canvas(modifier = Modifier.fillMaxSize()) {
            val radius = size.width * 0.95f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        bottomGlowColor.copy(alpha = 0.52f),
                        bottomGlowColor.copy(alpha = 0.18f),
                        Color.Transparent
                    ),
                    center = Offset(size.width / 2f, size.height * 0.96f),
                    radius = radius
                ),
                radius = radius,
                center = Offset(size.width / 2f, size.height * 0.96f)
            )
        }

        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Main Center / Output Scroll Area
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(scrollState)
                    .padding(horizontal = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = if (uiState.lastDeliverable == null && !uiState.isMissionRunning && !uiState.showTerminalConsole) {
                    Arrangement.Center
                } else {
                    Arrangement.Top
                }
            ) {
                if (uiState.isTemporaryChat && uiState.lastDeliverable == null && !uiState.isMissionRunning) {
                    // Prompt D: Temporary chat view ("Just stopping by?")
                    Spacer(modifier = Modifier.height(36.dp))
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(KnightsCardPill),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.EditNote,
                            contentDescription = "Temporary chat",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        text = "Just stopping by?",
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Light,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Temporary chats won't appear in your Library, Missions history, or update Knights memory.",
                        fontSize = 14.5.sp,
                        fontWeight = FontWeight.Normal,
                        color = KnightsSecondaryGray,
                        textAlign = TextAlign.Center,
                        lineHeight = 20.sp,
                        modifier = Modifier.padding(horizontal = 24.dp)
                    )
                    Spacer(modifier = Modifier.height(32.dp))
                } else {
                    Spacer(modifier = Modifier.height(24.dp))

                    // Original Knights shield-star mark in blue-to-violet-to-pink gradient
                    KnightsShieldStarMark(size = 44.dp)

                    Spacer(modifier = Modifier.height(20.dp))

                    // Big centered greeting ~34.sp, light weight
                    Text(
                        text = "Hi Commander,\nwhat's the move?",
                        fontSize = 34.sp,
                        lineHeight = 40.sp,
                        fontWeight = FontWeight.Light,
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.testTag("home_greeting_title")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Subtle active Knight / Team indicator pill (tap to pick @Knight)
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(KnightsCardPill.copy(alpha = 0.75f))
                            .clickable { forceMentionPopup = !forceMentionPopup }
                            .padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (uiState.isTaskMode) {
                                "Task Mode • All 9 Knights Team"
                            } else {
                                "Chat • @${selectedKnight?.codename ?: "Knight I • Vanguard Scout"}"
                            },
                            fontSize = 12.5.sp,
                            color = KnightsSecondaryGray
                        )
                    }

                    // Prompt A: In Task mode, show three plain suggestion rows with thin icons, no cards
                    AnimatedVisibility(visible = uiState.isTaskMode && uiState.lastDeliverable == null && !uiState.isMissionRunning) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 28.dp, start = 12.dp, end = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            val suggestions = listOf(
                                Triple(
                                    Icons.Outlined.SmartDisplay,
                                    "Plan a YouTube video",
                                    "Plan a viral YouTube video with hook, retention script, thumbnail brief, and SEO metadata"
                                ),
                                Triple(
                                    Icons.Outlined.Search,
                                    "Research a topic",
                                    "Research the latest breakthroughs in autonomous AI agents with live web citations"
                                ),
                                Triple(
                                    Icons.Outlined.AutoFixHigh,
                                    "Build a skill",
                                    "Build a reusable SKILL.md for automated competitor analysis and executive reporting"
                                )
                            )
                            suggestions.forEach { (icon, title, fullPrompt) ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .defaultMinSize(minHeight = 48.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .clickable {
                                            onCommandChanged(fullPrompt)
                                        }
                                        .testTag("task_suggestion_${title.lowercase().replace(" ", "_")}")
                                        .padding(horizontal = 12.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = title,
                                        tint = KnightsSecondaryGray,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Text(
                                        text = title,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Light,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }

                // Active Deliverable / Live Agent Execution Output
                if (uiState.lastDeliverable != null || uiState.isMissionRunning || uiState.showTerminalConsole) {
                    Spacer(modifier = Modifier.height(20.dp))

                    LiveOutputAndTerminalSection(
                        uiState = uiState,
                        onToggleExpand = { onToggleTerminalConsole(null) },
                        onClearLogs = onClearLogsClicked,
                        onCopyText = { title, text ->
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText(title, text))
                            Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                        },
                        onShareText = { text ->
                            val sendIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, text)
                                type = "text/plain"
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "Share Knights Output"))
                        }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // Bottom Section: @ Knight Picker Popup + Chat | Task Toggle + 60.dp Pill Input Bar
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Typing "@" opens a list to pick one of the 9 Knights
                AnimatedVisibility(visible = showMentionPopup) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                            .clip(RoundedCornerShape(28.dp))
                            .background(KnightsCardPill)
                            .border(1.dp, GeminiBorder, RoundedCornerShape(28.dp))
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Pick one of the 9 Knights (@)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = KnightsSecondaryGray
                            )
                            Text(
                                text = "Close",
                                fontSize = 12.sp,
                                color = GeminiLightBlue,
                                modifier = Modifier.clickable { forceMentionPopup = false }
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 220.dp)
                        ) {
                            items(uiState.allKnights) { knight ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .defaultMinSize(minHeight = 48.dp)
                                        .clip(RoundedCornerShape(18.dp))
                                        .clickable {
                                            onSoloKnightSelected(knight.id)
                                            if (uiState.commandInput.endsWith("@")) {
                                                onCommandChanged(uiState.commandInput.removeSuffix("@"))
                                            }
                                            forceMentionPopup = false
                                        }
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .clip(CircleShape)
                                            .background(KnightsIconCircle),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${knight.orderNumber}",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = GeminiLightBlue
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = knight.codename,
                                            fontSize = 14.sp,
                                            color = Color.White,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = knight.description,
                                            fontSize = 11.5.sp,
                                            color = KnightsSecondaryGray,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Above the input bar: Chat | Task toggle where the selected option sits in a dark rounded pill (#1E1E1E)
                Row(
                    modifier = Modifier
                        .padding(bottom = 12.dp)
                        .clip(RoundedCornerShape(28.dp))
                        .background(Color(0xFF111113))
                        .border(1.dp, GeminiBorder, RoundedCornerShape(28.dp))
                        .padding(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .defaultMinSize(minWidth = 88.dp, minHeight = 38.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .background(if (!uiState.isTaskMode) KnightsCardPill else Color.Transparent)
                            .clickable { onTaskModeChanged(false) }
                            .testTag("mode_toggle_chat")
                            .padding(horizontal = 18.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Chat",
                            fontSize = 14.sp,
                            fontWeight = if (!uiState.isTaskMode) FontWeight.Medium else FontWeight.Light,
                            color = if (!uiState.isTaskMode) Color.White else KnightsSecondaryGray
                        )
                    }

                    Box(
                        modifier = Modifier
                            .defaultMinSize(minWidth = 88.dp, minHeight = 38.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .background(if (uiState.isTaskMode) KnightsCardPill else Color.Transparent)
                            .clickable { onTaskModeChanged(true) }
                            .testTag("mode_toggle_task")
                            .padding(horizontal = 18.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Task",
                            fontSize = 14.sp,
                            fontWeight = if (uiState.isTaskMode) FontWeight.Medium else FontWeight.Light,
                            color = if (uiState.isTaskMode) Color.White else KnightsSecondaryGray
                        )
                    }
                }

                // Bottom Input Bar: pill, ~60.dp tall, fill #1F1F1F.
                // Left "+" icon, gray placeholder "Describe a task", mic icon, then 52.dp round indigo button
                KnightsBottomInputPill(
                    commandInput = uiState.commandInput,
                    isTaskMode = uiState.isTaskMode,
                    isMissionRunning = uiState.isMissionRunning,
                    onCommandChanged = onCommandChanged,
                    onPlusClicked = { forceMentionPopup = !forceMentionPopup },
                    onMicClicked = {
                        val sampleVoice = if (uiState.isTaskMode) {
                            "Plan a high-retention YouTube video and full research brief on autonomous agents"
                        } else {
                            "Summarize the top 3 strategic moves for our next product launch"
                        }
                        onCommandChanged(sampleVoice)
                    },
                    onSendClicked = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        if (uiState.commandInput.isBlank()) {
                            onCommandChanged(
                                if (uiState.isTaskMode) {
                                    "Run a full 9-Knight autonomous mission on AI engineering trends"
                                } else {
                                    "Analyze current opportunities and give me a direct action plan"
                                }
                            )
                        }
                        onDeployClicked()
                    }
                )
            }
        }
    }
}

@Composable
private fun KnightsBottomInputPill(
    commandInput: String,
    isTaskMode: Boolean,
    isMissionRunning: Boolean,
    onCommandChanged: (String) -> Unit,
    onPlusClicked: () -> Unit,
    onMicClicked: () -> Unit,
    onSendClicked: () -> Unit
) {
    val hasText = commandInput.trim().isNotEmpty()
    val buttonColor = when {
        isMissionRunning -> Color(0xFF3C4043)
        isTaskMode -> KnightsTaskSendViolet
        else -> KnightsChatSendIndigo
    }

    val infiniteTransition = rememberInfiniteTransition(label = "sendPulse")
    val runningScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(750),
            repeatMode = RepeatMode.Reverse
        ),
        label = "sendScale"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 60.dp)
            .clip(RoundedCornerShape(30.dp))
            .background(KnightsInputPill)
            .padding(start = 6.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left "+" icon (touch target >= 48.dp)
        IconButton(
            onClick = onPlusClicked,
            modifier = Modifier
                .size(48.dp)
                .testTag("input_plus_button")
        ) {
            Icon(
                imageVector = Icons.Outlined.Add,
                contentDescription = "Pick Knight or attach context",
                tint = KnightsSecondaryGray,
                modifier = Modifier.size(24.dp)
            )
        }

        // Text Field with gray placeholder "Describe a task"
        Box(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 4.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            if (commandInput.isEmpty()) {
                Text(
                    text = "Describe a task",
                    color = KnightsSecondaryGray,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Light
                )
            }
            BasicTextField(
                value = commandInput,
                onValueChange = onCommandChanged,
                textStyle = TextStyle(
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Normal
                ),
                cursorBrush = SolidColor(GeminiLightBlue),
                maxLines = 4,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("terminal_command_input")
            )
        }

        // Mic icon (touch target >= 48.dp)
        IconButton(
            onClick = onMicClicked,
            modifier = Modifier
                .size(48.dp)
                .testTag("input_mic_button")
        ) {
            Icon(
                imageVector = Icons.Outlined.Mic,
                contentDescription = "Voice input",
                tint = KnightsSecondaryGray,
                modifier = Modifier.size(22.dp)
            )
        }

        // 52.dp round button: indigo with waveform icon when empty; up-arrow when there is text
        Box(
            modifier = Modifier
                .size(52.dp)
                .scale(if (isMissionRunning) runningScale else 1f)
                .clip(CircleShape)
                .background(buttonColor)
                .clickable(enabled = !isMissionRunning) { onSendClicked() }
                .testTag("deploy_mission_button"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (hasText) Icons.Outlined.ArrowUpward else Icons.Outlined.GraphicEq,
                contentDescription = if (hasText) "Send task" else "Start voice or quick task",
                tint = Color.White,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@Composable
private fun LiveOutputAndTerminalSection(
    uiState: KnightsUiState,
    onToggleExpand: () -> Unit,
    onClearLogs: () -> Unit,
    onCopyText: (String, String) -> Unit,
    onShareText: (String) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Deliverable Card if available
        uiState.lastDeliverable?.let { deliverable ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(KnightsCardPill)
                    .border(1.dp, GeminiBorder, RoundedCornerShape(28.dp))
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = deliverable.title,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White
                        )
                        Text(
                            text = "${deliverable.authorKnight} • ${deliverable.formattedDate}",
                            fontSize = 12.sp,
                            color = KnightsSecondaryGray
                        )
                    }
                    Row {
                        IconButton(
                            onClick = { onCopyText(deliverable.title, deliverable.content) },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.ContentCopy,
                                contentDescription = "Copy output",
                                tint = KnightsSecondaryGray,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        IconButton(
                            onClick = { onShareText(deliverable.content) },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Share,
                                contentDescription = "Share output",
                                tint = KnightsSecondaryGray,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                SelectionContainer {
                    Text(
                        text = deliverable.content,
                        fontSize = 13.5.sp,
                        lineHeight = 20.sp,
                        color = Color(0xFFE3E3E3)
                    )
                }
            }
        }

        // Collapsible Live Execution Stream
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(KnightsCardPill)
                .border(1.dp, GeminiBorder, RoundedCornerShape(28.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleExpand() }
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Outlined.Terminal,
                        contentDescription = null,
                        tint = GeminiLightBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = if (uiState.isMissionRunning) "Knights Executing Task..." else "Execution Log (${uiState.terminalLogs.size})",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Normal,
                        color = Color.White
                    )
                }
                Icon(
                    imageVector = if (uiState.showTerminalConsole) Icons.Outlined.KeyboardArrowUp else Icons.Outlined.KeyboardArrowDown,
                    contentDescription = "Expand logs",
                    tint = KnightsSecondaryGray
                )
            }

            AnimatedVisibility(visible = uiState.showTerminalConsole || uiState.isMissionRunning) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 18.dp, end = 18.dp, bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    uiState.terminalLogs.takeLast(8).forEach { log ->
                        val logColor = when (log.level) {
                            LogLevel.SUCCESS -> KnightEmerald
                            LogLevel.WARN -> Color(0xFFFDD663)
                            LogLevel.ERROR -> GeminiRose
                            else -> KnightsSecondaryGray
                        }
                        Text(
                            text = "${log.formattedTime} ${log.agentName?.let { "[$it] " } ?: ""}${log.message}",
                            fontSize = 11.5.sp,
                            fontFamily = FontFamily.Monospace,
                            color = logColor,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}

/**
 * 2-Column Adaptive Grid of the 9 Autonomous Agents (used in Knights Roster & tests)
 */
@Composable
fun AutonomousAgentsGrid(
    agents: List<KnightAgent>,
    executionStates: Map<String, KnightExecutionState>,
    selectedSoloKnightId: String?,
    onAgentClicked: (KnightAgent) -> Unit,
    onTriggerAgentTask: (KnightAgent) -> Unit = onAgentClicked,
    onCustomizeAgent: (KnightAgent) -> Unit = {}
) {
    val rows = agents.chunked(2)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("agents_grid_container"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        rows.forEach { rowAgents ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                rowAgents.forEach { agent ->
                    GeminiAgentGridCard(
                        agent = agent,
                        execState = executionStates[agent.id],
                        isSelected = selectedSoloKnightId == agent.id,
                        onClick = { onAgentClicked(agent) },
                        onTriggerTask = { onTriggerAgentTask(agent) },
                        onCustomize = { onCustomizeAgent(agent) },
                        modifier = Modifier.weight(1f)
                    )
                }
                if (rowAgents.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

/**
 * Vertical List of the 9 Autonomous Agents with visual status indicators, role descriptions & task triggers
 */
@Composable
fun AutonomousAgentsList(
    agents: List<KnightAgent>,
    executionStates: Map<String, KnightExecutionState>,
    selectedSoloKnightId: String?,
    onAgentClicked: (KnightAgent) -> Unit,
    onTriggerAgentTask: (KnightAgent) -> Unit = onAgentClicked,
    onCustomizeAgent: (KnightAgent) -> Unit = {}
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("agents_list_container"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        agents.forEach { agent ->
            GeminiAgentListRow(
                agent = agent,
                execState = executionStates[agent.id],
                isSelected = selectedSoloKnightId == agent.id,
                onClick = { onAgentClicked(agent) },
                onTriggerTask = { onTriggerAgentTask(agent) },
                onCustomize = { onCustomizeAgent(agent) }
            )
        }
    }
}

@Composable
private fun GeminiAgentGridCard(
    agent: KnightAgent,
    execState: KnightExecutionState?,
    isSelected: Boolean,
    onClick: () -> Unit,
    onTriggerTask: () -> Unit,
    onCustomize: () -> Unit,
    modifier: Modifier = Modifier
) {
    val status = execState?.status
    val borderColor = when {
        status == AgentStatus.EXECUTING -> GeminiLightBlue
        isSelected -> GeminiLightBlue.copy(alpha = 0.65f)
        status == AgentStatus.COMPLETED -> KnightEmerald.copy(alpha = 0.55f)
        else -> GeminiBorder
    }

    val containerBg = if (isSelected) GeminiSurfaceHigh else GeminiSurface
    val localModelShort = remember(agent.localModelId) {
        DEFAULT_LOCAL_AI_MODELS.find { it.id == agent.localModelId }?.name?.substringBefore(" ") ?: "Cloud"
    }

    Column(
        modifier = modifier
            .defaultMinSize(minHeight = 166.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(containerBg)
            .border(1.dp, borderColor, RoundedCornerShape(28.dp))
            .clickable(onClick = onClick)
            .testTag("agent_card_${agent.id}")
            .padding(14.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                AgentGemAvatar(agent = agent, sizeDp = 30)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AgentVisualStatusIndicator(execState = execState, compact = true)
                    Spacer(modifier = Modifier.width(2.dp))
                    IconButton(
                        onClick = onCustomize,
                        modifier = Modifier
                            .size(28.dp)
                            .testTag("customize_agent_${agent.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Tune,
                            contentDescription = "Customize ${agent.codename}",
                            tint = KnightsSecondaryGray,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = agent.codename,
                fontWeight = FontWeight.Medium,
                fontSize = 14.sp,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = agent.description,
                fontSize = 11.5.sp,
                color = KnightsSecondaryGray,
                lineHeight = 15.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.Language,
                    contentDescription = "Live Web",
                    tint = if (agent.internetEnabled) KnightEmerald else Color(0xFF5F6368),
                    modifier = Modifier.size(12.dp)
                )
                Text(
                    text = if (agent.internetEnabled) "Web" else "Offline",
                    fontSize = 10.sp,
                    color = if (agent.internetEnabled) KnightEmerald else KnightsSecondaryGray
                )
                Text(
                    text = "• $localModelShort",
                    fontSize = 10.sp,
                    color = KnightsSecondaryGray
                )
            }

            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(GeminiSurfaceBright)
                    .clickable(onClick = onTriggerTask)
                    .testTag("trigger_task_${agent.id}")
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Outlined.PlayArrow,
                    contentDescription = "Trigger task for ${agent.codename}",
                    tint = GeminiLightBlue,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                    text = "Task",
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun GeminiAgentListRow(
    agent: KnightAgent,
    execState: KnightExecutionState?,
    isSelected: Boolean,
    onClick: () -> Unit,
    onTriggerTask: () -> Unit,
    onCustomize: () -> Unit
) {
    val status = execState?.status
    val borderColor = when {
        status == AgentStatus.EXECUTING -> GeminiLightBlue
        isSelected -> GeminiLightBlue.copy(alpha = 0.65f)
        status == AgentStatus.COMPLETED -> KnightEmerald.copy(alpha = 0.55f)
        else -> GeminiBorder
    }

    val localModelName = remember(agent.localModelId) {
        DEFAULT_LOCAL_AI_MODELS.find { it.id == agent.localModelId }?.name ?: "Cloud Engine"
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 84.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(if (isSelected) GeminiSurfaceHigh else GeminiSurface)
            .border(1.dp, borderColor, RoundedCornerShape(28.dp))
            .clickable(onClick = onClick)
            .testTag("agent_list_item_${agent.id}")
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AgentGemAvatar(agent = agent, sizeDp = 42)

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = agent.codename,
                    fontWeight = FontWeight.Medium,
                    fontSize = 15.sp,
                    color = Color.White,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.width(6.dp))
                AgentVisualStatusIndicator(execState = execState, compact = false)
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = agent.description,
                fontSize = 12.sp,
                color = KnightsSecondaryGray,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(GeminiDarkBg)
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = if (agent.internetEnabled) "Web ON" else "Offline",
                            fontSize = 10.sp,
                            color = if (agent.internetEnabled) KnightEmerald else KnightsSecondaryGray
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(GeminiDarkBg)
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = localModelName,
                            fontSize = 10.sp,
                            color = KnightsSecondaryGray
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onCustomize,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("list_customize_agent_${agent.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Tune,
                            contentDescription = "Customize ${agent.codename}",
                            tint = KnightsSecondaryGray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(GeminiSurfaceBright)
                            .clickable(onClick = onTriggerTask)
                            .testTag("list_trigger_task_${agent.id}")
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.PlayArrow,
                            contentDescription = "Run task",
                            tint = GeminiLightBlue,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Run Task",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AgentGemAvatar(
    agent: KnightAgent,
    sizeDp: Int
) {
    val accentColor = when {
        agent.isYouTube -> GeminiRose
        agent.isUniversal -> GeminiLightBlue
        else -> KnightEmerald
    }

    Box(
        modifier = Modifier
            .size(sizeDp.dp)
            .clip(CircleShape)
            .background(KnightsIconCircle)
            .border(1.dp, accentColor.copy(alpha = 0.45f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "${agent.orderNumber}",
            fontWeight = FontWeight.Medium,
            fontSize = (sizeDp * 0.40f).sp,
            color = accentColor
        )
    }
}

@Composable
fun AgentVisualStatusIndicator(
    execState: KnightExecutionState?,
    compact: Boolean
) {
    val infiniteTransition = rememberInfiniteTransition(label = "statusPulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(700),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseDot"
    )

    val (dotColor, bgColor, statusText) = when (execState?.status) {
        AgentStatus.EXECUTING -> Triple(
            GeminiLightBlue,
            GeminiLightBlue.copy(alpha = 0.14f),
            if (compact) "Active" else (execState.activeTool?.let { "⚡ $it" } ?: "Executing")
        )
        AgentStatus.QUEUED -> Triple(
            Color(0xFFFDD663),
            Color(0xFFFDD663).copy(alpha = 0.14f),
            "Queued"
        )
        AgentStatus.COMPLETED -> Triple(
            KnightEmerald,
            KnightEmerald.copy(alpha = 0.14f),
            if (compact) "Done" else "Done (${execState.durationMs}ms)"
        )
        AgentStatus.FAILED -> Triple(
            GeminiRose,
            GeminiRose.copy(alpha = 0.16f),
            "Failed"
        )
        null -> Triple(
            KnightEmerald,
            KnightsIconCircle,
            "Ready"
        )
    }

    Row(
        modifier = Modifier
            .clip(CircleShape)
            .background(bgColor)
            .padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .scale(if (execState?.status == AgentStatus.EXECUTING) pulseScale else 1f)
                .clip(CircleShape)
                .background(dotColor)
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = statusText,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            color = dotColor
        )
    }
}
