package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.YouTubeFunnelParams
import com.example.ui.theme.KnightCyan
import com.example.ui.theme.KnightEmerald
import com.example.ui.theme.KnightIndigo
import com.example.ui.theme.KnightRose
import com.example.ui.theme.KnightSurfaceCard
import com.example.ui.theme.KnightViolet
import java.util.Locale

@Composable
fun YouTubeLabScreen(
    params: YouTubeFunnelParams,
    onViewsChanged: (Long) -> Unit,
    onRpmChanged: (Double) -> Unit,
    onCtrChanged: (Double) -> Unit,
    onAvdChanged: (Double) -> Unit,
    onLaunchSquadronClicked: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(bottom = 24.dp)
    ) {
        Text(
            text = "🎬 YouTube Revenue & Funnel Simulator",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = Color.White
        )
        Text(
            text = "Model ad revenue, watch hours, and impression targets before dispatching the 5-Knight YouTube Squadron",
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFF94A3B8)
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Metrics Summary Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MetricBox(
                value = "$" + String.format(Locale.US, "%,.2f", params.estimatedAdRevenueUsd),
                label = "Estimated Ad Revenue",
                accentColor = KnightEmerald,
                modifier = Modifier.weight(1f)
            )
            MetricBox(
                value = String.format(Locale.US, "%,.1f", params.projectedWatchTimeHours) + " hrs",
                label = if (params.isMonetizationEligible) "Watch Time (Eligible ✓)" else "Watch Time",
                accentColor = if (params.isMonetizationEligible) KnightCyan else Color(0xFFFBBF24),
                modifier = Modifier.weight(1f)
            )
            MetricBox(
                value = String.format(Locale.US, "%,d", params.requiredImpressions),
                label = "Impressions Needed",
                accentColor = KnightRose,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Input Sliders Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(KnightSurfaceCard)
                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(18.dp))
                .padding(16.dp)
        ) {
            // Projected Views
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Projected Views", fontSize = 13.sp, color = Color(0xFF94A3B8))
                Text(
                    text = String.format(Locale.US, "%,d views", params.views),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            Slider(
                value = params.views.toFloat(),
                onValueChange = { onViewsChanged(it.toLong()) },
                valueRange = 5_000f..1_000_000f,
                steps = 99,
                colors = SliderDefaults.colors(
                    thumbColor = KnightCyan,
                    activeTrackColor = KnightCyan,
                    inactiveTrackColor = Color(0xFF1E293B)
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Niche RPM
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Niche RPM ($ USD)", fontSize = 13.sp, color = Color(0xFF94A3B8))
                Text(
                    text = String.format(Locale.US, "$%.2f RPM", params.rpmUsd),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            Slider(
                value = params.rpmUsd.toFloat(),
                onValueChange = { onRpmChanged(it.toDouble()) },
                valueRange = 1.0f..30.0f,
                steps = 58,
                colors = SliderDefaults.colors(
                    thumbColor = KnightEmerald,
                    activeTrackColor = KnightEmerald,
                    inactiveTrackColor = Color(0xFF1E293B)
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Target CTR
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Target CTR (%)", fontSize = 13.sp, color = Color(0xFF94A3B8))
                Text(
                    text = String.format(Locale.US, "%.1f%% CTR", params.ctrPercent),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            Slider(
                value = params.ctrPercent.toFloat(),
                onValueChange = { onCtrChanged(it.toDouble()) },
                valueRange = 2.0f..18.0f,
                steps = 32,
                colors = SliderDefaults.colors(
                    thumbColor = KnightRose,
                    activeTrackColor = KnightRose,
                    inactiveTrackColor = Color(0xFF1E293B)
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Average View Duration
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Average View Duration (Mins)", fontSize = 13.sp, color = Color(0xFF94A3B8))
                Text(
                    text = String.format(Locale.US, "%.1f min", params.avgViewDurationMins),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            Slider(
                value = params.avgViewDurationMins.toFloat(),
                onValueChange = { onAvdChanged(it.toDouble()) },
                valueRange = 1.0f..15.0f,
                steps = 28,
                colors = SliderDefaults.colors(
                    thumbColor = KnightViolet,
                    activeTrackColor = KnightViolet,
                    inactiveTrackColor = Color(0xFF1E293B)
                )
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Launch YouTube Squadron Button
        val geminiGradient = Brush.linearGradient(
            listOf(KnightIndigo, KnightViolet, KnightRose, KnightCyan)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .defaultMinSize(minHeight = 50.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(geminiGradient)
                .clickable { onLaunchSquadronClicked() }
                .testTag("launch_youtube_squadron_button")
                .padding(vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "🚀 Arm & Launch 5-Knight YouTube Squadron",
                fontWeight = FontWeight.Bold,
                color = Color.White,
                fontSize = 14.5.sp
            )
        }
    }
}

@Composable
fun MetricBox(
    value: String,
    label: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF090D1C))
            .border(1.dp, accentColor.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
            .padding(vertical = 12.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            fontWeight = FontWeight.Black,
            fontSize = 15.sp,
            color = accentColor,
            maxLines = 1
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            color = Color(0xFF94A3B8),
            maxLines = 1
        )
    }
}
