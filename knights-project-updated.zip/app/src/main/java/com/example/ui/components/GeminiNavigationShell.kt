package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AutoAwesomeMotion
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Deliverable
import com.example.data.model.DeviceHardwareInfo
import com.example.data.model.KnightAgent
import com.example.data.model.SquadronType
import com.example.ui.theme.GeminiBorder
import com.example.ui.theme.GeminiLightBlue
import com.example.ui.theme.GeminiPurple
import com.example.ui.theme.GeminiRose
import com.example.ui.theme.KnightEmerald
import com.example.ui.theme.KnightsCardPill
import com.example.ui.theme.KnightsChatSendIndigo
import com.example.ui.theme.KnightsIconCircle
import com.example.ui.theme.KnightsPureBlack
import com.example.ui.theme.KnightsSecondaryGray
import com.example.ui.viewmodel.KnightsTab

/**
 * Original Knights four-point shield-star mark in a blue-to-violet-to-pink gradient.
 */
@Composable
fun KnightsShieldStarMark(
    size: Dp = 36.dp,
    modifier: Modifier = Modifier
) {
    val gradient = Brush.linearGradient(
        colors = listOf(
            Color(0xFF6EA8FE),
            Color(0xFF9B72FF),
            Color(0xFFF28B82)
        )
    )
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val cx = w / 2f
        val cy = h / 2f
        val outerR = w * 0.46f
        val innerR = w * 0.16f

        val path = Path().apply {
            moveTo(cx, cy - outerR)
            quadraticTo(cx + innerR * 0.55f, cy - innerR * 0.55f, cx + outerR, cy)
            quadraticTo(cx + innerR * 0.55f, cy + innerR * 0.55f, cx, cy + outerR)
            quadraticTo(cx - innerR * 0.55f, cy + innerR * 0.55f, cx - outerR, cy)
            quadraticTo(cx - innerR * 0.55f, cy - innerR * 0.55f, cx, cy - outerR)
            close()
        }
        drawPath(path = path, brush = gradient)

        // Subtle inner shield diamond accent
        val shieldPath = Path().apply {
            moveTo(cx, cy - outerR * 0.45f)
            lineTo(cx + outerR * 0.45f, cy)
            lineTo(cx, cy + outerR * 0.45f)
            lineTo(cx - outerR * 0.45f, cy)
            close()
        }
        drawPath(
            path = shieldPath,
            color = Color.White.copy(alpha = 0.28f),
            style = Stroke(width = 1.5f)
        )
    }
}

/**
 * Minimal two-line menu icon on the left of the top bar (Prompt A).
 */
@Composable
fun TwoLineMenuIcon(
    tint: Color = Color.White,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.size(22.dp)) {
        val strokeWidth = 2.dp.toPx()
        val y1 = size.height * 0.36f
        val y2 = size.height * 0.66f
        drawLine(
            color = tint,
            start = Offset(size.width * 0.12f, y1),
            end = Offset(size.width * 0.88f, y1),
            strokeWidth = strokeWidth,
            cap = StrokeCap.Round
        )
        drawLine(
            color = tint,
            start = Offset(size.width * 0.12f, y2),
            end = Offset(size.width * 0.64f, y2),
            strokeWidth = strokeWidth,
            cap = StrokeCap.Round
        )
    }
}

@Composable
fun GeminiTopBar(
    activeModel: String,
    isGridView: Boolean,
    isMissionRunning: Boolean,
    showTerminalConsole: Boolean,
    hardwareInfo: DeviceHardwareInfo?,
    activeMemoryCount: Int = 3,
    installedLocalAiCount: Int = 1,
    isCloudSignedIn: Boolean = false,
    isTemporaryChat: Boolean = false,
    userName: String? = null,
    allKnights: List<KnightAgent> = emptyList(),
    onMenuClick: () -> Unit,
    onModelSelected: (String) -> Unit,
    onToggleGridList: () -> Unit,
    onToggleTerminal: () -> Unit,
    onToggleTemporaryChat: () -> Unit = {},
    onSelectSoloKnight: (String) -> Unit = {},
    onOpenAuthModal: () -> Unit = {},
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    var modelMenuExpanded by remember { mutableStateOf(false) }
    val models = listOf(
        "auto" to "Auto • Always the latest Flash (recommended)",
        "gemini-3.5-flash" to "3.5 Flash • Fixed version",
        "gemini-flash-latest" to "Flash Latest • Deep Reasoning & Code",
        "gemma-3-nano-local" to "Gemma 3 Nano 4B • On-Device Local AI"
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left: Two-line menu icon + Model picker showing "Knights" in white and current model in gray with chevron
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = onMenuClick,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("gemini_menu_button")
            ) {
                TwoLineMenuIcon(tint = Color.White)
            }

            Spacer(modifier = Modifier.width(4.dp))

            Box {
                Row(
                    modifier = Modifier
                        .defaultMinSize(minHeight = 48.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .clickable { modelMenuExpanded = true }
                        .testTag("gemini_model_selector")
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Knights",
                                fontWeight = FontWeight.Medium,
                                fontSize = 18.sp,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Outlined.KeyboardArrowDown,
                                contentDescription = "Switch Model or Agent",
                                tint = KnightsSecondaryGray,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Text(
                            text = activeModel,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Normal,
                            color = KnightsSecondaryGray
                        )
                    }
                }

                DropdownMenu(
                    expanded = modelMenuExpanded,
                    onDismissRequest = { modelMenuExpanded = false },
                    modifier = Modifier
                        .width(290.dp)
                        .background(KnightsCardPill)
                        .border(1.dp, GeminiBorder, RoundedCornerShape(20.dp))
                ) {
                    Text(
                        text = "Cloud & Local AI Engines",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = KnightsSecondaryGray,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                    models.forEach { (modelId, label) ->
                        val selected = activeModel == modelId
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(
                                        text = label.substringBefore(" • "),
                                        color = Color.White,
                                        fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = label.substringAfter(" • "),
                                        color = KnightsSecondaryGray,
                                        fontSize = 11.5.sp
                                    )
                                }
                            },
                            trailingIcon = {
                                if (selected) {
                                    Icon(
                                        imageVector = Icons.Outlined.Check,
                                        contentDescription = "Selected",
                                        tint = GeminiLightBlue,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            },
                            onClick = {
                                onModelSelected(modelId)
                                modelMenuExpanded = false
                            }
                        )
                    }

                    if (allKnights.isNotEmpty()) {
                        HorizontalDivider(color = GeminiBorder, modifier = Modifier.padding(vertical = 4.dp))
                        Text(
                            text = "Direct Per-Agent Selection",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = KnightsSecondaryGray,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                        )
                        allKnights.take(5).forEach { knight ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = knight.codename,
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                },
                                onClick = {
                                    onSelectSoloKnight(knight.id)
                                    modelMenuExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        }

        // Right: Temporary chat dotted-pencil toggle + Round profile avatar
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            IconButton(
                onClick = onToggleTemporaryChat,
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(if (isTemporaryChat) KnightsCardPill else Color.Transparent)
                    .testTag("temporary_chat_toggle_button")
            ) {
                Icon(
                    imageVector = Icons.Outlined.EditNote,
                    contentDescription = "Temporary chat",
                    tint = if (isTemporaryChat) GeminiLightBlue else KnightsSecondaryGray,
                    modifier = Modifier.size(22.dp)
                )
            }

            // Round profile avatar on the right (with thin colored ring)
            val ringBrush = Brush.linearGradient(
                colors = if (isCloudSignedIn) {
                    listOf(KnightEmerald, GeminiLightBlue, GeminiPurple)
                } else {
                    listOf(GeminiLightBlue, GeminiPurple, GeminiRose)
                }
            )
            val avatarInitial = (userName?.trim()?.firstOrNull()?.uppercaseChar() ?: 'C').toString()

            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .clickable { onOpenAuthModal() }
                    .testTag("gemini_profile_orb"),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(KnightsCardPill)
                        .border(1.5.dp, ringBrush, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = avatarInitial,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White
                    )
                }
            }
        }
    }
}

/**
 * Prompt B: Full-screen drawer on pure black #000000.
 * Top: title "Knights", search icon, close icon.
 * Rows with outline icons (18.sp text, generous spacing):
 * - New chat (highlighted dark pill)
 * - Library
 * - Scheduled
 * - Customize
 * - Knights (the 9 agents as a roster)
 * Section "Missions" with "+ New mission", the 4 latest missions, and "All missions".
 * Bottom row: avatar with thin colored ring, user's name with small "PRO" label, and settings gear.
 */
@Composable
fun GeminiDrawerContent(
    currentTab: KnightsTab,
    selectedSquadron: SquadronType,
    hardwareInfo: DeviceHardwareInfo?,
    recentDeliverables: List<Deliverable>,
    activeMemoryCount: Int = 3,
    installedLocalModelsCount: Int = 1,
    userName: String? = null,
    userEmail: String? = null,
    isSignedIn: Boolean = false,
    onNewSessionClick: () -> Unit,
    onCloseDrawer: () -> Unit = {},
    onTabSelected: (KnightsTab) -> Unit,
    onSquadronSelected: (SquadronType) -> Unit,
    onDeliverableSelected: (Deliverable) -> Unit,
    onOpenAuthModal: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var showSearchField by remember { mutableStateOf(false) }
    var missionSearchQuery by remember { mutableStateOf("") }

    val filteredMissions = remember(recentDeliverables, missionSearchQuery) {
        if (missionSearchQuery.isBlank()) {
            recentDeliverables.take(4)
        } else {
            recentDeliverables.filter {
                it.title.contains(missionSearchQuery, ignoreCase = true) ||
                    it.authorKnight.contains(missionSearchQuery, ignoreCase = true)
            }.take(4)
        }
    }

    Surface(
        color = KnightsPureBlack,
        contentColor = Color.White,
        modifier = modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(KnightsPureBlack)
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 20.dp, vertical = 14.dp)
        ) {
            // Top Header: Title "Knights", search icon, close icon
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    KnightsShieldStarMark(size = 26.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Knights",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Normal,
                        color = Color.White
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { showSearchField = !showSearchField },
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("drawer_search_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Search,
                            contentDescription = "Search missions",
                            tint = Color.White
                        )
                    }
                    IconButton(
                        onClick = onCloseDrawer,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("drawer_close_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Close,
                            contentDescription = "Close menu",
                            tint = Color.White
                        )
                    }
                }
            }

            AnimatedVisibility(visible = showSearchField) {
                OutlinedTextField(
                    value = missionSearchQuery,
                    onValueChange = { missionSearchQuery = it },
                    placeholder = { Text("Search missions...", color = KnightsSecondaryGray, fontSize = 14.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GeminiLightBlue,
                        unfocusedBorderColor = GeminiBorder,
                        focusedContainerColor = KnightsCardPill,
                        unfocusedContainerColor = KnightsCardPill,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp, bottom = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // 1. "New chat" (highlighted dark pill #1E1E1E)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 54.dp)
                        .clip(RoundedCornerShape(28.dp))
                        .background(KnightsCardPill)
                        .clickable { onNewSessionClick() }
                        .testTag("drawer_new_mission_button")
                        .padding(horizontal = 18.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.EditNote,
                        contentDescription = "New chat",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = "New chat",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Normal,
                        color = Color.White
                    )
                }

                // 2. "Library"
                DrawerOutlineRow(
                    icon = Icons.Outlined.FolderOpen,
                    label = "Library",
                    selected = currentTab == KnightsTab.LIBRARY,
                    testTag = "drawer_tab_library",
                    onClick = { onTabSelected(KnightsTab.LIBRARY) }
                )

                // 3. "Scheduled"
                DrawerOutlineRow(
                    icon = Icons.Outlined.Schedule,
                    label = "Scheduled",
                    selected = currentTab == KnightsTab.SCHEDULED,
                    testTag = "drawer_tab_scheduled",
                    onClick = { onTabSelected(KnightsTab.SCHEDULED) }
                )

                // 4. "Customize"
                DrawerOutlineRow(
                    icon = Icons.Outlined.Tune,
                    label = "Customize",
                    selected = currentTab == KnightsTab.FORGE,
                    testTag = "drawer_tab_forge",
                    onClick = { onTabSelected(KnightsTab.FORGE) }
                )

                // 5. "Knights" (the 9 agents as a roster)
                DrawerOutlineRow(
                    icon = Icons.Outlined.Groups,
                    label = "Knights",
                    selected = currentTab == KnightsTab.ROSTER,
                    testTag = "drawer_tab_roster",
                    onClick = { onTabSelected(KnightsTab.ROSTER) }
                )

                Spacer(modifier = Modifier.height(18.dp))
                HorizontalDivider(color = GeminiBorder)
                Spacer(modifier = Modifier.height(14.dp))

                // Section "Missions" with "+ New mission", the 4 latest missions, and "All missions"
                Text(
                    text = "Missions",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = KnightsSecondaryGray,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 48.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .clickable { onNewSessionClick() }
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Add,
                        contentDescription = "New mission",
                        tint = GeminiLightBlue,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Text(
                        text = "+ New mission",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Normal,
                        color = GeminiLightBlue
                    )
                }

                filteredMissions.forEach { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 48.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .clickable { onDeliverableSelected(item) }
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Description,
                            contentDescription = null,
                            tint = KnightsSecondaryGray,
                            modifier = Modifier.size(19.dp)
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.title,
                                fontSize = 15.5.sp,
                                fontWeight = FontWeight.Light,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = item.authorKnight,
                                fontSize = 11.5.sp,
                                color = KnightsSecondaryGray
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 48.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .clickable { onTabSelected(KnightsTab.LIBRARY) }
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.AutoAwesomeMotion,
                        contentDescription = "All missions",
                        tint = KnightsSecondaryGray,
                        modifier = Modifier.size(19.dp)
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Text(
                        text = "All missions",
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.Normal,
                        color = KnightsSecondaryGray
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = GeminiBorder)
            Spacer(modifier = Modifier.height(12.dp))

            // Bottom row: avatar with thin colored ring, user's name with small "PRO" or plan label, and settings gear
            val ringGradient = Brush.linearGradient(
                colors = listOf(GeminiLightBlue, GeminiPurple, GeminiRose)
            )
            val resolvedName = userName?.takeIf { it.isNotBlank() } ?: "Commander"
            val initial = resolvedName.firstOrNull()?.uppercaseChar()?.toString() ?: "C"

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(KnightsCardPill)
                    .clickable { onOpenAuthModal() }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(KnightsIconCircle)
                            .border(1.5.dp, ringGradient, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = initial,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = resolvedName,
                                fontSize = 15.5.sp,
                                fontWeight = FontWeight.Normal,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(KnightsChatSendIndigo)
                                    .padding(horizontal = 7.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "PRO",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White
                                )
                            }
                        }
                        Text(
                            text = if (isSignedIn) (userEmail ?: "Cloud Synced") else "Tap to sign in (Google, GitHub, Email, Phone)",
                            fontSize = 11.5.sp,
                            color = KnightsSecondaryGray,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                IconButton(
                    onClick = { onTabSelected(KnightsTab.VAULT) },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("drawer_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Settings,
                        contentDescription = "Settings",
                        tint = KnightsSecondaryGray
                    )
                }
            }
        }
    }
}

@Composable
private fun DrawerOutlineRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 52.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(if (selected) KnightsCardPill.copy(alpha = 0.7f) else Color.Transparent)
            .clickable(onClick = onClick)
            .testTag(testTag)
            .padding(horizontal = 18.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (selected) Color.White else KnightsSecondaryGray,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = label,
            fontSize = 18.sp,
            fontWeight = if (selected) FontWeight.Medium else FontWeight.Light,
            color = Color.White
        )
    }
}
