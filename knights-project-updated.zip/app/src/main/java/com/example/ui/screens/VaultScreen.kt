package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.FilterList
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.SmartDisplay
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AuthProviderType
import com.example.data.model.DEFAULT_GEMINI_MEMORIES
import com.example.data.model.DEFAULT_SCHEDULED_SUGGESTIONS
import com.example.data.model.Deliverable
import com.example.data.model.ScheduledTaskItem
import com.example.data.model.UserMemoryItem
import com.example.ui.theme.GeminiBorder
import com.example.ui.theme.GeminiLightBlue
import com.example.ui.theme.GeminiPurple
import com.example.ui.theme.GeminiRose
import com.example.ui.theme.KnightEmerald
import com.example.ui.theme.KnightsCardPill
import com.example.ui.theme.KnightsChatSendIndigo
import com.example.ui.theme.KnightsIconCircle
import com.example.ui.theme.KnightsPureBlack
import com.example.ui.theme.KnightsSecondaryGray

/**
 * Prompt D: Library Screen
 * - "Documents" section with rounded cards (icon, title, date in gray) for saved agent outputs
 * - "Media" section as a 3-column grid of dark tiles
 * - Supports full offline browsing of saved results
 */
@Composable
fun LibraryScreen(
    deliverables: List<Deliverable>,
    searchQuery: String,
    onSearchChanged: (String) -> Unit,
    onDeleteDeliverable: (Deliverable) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val mediaTiles = listOf(
        Triple("YT Thumbnail Frame", "Sir Tristan • 16:9", Icons.Outlined.SmartDisplay),
        Triple("Architecture Graph", "Sir Lancelot • SVG", Icons.Outlined.Image),
        Triple("Retention Heatmap", "Sir Gawain • Chart", Icons.Outlined.SmartDisplay),
        Triple("Funnel Blueprint", "Sir Percivale • Flow", Icons.Outlined.Image),
        Triple("Storyboard Deck", "Sir Bors • 5 Scenes", Icons.Outlined.SmartDisplay),
        Triple("Audit Matrix", "Sir Bedivere • Card", Icons.Outlined.Image)
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(KnightsPureBlack)
            .verticalScroll(scrollState)
            .padding(horizontal = 8.dp, vertical = 8.dp)
    ) {
        Text(
            text = "Library",
            fontSize = 34.sp,
            fontWeight = FontWeight.Light,
            color = Color.White,
            modifier = Modifier.testTag("library_screen_title")
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Saved agent documents and visual media assets available offline",
            fontSize = 14.sp,
            color = KnightsSecondaryGray
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChanged,
            placeholder = { Text("Search documents...", color = KnightsSecondaryGray, fontSize = 14.sp) },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Outlined.Search,
                    contentDescription = "Search",
                    tint = KnightsSecondaryGray,
                    modifier = Modifier.size(20.dp)
                )
            },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GeminiLightBlue,
                unfocusedBorderColor = GeminiBorder,
                focusedContainerColor = KnightsCardPill,
                unfocusedContainerColor = KnightsCardPill,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("vault_search_input")
        )

        Spacer(modifier = Modifier.height(22.dp))

        // 1. "Documents" section with rounded cards (icon, title, date in gray)
        Text(
            text = "Documents",
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
            color = KnightsSecondaryGray
        )

        Spacer(modifier = Modifier.height(12.dp))

        if (deliverables.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(KnightsCardPill)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (searchQuery.isBlank()) "No saved documents yet." else "No documents match \"$searchQuery\".",
                    fontSize = 14.sp,
                    color = KnightsSecondaryGray
                )
            }
        } else {
            deliverables.forEach { item ->
                DeliverableVaultCard(
                    deliverable = item,
                    onCopy = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText(item.title, item.content))
                        Toast.makeText(context, "Copied \"${item.title}\"", Toast.LENGTH_SHORT).show()
                    },
                    onShare = {
                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, item.content)
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "Share ${item.title}"))
                    },
                    onDelete = { onDeleteDeliverable(item) }
                )
                Spacer(modifier = Modifier.height(10.dp))
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 2. "Media" section as a 3-column grid of dark tiles
        Text(
            text = "Media",
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
            color = KnightsSecondaryGray
        )

        Spacer(modifier = Modifier.height(12.dp))

        val rows = mediaTiles.chunked(3)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("library_media_grid"),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            rows.forEach { rowItems ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    rowItems.forEach { (title, subtitle, icon) ->
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(22.dp))
                                .background(KnightsCardPill)
                                .padding(12.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(KnightsIconCircle),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = title,
                                    tint = GeminiLightBlue,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = title,
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.Normal,
                                    color = Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = subtitle,
                                    fontSize = 10.5.sp,
                                    color = KnightsSecondaryGray,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))
    }
}

/**
 * Prompt D: Scheduled Screen
 * - Centered title, a filter icon on the right
 * - A gray sentence with a dotted-underlined "Learn more"
 * - A "Suggested" label
 * - Tall rounded cards (title and one-line description) such as "Weekly YouTube trend report" and "Daily research digest"
 * - Tapping one schedules a recurring task
 */
@Composable
fun ScheduledScreen(
    scheduledTasks: List<ScheduledTaskItem> = DEFAULT_SCHEDULED_SUGGESTIONS,
    onToggleSchedule: (String) -> Unit = {},
    onRunNow: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var showOnlyActive by remember { mutableStateOf(false) }
    var showLearnMoreNote by remember { mutableStateOf(false) }

    val displayedTasks = remember(scheduledTasks, showOnlyActive) {
        if (showOnlyActive) scheduledTasks.filter { it.isScheduled } else scheduledTasks
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(KnightsPureBlack)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 8.dp, vertical = 8.dp)
    ) {
        // Top header: centered title "Scheduled", filter icon on the right
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        ) {
            Text(
                text = "Scheduled",
                fontSize = 24.sp,
                fontWeight = FontWeight.Normal,
                color = Color.White,
                modifier = Modifier
                    .align(Alignment.Center)
                    .testTag("scheduled_screen_title")
            )
            IconButton(
                onClick = { showOnlyActive = !showOnlyActive },
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .size(48.dp)
                    .testTag("scheduled_filter_button")
            ) {
                Icon(
                    imageVector = Icons.Outlined.FilterList,
                    contentDescription = "Filter scheduled tasks",
                    tint = if (showOnlyActive) GeminiLightBlue else Color.White
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Gray sentence with a dotted-underlined "Learn more"
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Automate recurring multi-agent missions on your schedule.",
                fontSize = 14.5.sp,
                color = KnightsSecondaryGray,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.clickable { showLearnMoreNote = !showLearnMoreNote }
            ) {
                Text(
                    text = "Learn more",
                    fontSize = 14.sp,
                    color = KnightsSecondaryGray
                )
                Canvas(
                    modifier = Modifier
                        .width(74.dp)
                        .height(2.dp)
                ) {
                    drawLine(
                        color = KnightsSecondaryGray,
                        start = Offset(0f, 0f),
                        end = Offset(size.width, 0f),
                        strokeWidth = 2f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(5f, 5f), 0f)
                    )
                }
            }
        }

        AnimatedVisibility(visible = showLearnMoreNote) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(KnightsCardPill)
                    .padding(14.dp)
            ) {
                Text(
                    text = "Scheduled tasks dispatch all 9 Knights automatically and save deliverables directly to your Library.",
                    fontSize = 13.sp,
                    color = KnightsSecondaryGray
                )
            }
        }

        Spacer(modifier = Modifier.height(26.dp))

        // "Suggested" label
        Text(
            text = if (showOnlyActive) "Active Schedules" else "Suggested",
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            color = KnightsSecondaryGray,
            modifier = Modifier.padding(horizontal = 4.dp)
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Tall rounded cards (title and one-line description) such as "Weekly YouTube trend report" and "Daily research digest"
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            displayedTasks.forEach { task ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 148.dp)
                        .clip(RoundedCornerShape(28.dp))
                        .background(KnightsCardPill)
                        .border(
                            width = 1.dp,
                            color = if (task.isScheduled) GeminiLightBlue.copy(alpha = 0.5f) else Color.Transparent,
                            shape = RoundedCornerShape(28.dp)
                        )
                        .clickable { onToggleSchedule(task.id) }
                        .testTag("scheduled_card_${task.id}")
                        .padding(20.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Outlined.Schedule,
                                    contentDescription = null,
                                    tint = if (task.isScheduled) KnightEmerald else KnightsSecondaryGray,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = task.cadence,
                                    fontSize = 12.5.sp,
                                    color = if (task.isScheduled) KnightEmerald else KnightsSecondaryGray
                                )
                            }

                            if (task.isScheduled) {
                                Icon(
                                    imageVector = Icons.Outlined.CheckCircle,
                                    contentDescription = "Scheduled",
                                    tint = KnightEmerald,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = task.title,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Normal,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = task.description,
                            fontSize = 14.sp,
                            color = KnightsSecondaryGray,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (task.isScheduled) "Scheduled • Tap to pause" else "Tap card to schedule recurring task",
                            fontSize = 12.5.sp,
                            color = if (task.isScheduled) GeminiLightBlue else KnightsSecondaryGray
                        )

                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(18.dp))
                                .background(KnightsPureBlack)
                                .clickable { onRunNow(task.id) }
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.PlayArrow,
                                contentDescription = "Run now",
                                tint = GeminiLightBlue,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Run now",
                                fontSize = 12.sp,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))
    }
}

/**
 * Settings, Multi-Provider Login, Saved Info Memory & Engine Configuration Screen
 */
@Composable
fun VaultScreen(
    deliverables: List<Deliverable>,
    searchQuery: String,
    onSearchChanged: (String) -> Unit,
    onDeleteDeliverable: (Deliverable) -> Unit,
    apiKey: String,
    modelName: String,
    commanderPrefs: String,
    onSaveSettings: (key: String, model: String, prefs: String) -> Unit,
    memories: List<UserMemoryItem> = DEFAULT_GEMINI_MEMORIES,
    isGlobalMemoryEnabled: Boolean = true,
    onToggleGlobalMemory: (Boolean) -> Unit = {},
    onAddMemory: (content: String, category: String) -> Unit = { _, _ -> },
    onToggleMemoryItem: (String) -> Unit = {},
    onDeleteMemoryItem: (String) -> Unit = {},
    currentUserId: String? = null,
    currentUserEmail: String? = null,
    currentUserName: String? = null,
    authProvider: AuthProviderType = AuthProviderType.NONE,
    onMultiProviderLogin: (AuthProviderType, String, String, String?) -> Unit = { _, _, _, _ -> },
    onSignOut: () -> Unit = {},
    onAuthChanged: () -> Unit = {},
    onShowMessage: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    var keyInput by remember(apiKey) { mutableStateOf(apiKey) }
    var modelInput by remember(modelName) { mutableStateOf(modelName) }
    var prefsInput by remember(commanderPrefs) { mutableStateOf(commanderPrefs) }

    var newMemoryText by remember { mutableStateOf("") }
    var selectedMemoryCategory by remember { mutableStateOf("Preference") }
    val memoryCategories = listOf("Preference", "Coding Style", "Agent Behavior", "Output Format", "Personal Context")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(KnightsPureBlack)
            .verticalScroll(scrollState)
            .padding(horizontal = 8.dp, vertical = 8.dp)
    ) {
        Text(
            text = "Account & Settings",
            fontSize = 34.sp,
            fontWeight = FontWeight.Light,
            color = Color.White
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Sign in with Google, GitHub, Email, or Phone, and manage Knights memory & engine settings.",
            fontSize = 14.sp,
            color = KnightsSecondaryGray
        )

        Spacer(modifier = Modifier.height(20.dp))

        // 1. MULTI-PROVIDER LOGIN & CLOUD SYNC (Google, GitHub, Email, Phone Number)
        GoogleCloudSyncCard(
            userId = currentUserId,
            userEmail = currentUserEmail,
            userName = currentUserName,
            authProvider = authProvider,
            onAuthChanged = onAuthChanged,
            onShowMessage = onShowMessage,
            onMultiProviderLogin = onMultiProviderLogin,
            onSignOut = onSignOut
        )

        Spacer(modifier = Modifier.height(24.dp))

        // 2. SAVED INFO (MEMORY SETTINGS)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(
                    imageVector = Icons.Outlined.Psychology,
                    contentDescription = null,
                    tint = GeminiLightBlue,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Saved info (Memory)",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Normal,
                        color = Color.White
                    )
                    Text(
                        text = "All 9 Knights remember your standing preferences across every session.",
                        fontSize = 12.5.sp,
                        color = KnightsSecondaryGray
                    )
                }
            }
            Switch(
                checked = isGlobalMemoryEnabled,
                onCheckedChange = onToggleGlobalMemory,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = KnightsPureBlack,
                    checkedTrackColor = GeminiLightBlue,
                    uncheckedThumbColor = KnightsSecondaryGray,
                    uncheckedTrackColor = KnightsCardPill
                ),
                modifier = Modifier.testTag("global_memory_switch")
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(KnightsCardPill)
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                memoryCategories.forEach { cat ->
                    val active = selectedMemoryCategory == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (active) KnightsChatSendIndigo else KnightsPureBlack)
                            .clickable { selectedMemoryCategory = cat }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = cat,
                            fontSize = 11.5.sp,
                            fontWeight = if (active) FontWeight.Medium else FontWeight.Normal,
                            color = if (active) Color.White else KnightsSecondaryGray
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = newMemoryText,
                    onValueChange = { newMemoryText = it },
                    placeholder = {
                        Text(
                            "Remember a preference or rule...",
                            color = KnightsSecondaryGray,
                            fontSize = 13.sp
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GeminiLightBlue,
                        unfocusedBorderColor = GeminiBorder,
                        focusedContainerColor = KnightsPureBlack,
                        unfocusedContainerColor = KnightsPureBlack,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("memory_input_field")
                )

                Spacer(modifier = Modifier.width(8.dp))

                Row(
                    modifier = Modifier
                        .defaultMinSize(minHeight = 48.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(KnightsChatSendIndigo)
                        .clickable {
                            onAddMemory(newMemoryText, selectedMemoryCategory)
                            newMemoryText = ""
                        }
                        .testTag("add_memory_button")
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Add,
                        contentDescription = "Add memory",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Add",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            memories.forEach { mem ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(KnightsPureBlack)
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = mem.category,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = GeminiLightBlue
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = mem.content,
                            fontSize = 13.sp,
                            color = if (mem.isEnabled && isGlobalMemoryEnabled) Color.White else KnightsSecondaryGray,
                            lineHeight = 17.sp
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(
                            checked = mem.isEnabled,
                            onCheckedChange = { onToggleMemoryItem(mem.id) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = KnightsPureBlack,
                                checkedTrackColor = KnightEmerald,
                                uncheckedThumbColor = KnightsSecondaryGray,
                                uncheckedTrackColor = KnightsCardPill
                            )
                        )
                        IconButton(
                            onClick = { onDeleteMemoryItem(mem.id) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Delete,
                                contentDescription = "Delete memory",
                                tint = KnightsSecondaryGray,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 3. ENGINE & STANDING DIRECTIVES
        Text(
            text = "Knights Engine & Standing Directives",
            fontSize = 18.sp,
            fontWeight = FontWeight.Normal,
            color = Color.White
        )
        Spacer(modifier = Modifier.height(10.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(KnightsCardPill)
                .padding(18.dp)
        ) {
            Text(
                text = "Cloud API Key (Optional override):",
                fontSize = 12.5.sp,
                color = KnightsSecondaryGray
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = keyInput,
                onValueChange = { keyInput = it },
                placeholder = { Text("Leave blank for built-in Cloud + Local AI Engine", color = KnightsSecondaryGray, fontSize = 13.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GeminiLightBlue,
                    unfocusedBorderColor = GeminiBorder,
                    focusedContainerColor = KnightsPureBlack,
                    unfocusedContainerColor = KnightsPureBlack,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("gemini_api_key_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Default Model Identifier:",
                fontSize = 12.5.sp,
                color = KnightsSecondaryGray
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = modelInput,
                onValueChange = { modelInput = it },
                placeholder = { Text("auto (latest Flash)", color = KnightsSecondaryGray, fontSize = 13.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GeminiLightBlue,
                    unfocusedBorderColor = GeminiBorder,
                    focusedContainerColor = KnightsPureBlack,
                    unfocusedContainerColor = KnightsPureBlack,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Global System Directive:",
                fontSize = 12.5.sp,
                color = KnightsSecondaryGray
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = prefsInput,
                onValueChange = { prefsInput = it },
                placeholder = { Text("Clean, minimal, high-precision, zero fluff.", color = KnightsSecondaryGray, fontSize = 13.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GeminiLightBlue,
                    unfocusedBorderColor = GeminiBorder,
                    focusedContainerColor = KnightsPureBlack,
                    unfocusedContainerColor = KnightsPureBlack,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 48.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(KnightsChatSendIndigo)
                    .clickable { onSaveSettings(keyInput, modelInput, prefsInput) }
                    .testTag("save_settings_button")
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Save Engine Settings",
                    fontWeight = FontWeight.Medium,
                    color = Color.White,
                    fontSize = 14.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))
    }
}

@Composable
fun DeliverableVaultCard(
    deliverable: Deliverable,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    var isExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(KnightsCardPill)
            .clickable { isExpanded = !isExpanded }
            .padding(18.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(KnightsIconCircle),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Description,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column {
                    Text(
                        text = deliverable.title,
                        fontWeight = FontWeight.Normal,
                        fontSize = 16.sp,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${deliverable.authorKnight} • ${deliverable.formattedDate}",
                        fontSize = 12.sp,
                        color = KnightsSecondaryGray
                    )
                }
            }

            Row {
                IconButton(onClick = onCopy, modifier = Modifier.size(40.dp)) {
                    Icon(
                        imageVector = Icons.Outlined.ContentCopy,
                        contentDescription = "Copy",
                        tint = KnightsSecondaryGray,
                        modifier = Modifier.size(18.dp)
                    )
                }
                IconButton(onClick = onShare, modifier = Modifier.size(40.dp)) {
                    Icon(
                        imageVector = Icons.Outlined.Share,
                        contentDescription = "Share",
                        tint = KnightsSecondaryGray,
                        modifier = Modifier.size(18.dp)
                    )
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(40.dp)) {
                    Icon(
                        imageVector = Icons.Outlined.Delete,
                        contentDescription = "Delete",
                        tint = GeminiRose,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        if (isExpanded) {
            Spacer(modifier = Modifier.height(12.dp))
            SelectionContainer {
                Text(
                    text = deliverable.content,
                    fontSize = 13.sp,
                    lineHeight = 19.sp,
                    color = Color(0xFFE3E3E3),
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
