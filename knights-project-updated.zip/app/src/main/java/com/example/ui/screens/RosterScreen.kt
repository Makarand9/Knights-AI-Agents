package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ViewList
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.SmartDisplay
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DEFAULT_LOCAL_AI_MODELS
import com.example.data.model.KnightAgent
import com.example.data.model.KnightExecutionState
import com.example.ui.theme.GeminiBorder
import com.example.ui.theme.GeminiLightBlue
import com.example.ui.theme.GeminiPurple
import com.example.ui.theme.KnightEmerald
import com.example.ui.theme.KnightsCardPill
import com.example.ui.theme.KnightsChatSendIndigo
import com.example.ui.theme.KnightsIconCircle
import com.example.ui.theme.KnightsPureBlack
import com.example.ui.theme.KnightsSecondaryGray

@Composable
fun RosterScreen(
    knights: List<KnightAgent>,
    executionStates: Map<String, KnightExecutionState> = emptyMap(),
    isGridView: Boolean = true,
    onSelectKnightSolo: (String) -> Unit,
    onTriggerTaskForKnight: (String) -> Unit = { onSelectKnightSolo(it) },
    onCustomizeKnight: (String) -> Unit = {},
    onToggleInternetForKnight: (String) -> Unit = {},
    onToggleGridList: () -> Unit = {},
    onOpenYouTubeLab: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(KnightsPureBlack)
            .padding(horizontal = 8.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Knights",
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Light,
                    color = Color.White,
                    modifier = Modifier.testTag("knights_roster_title")
                )
                Text(
                    text = "9 autonomous agents with live web & on-device Local AI",
                    fontSize = 14.sp,
                    color = KnightsSecondaryGray
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .defaultMinSize(minHeight = 42.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(KnightsCardPill)
                        .clickable { onOpenYouTubeLab() }
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.SmartDisplay,
                        contentDescription = "YouTube Lab",
                        tint = GeminiLightBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "YT Lab",
                        fontSize = 13.sp,
                        color = Color.White
                    )
                }

                IconButton(
                    onClick = onToggleGridList,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(KnightsCardPill)
                        .testTag("toggle_grid_list_button")
                ) {
                    Icon(
                        imageVector = if (isGridView) Icons.AutoMirrored.Outlined.ViewList else Icons.Outlined.GridView,
                        contentDescription = "Switch layout",
                        tint = Color.White
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (isGridView) {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 165.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(knights) { knight ->
                    KnightCard(
                        knight = knight,
                        execState = executionStates[knight.id],
                        onDeploySolo = { onSelectKnightSolo(knight.id) },
                        onTriggerTask = { onTriggerTaskForKnight(knight.id) },
                        onCustomize = { onCustomizeKnight(knight.id) },
                        onToggleInternet = { onToggleInternetForKnight(knight.id) }
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(knights) { knight ->
                    KnightCard(
                        knight = knight,
                        execState = executionStates[knight.id],
                        onDeploySolo = { onSelectKnightSolo(knight.id) },
                        onTriggerTask = { onTriggerTaskForKnight(knight.id) },
                        onCustomize = { onCustomizeKnight(knight.id) },
                        onToggleInternet = { onToggleInternetForKnight(knight.id) }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun KnightCard(
    knight: KnightAgent,
    execState: KnightExecutionState? = null,
    onDeploySolo: () -> Unit,
    onTriggerTask: () -> Unit = onDeploySolo,
    onCustomize: () -> Unit = {},
    onToggleInternet: () -> Unit = {}
) {
    val localModelName = DEFAULT_LOCAL_AI_MODELS.find { it.id == knight.localModelId }?.name ?: "Cloud Only"

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 200.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(KnightsCardPill)
            .clickable(onClick = onCustomize)
            .padding(16.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(KnightsIconCircle),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${knight.orderNumber}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = GeminiLightBlue
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    AgentVisualStatusIndicator(execState = execState, compact = true)
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(
                        onClick = onCustomize,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("roster_customize_${knight.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Tune,
                            contentDescription = "Customize Agent",
                            tint = KnightsSecondaryGray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = knight.codename,
                fontWeight = FontWeight.Normal,
                fontSize = 16.sp,
                color = Color.White,
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = knight.description,
                fontSize = 12.5.sp,
                color = KnightsSecondaryGray,
                lineHeight = 17.sp,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(10.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(KnightsPureBlack)
                        .clickable { onToggleInternet() }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Language,
                        contentDescription = null,
                        tint = if (knight.internetEnabled) KnightEmerald else KnightsSecondaryGray,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (knight.internetEnabled) "Web ON" else "Web OFF",
                        fontSize = 10.5.sp,
                        color = if (knight.internetEnabled) KnightEmerald else KnightsSecondaryGray
                    )
                }

                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(KnightsPureBlack)
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Memory,
                        contentDescription = null,
                        tint = GeminiPurple,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = localModelName,
                        fontSize = 10.5.sp,
                        color = KnightsSecondaryGray,
                        maxLines = 1
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 42.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(KnightsChatSendIndigo)
                    .clickable(onClick = onTriggerTask)
                    .testTag("roster_trigger_task_${knight.id}")
                    .padding(vertical = 9.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Outlined.PlayArrow,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                    text = "Run Task",
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White
                )
            }
        }
    }
}
