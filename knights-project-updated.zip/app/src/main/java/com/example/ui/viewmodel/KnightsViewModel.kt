package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.KnightsPreferences
import com.example.data.model.AgentStatus
import com.example.data.model.AgentTaskExecutionRecord
import com.example.data.model.AgentTaskRecordDoc
import com.example.data.model.AuthProviderType
import com.example.data.model.ConnectorItem
import com.example.data.model.CustomAgentConfigDoc
import com.example.data.model.DEFAULT_CONNECTORS
import com.example.data.model.DEFAULT_GEMINI_MEMORIES
import com.example.data.model.DEFAULT_INSTALLED_SKILLS
import com.example.data.model.DEFAULT_LOCAL_AI_MODELS
import com.example.data.model.DEFAULT_SCHEDULED_SUGGESTIONS
import com.example.data.model.DEFAULT_SKILL_PACKS
import com.example.data.model.DefaultKnightsOrder
import com.example.data.model.Deliverable
import com.example.data.model.DeviceHardwareInfo
import com.example.data.model.InstalledSkillItem
import com.example.data.model.KnightAgent
import com.example.data.model.KnightExecutionState
import com.example.data.model.LocalAiModel
import com.example.data.model.LogLevel
import com.example.data.model.ScheduledTaskItem
import com.example.data.model.SkillPackItem
import com.example.data.model.SquadronType
import com.example.data.model.TerminalLog
import com.example.data.model.TerminalMode
import com.example.data.model.UserMemoryItem
import com.example.data.model.UserMemoryItemDoc
import com.example.data.model.YouTubeFunnelParams
import com.example.data.repository.KnightsFirestoreRepository
import com.example.data.repository.KnightsRepository
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class KnightsTab(val label: String, val icon: String) {
    TERMINAL("Home", "✦"),
    LIBRARY("Library", "◎"),
    SCHEDULED("Scheduled", "◷"),
    FORGE("Customize", "❖"),
    ROSTER("Knights", "◇"),
    YT_LAB("Growth", "▷"),
    VAULT("Settings", "⚙")
}

data class KnightsUiState(
    val currentTab: KnightsTab = KnightsTab.TERMINAL,
    val commandInput: String = "",
    val isTaskMode: Boolean = false,
    val isTemporaryChat: Boolean = false,
    val selectedSquadron: SquadronType = SquadronType.GRAND_COMMANDER,
    val selectedSoloKnightId: String? = "knight_1_scout",
    val isMissionRunning: Boolean = false,
    val terminalLogs: List<TerminalLog> = emptyList(),
    val terminalMode: TerminalMode = TerminalMode.CLI_STREAM,
    val agentExecutionStates: Map<String, KnightExecutionState> = emptyMap(),
    val lastDeliverable: Deliverable? = null,
    val deviceHardwareInfo: DeviceHardwareInfo? = null,
    val allKnights: List<KnightAgent> = DefaultKnightsOrder.ALL_9_KNIGHTS,
    val localAiModels: List<LocalAiModel> = DEFAULT_LOCAL_AI_MODELS,
    val memories: List<UserMemoryItem> = DEFAULT_GEMINI_MEMORIES,
    val isGlobalMemoryEnabled: Boolean = true,
    val recentAgentTasks: List<AgentTaskExecutionRecord> = emptyList(),
    val ytParams: YouTubeFunnelParams = YouTubeFunnelParams(),
    val vaultDeliverables: List<Deliverable> = emptyList(),
    val vaultSearchQuery: String = "",
    val apiKey: String = "",
    val activeModel: String = "auto",
    val commanderPrefs: String = "",
    val blueprintJson: String = "",
    val snackbarMessage: String? = null,
    val isAgentGridView: Boolean = true,
    val squadronFilter: String = "all",
    val showTerminalConsole: Boolean = false,
    val inspectedKnightId: String? = null,
    val customizingKnightId: String? = null,
    val currentUserId: String? = null,
    val currentUserEmail: String? = null,
    val currentUserName: String? = null,
    val authProvider: AuthProviderType = AuthProviderType.NONE,
    val showAuthModal: Boolean = false,
    val customizeSubTab: String = "Discover",
    val skillPacks: List<SkillPackItem> = DEFAULT_SKILL_PACKS,
    val installedSkills: List<InstalledSkillItem> = DEFAULT_INSTALLED_SKILLS,
    val connectors: List<ConnectorItem> = DEFAULT_CONNECTORS,
    val skillDraftName: String? = null,
    val skillDraftMarkdown: String? = null,
    val scheduledTasks: List<ScheduledTaskItem> = DEFAULT_SCHEDULED_SUGGESTIONS
)

class KnightsViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = KnightsRepository(application)
    private val prefs = KnightsPreferences(application)
    private val firestoreRepository: KnightsFirestoreRepository? = try {
        KnightsFirestoreRepository(application)
    } catch (_: Exception) {
        null
    }

    private val _uiState = MutableStateFlow(KnightsUiState())
    val uiState: StateFlow<KnightsUiState> = _uiState.asStateFlow()

    private var firestoreAgentsJob: Job? = null
    private var firestoreMemoriesJob: Job? = null

    init {
        loadInitialData()
        observeTerminalLogs()
        observeVaultDeliverables()
        refreshAuthState()
    }

    private fun loadInitialData() {
        viewModelScope.launch {
            repository.seedInitialWelcomeDeliverableIfNeeded()
            val hw = repository.getDeviceHardwareInfo()
            val agents = repository.getAllKnights()
            val installedIds = repository.getInstalledLocalModelIds()
            val localModels = DEFAULT_LOCAL_AI_MODELS.map { m ->
                val installed = installedIds.contains(m.id)
                m.copy(
                    isInstalled = installed,
                    installProgress = if (installed) 1f else 0f
                )
            }
            val memories = repository.getMemories()
            val globalMem = repository.isGlobalMemoryEnabled()
            val key = repository.getApiKey()
            val model = repository.getActiveModel().let {
                if (it.startsWith("gemini-2.5") || it == "gemini-3.5-flash") "auto" else it
            }
            val commanderPrefs = repository.getCommanderPrefs()
            val blueprint = generateBlueprintJson(agents)
            val savedPackIds = prefs.installedSkillPacksCsv.split(",").map { it.trim() }.toSet()
            val packs = DEFAULT_SKILL_PACKS.map { p -> p.copy(isAdded = savedPackIds.contains(p.id)) }

            _uiState.update {
                it.copy(
                    deviceHardwareInfo = hw,
                    allKnights = agents,
                    localAiModels = localModels,
                    memories = memories,
                    isGlobalMemoryEnabled = globalMem,
                    apiKey = key,
                    activeModel = model,
                    commanderPrefs = commanderPrefs,
                    blueprintJson = blueprint,
                    skillPacks = packs
                )
            }

            addLog(
                TerminalLog(
                    level = LogLevel.SYS,
                    message = "KNIGHTS OS v3.5 // 9 AUTONOMOUS MULTI-DOMAIN AGENTS READY"
                )
            )
            addLog(
                TerminalLog(
                    level = LogLevel.INFO,
                    message = "Engine: $model • Telemetry: ${hw.telemetrySummary} • Local AI: ${installedIds.size} model(s)"
                )
            )
        }
    }

    fun refreshAuthState() {
        val firebaseUser = try {
            Firebase.auth.currentUser
        } catch (_: Exception) {
            null
        }

        if (firebaseUser != null) {
            val providerId = firebaseUser.providerData.firstOrNull { it.providerId != "firebase" }?.providerId ?: ""
            val resolvedProvider = when {
                providerId.contains("github", ignoreCase = true) -> AuthProviderType.GITHUB
                providerId.contains("phone", ignoreCase = true) -> AuthProviderType.PHONE
                providerId.contains("password", ignoreCase = true) -> AuthProviderType.EMAIL
                else -> AuthProviderType.GOOGLE
            }
            val resolvedName = firebaseUser.displayName?.takeIf { it.isNotBlank() }
                ?: prefs.authDisplayName.takeIf { it.isNotBlank() }
                ?: "Commander"
            val resolvedEmail = firebaseUser.email?.takeIf { it.isNotBlank() }
                ?: firebaseUser.phoneNumber?.takeIf { it.isNotBlank() }
                ?: prefs.authIdentifier.takeIf { it.isNotBlank() }
                ?: "Connected"

            prefs.authProvider = resolvedProvider.name
            prefs.authDisplayName = resolvedName
            prefs.authIdentifier = resolvedEmail

            _uiState.update {
                it.copy(
                    currentUserId = firebaseUser.uid,
                    currentUserEmail = resolvedEmail,
                    currentUserName = resolvedName,
                    authProvider = resolvedProvider
                )
            }
            startFirestoreSync(firebaseUser.uid)
        } else if (prefs.authProvider.isNotBlank() && prefs.authIdentifier.isNotBlank()) {
            val savedProvider = try {
                AuthProviderType.valueOf(prefs.authProvider)
            } catch (_: Exception) {
                AuthProviderType.EMAIL
            }
            _uiState.update {
                it.copy(
                    currentUserId = "local_${prefs.authIdentifier.hashCode().toUInt()}",
                    currentUserEmail = prefs.authIdentifier,
                    currentUserName = prefs.authDisplayName.ifBlank { "Commander" },
                    authProvider = savedProvider
                )
            }
        } else {
            _uiState.update {
                it.copy(
                    currentUserId = null,
                    currentUserEmail = null,
                    currentUserName = null,
                    authProvider = AuthProviderType.NONE
                )
            }
            firestoreAgentsJob?.cancel()
            firestoreMemoriesJob?.cancel()
        }
    }

    fun completeMultiProviderLogin(
        provider: AuthProviderType,
        displayName: String,
        identifier: String,
        firebaseUid: String? = null
    ) {
        val cleanName = displayName.trim().ifBlank {
            identifier.substringBefore("@").ifBlank { "Commander" }
        }
        val cleanId = identifier.trim()
        prefs.authProvider = provider.name
        prefs.authDisplayName = cleanName
        prefs.authIdentifier = cleanId

        val uid = firebaseUid ?: Firebase.auth.currentUser?.uid ?: "auth_${cleanId.hashCode().toUInt()}"
        _uiState.update {
            it.copy(
                currentUserId = uid,
                currentUserName = cleanName,
                currentUserEmail = cleanId,
                authProvider = provider,
                showAuthModal = false
            )
        }
        if (Firebase.auth.currentUser != null) {
            startFirestoreSync(Firebase.auth.currentUser!!.uid)
        }
        showSnackbar("Signed in with ${provider.label} as $cleanName")
    }

    fun signOutAllProviders() {
        try {
            Firebase.auth.signOut()
        } catch (_: Exception) {
        }
        prefs.authProvider = ""
        prefs.authDisplayName = ""
        prefs.authIdentifier = ""
        firestoreAgentsJob?.cancel()
        firestoreMemoriesJob?.cancel()
        _uiState.update {
            it.copy(
                currentUserId = null,
                currentUserEmail = null,
                currentUserName = null,
                authProvider = AuthProviderType.NONE
            )
        }
        showSnackbar("Signed out")
    }

    fun setShowAuthModal(show: Boolean) {
        _uiState.update { it.copy(showAuthModal = show) }
    }

    fun setTaskMode(isTask: Boolean) {
        _uiState.update { state ->
            state.copy(
                isTaskMode = isTask,
                selectedSquadron = if (isTask) {
                    SquadronType.GRAND_ORDER
                } else {
                    SquadronType.SOLO_KNIGHT
                },
                selectedSoloKnightId = state.selectedSoloKnightId ?: "knight_1_scout"
            )
        }
    }

    fun toggleTemporaryChat() {
        val next = !_uiState.value.isTemporaryChat
        _uiState.update { it.copy(isTemporaryChat = next) }
        showSnackbar(
            if (next) "Temporary chat active — chats won't be saved to Library"
            else "Standard chat active — outputs saved to Library"
        )
    }

    fun setCustomizeSubTab(tab: String) {
        _uiState.update { it.copy(customizeSubTab = tab) }
    }

    fun toggleSkillPack(packId: String) {
        val updated = _uiState.value.skillPacks.map { pack ->
            if (pack.id == packId) pack.copy(isAdded = !pack.isAdded) else pack
        }
        val addedIds = updated.filter { it.isAdded }.joinToString(",") { it.id }
        prefs.installedSkillPacksCsv = addedIds
        val target = updated.find { it.id == packId }
        _uiState.update { it.copy(skillPacks = updated) }
        if (target != null) {
            showSnackbar(if (target.isAdded) "Added ${target.title} pack" else "Removed ${target.title} pack")
        }
    }

    fun addConnector(name: String, type: String, url: String) {
        val cleanUrl = url.trim()
        if (cleanUrl.isBlank()) {
            showSnackbar("Enter a valid OpenAPI or MCP Server URL")
            return
        }
        val cleanName = name.trim().ifBlank {
            if (type == "MCP Server") "Custom MCP Server" else "Custom OpenAPI Spec"
        }
        val item = ConnectorItem(
            id = "conn_${UUID.randomUUID().toString().take(6)}",
            name = cleanName,
            type = type,
            endpointUrl = cleanUrl,
            isConnected = true
        )
        _uiState.update { it.copy(connectors = listOf(item) + it.connectors) }
        showSnackbar("Connected $cleanName ($type)")
    }

    fun removeConnector(connectorId: String) {
        _uiState.update { state ->
            state.copy(connectors = state.connectors.filterNot { it.id == connectorId })
        }
        showSnackbar("Connector removed")
    }

    fun toggleInstalledSkill(skillId: String) {
        _uiState.update { state ->
            state.copy(
                installedSkills = state.installedSkills.map { s ->
                    if (s.id == skillId) s.copy(isEnabled = !s.isEnabled) else s
                }
            )
        }
    }

    fun importSkillFromGithubUrl(url: String) {
        val cleanUrl = url.trim()
        if (cleanUrl.isBlank()) {
            showSnackbar("Enter a GitHub repository or SKILL.md URL")
            return
        }
        val slug = cleanUrl.trimEnd('/').substringAfterLast('/').removeSuffix(".md").ifBlank { "github-skill" }
        val newSkill = InstalledSkillItem(
            id = "skill_${UUID.randomUUID().toString().take(6)}",
            name = slug.lowercase(),
            source = "GitHub • $cleanUrl",
            markdownContent = "---\nname: ${slug.lowercase()}\nsource: $cleanUrl\n---\nImported autonomous skill instructions from GitHub.",
            isEnabled = true
        )
        _uiState.update { it.copy(installedSkills = listOf(newSkill) + it.installedSkills) }
        showSnackbar("Imported skill '${newSkill.name}' from GitHub")
    }

    fun pasteSkillMarkdown(name: String, markdown: String) {
        val cleanMd = markdown.trim()
        if (cleanMd.isBlank()) {
            showSnackbar("Paste valid SKILL.md content")
            return
        }
        val resolvedName = name.trim().ifBlank { "custom-skill-${_uiState.value.installedSkills.size + 1}" }
        val newSkill = InstalledSkillItem(
            id = "skill_${UUID.randomUUID().toString().take(6)}",
            name = resolvedName.lowercase().replace(" ", "-"),
            source = "Pasted SKILL.md",
            markdownContent = cleanMd,
            isEnabled = true
        )
        _uiState.update { it.copy(installedSkills = listOf(newSkill) + it.installedSkills) }
        showSnackbar("Saved '${newSkill.name}' to Skills")
    }

    fun draftSkillWithPrompt(prompt: String) {
        val cleanPrompt = prompt.trim()
        if (cleanPrompt.isBlank()) {
            showSnackbar("Describe the skill you want the Skill Smith agent to build")
            return
        }
        val slug = cleanPrompt.lowercase()
            .replace(Regex("[^a-z0-9\\s]"), "")
            .trim()
            .split(Regex("\\s+"))
            .take(3)
            .joinToString("-")
            .ifBlank { "autonomous-skill" }

        val draftedMd = """
            ---
            name: $slug
            author: Knight VIII • Skill Smith
            engine: ${_uiState.value.activeModel}
            ---
            # Goal
            $cleanPrompt

            ## Execution Protocol
            1. Ground context using live web search and active connectors.
            2. Decompose into verifiable steps across the 9 Knights.
            3. Output structured markdown with actionable takeaways.
        """.trimIndent()

        _uiState.update {
            it.copy(
                skillDraftName = slug,
                skillDraftMarkdown = draftedMd
            )
        }
    }

    fun approveSkillDraft() {
        val name = _uiState.value.skillDraftName ?: return
        val md = _uiState.value.skillDraftMarkdown ?: return
        val newSkill = InstalledSkillItem(
            id = "skill_${UUID.randomUUID().toString().take(6)}",
            name = name,
            source = "Skill Smith Agent • Approved",
            markdownContent = md,
            isEnabled = true
        )
        _uiState.update {
            it.copy(
                installedSkills = listOf(newSkill) + it.installedSkills,
                skillDraftName = null,
                skillDraftMarkdown = null
            )
        }
        showSnackbar("Approved & saved '$name'")
    }

    fun discardSkillDraft() {
        _uiState.update {
            it.copy(
                skillDraftName = null,
                skillDraftMarkdown = null
            )
        }
    }

    fun toggleScheduledTask(taskId: String) {
        val updated = _uiState.value.scheduledTasks.map { task ->
            if (task.id == taskId) task.copy(isScheduled = !task.isScheduled) else task
        }
        val target = updated.find { it.id == taskId }
        _uiState.update { it.copy(scheduledTasks = updated) }
        if (target != null) {
            showSnackbar(
                if (target.isScheduled) "Scheduled: ${target.title} (${target.cadence})"
                else "Paused schedule: ${target.title}"
            )
        }
    }

    fun runScheduledTaskNow(taskId: String) {
        val task = _uiState.value.scheduledTasks.find { it.id == taskId } ?: return
        val updated = _uiState.value.scheduledTasks.map {
            if (it.id == taskId) it.copy(isScheduled = true) else it
        }
        _uiState.update {
            it.copy(
                scheduledTasks = updated,
                commandInput = task.promptToRun,
                isTaskMode = true,
                selectedSquadron = SquadronType.GRAND_ORDER,
                currentTab = KnightsTab.TERMINAL
            )
        }
        deployMission()
    }

    private fun startFirestoreSync(userId: String) {
        val fsRepo = firestoreRepository ?: return

        firestoreAgentsJob?.cancel()
        firestoreAgentsJob = viewModelScope.launch {
            try {
                fsRepo.observeAgentConfigs(userId).collectLatest { docs ->
                    if (docs.isEmpty()) return@collectLatest
                    docs.forEach { doc ->
                        val targetId = doc.agentId.ifBlank { doc.id }
                        val existing = _uiState.value.allKnights.find { it.id == targetId }
                        if (existing != null) {
                            val parsedCaps = doc.capabilities.split(",").map { it.trim() }.filter { it.isNotBlank() }
                            val updated = existing.copy(
                                codename = doc.codename.ifBlank { existing.codename },
                                description = doc.description.ifBlank { existing.description },
                                instruction = doc.instruction.ifBlank { existing.instruction },
                                internetEnabled = doc.internetEnabled,
                                localModelId = doc.localModelId.ifBlank { existing.localModelId },
                                capabilities = if (parsedCaps.isNotEmpty()) parsedCaps else existing.capabilities,
                                lastTaskSummary = doc.lastTaskSummary.takeIf { it.isNotBlank() } ?: existing.lastTaskSummary
                            )
                            repository.saveAgentOverride(updated)
                        }
                    }
                    val refreshed = repository.getAllKnights()
                    _uiState.update {
                        it.copy(
                            allKnights = refreshed,
                            blueprintJson = generateBlueprintJson(refreshed)
                        )
                    }
                }
            } catch (_: Exception) {
            }
        }

        firestoreMemoriesJob?.cancel()
        firestoreMemoriesJob = viewModelScope.launch {
            try {
                fsRepo.observeMemories(userId).collectLatest { docs ->
                    if (docs.isEmpty()) return@collectLatest
                    val syncedMemories = docs.map { d ->
                        UserMemoryItem(
                            id = d.id,
                            content = d.content,
                            category = d.category,
                            isEnabled = d.enabled,
                            createdAtEpochMs = d.createdAt?.toDate()?.time ?: System.currentTimeMillis()
                        )
                    }
                    repository.saveMemories(syncedMemories)
                    _uiState.update { it.copy(memories = syncedMemories) }
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun observeTerminalLogs() {
        viewModelScope.launch {
            repository.logStream.collectLatest { log ->
                addLog(log)
            }
        }
    }

    private fun observeVaultDeliverables() {
        viewModelScope.launch {
            repository.allDeliverables.collectLatest { deliverables ->
                _uiState.update { it.copy(vaultDeliverables = deliverables) }
            }
        }
    }

    private fun addLog(log: TerminalLog) {
        _uiState.update { current ->
            val updated = current.terminalLogs.toMutableList()
            if (updated.size > 250) {
                updated.removeAt(0)
            }
            updated.add(log)
            current.copy(terminalLogs = updated)
        }
    }

    fun triggerAgentTask(agentId: String, taskPrompt: String = "") {
        val agent = _uiState.value.allKnights.find { it.id == agentId } ?: return
        val resolvedPrompt = taskPrompt.trim().ifBlank {
            _uiState.value.commandInput.trim().ifBlank {
                "Execute autonomous multi-domain analysis, live web research, and deliverable synthesis for ${agent.codename}"
            }
        }

        _uiState.update { state ->
            val updatedStates = state.agentExecutionStates.toMutableMap()
            updatedStates[agentId] = KnightExecutionState(
                knightId = agentId,
                codename = agent.codename,
                status = AgentStatus.QUEUED,
                activeTool = "initializing_pipeline"
            )
            state.copy(
                selectedSquadron = SquadronType.SOLO_KNIGHT,
                selectedSoloKnightId = agentId,
                isTaskMode = false,
                commandInput = resolvedPrompt,
                isMissionRunning = true,
                currentTab = KnightsTab.TERMINAL,
                agentExecutionStates = updatedStates
            )
        }

        viewModelScope.launch {
            val startTime = System.currentTimeMillis()
            repository.executeMission(
                targetId = agentId,
                prompt = resolvedPrompt,
                onAgentStateUpdated = { newStates ->
                    _uiState.update { current ->
                        val merged = current.agentExecutionStates.toMutableMap()
                        merged.putAll(newStates)
                        current.copy(agentExecutionStates = merged)
                    }
                },
                onMissionFinished = { deliverable ->
                    val elapsed = System.currentTimeMillis() - startTime
                    val summary = deliverable?.title ?: "Completed: ${resolvedPrompt.take(48)}"

                    if (_uiState.value.isTemporaryChat && deliverable != null) {
                        viewModelScope.launch {
                            repository.deleteDeliverable(deliverable)
                        }
                    }

                    val currentAgent = _uiState.value.allKnights.find { it.id == agentId } ?: agent
                    val updatedAgent = currentAgent.copy(
                        lastTaskSummary = summary,
                        tasksCompletedCount = currentAgent.tasksCompletedCount + 1
                    )
                    repository.saveAgentOverride(updatedAgent)
                    val refreshedKnights = repository.getAllKnights()

                    val taskRecord = AgentTaskExecutionRecord(
                        id = "task_${UUID.randomUUID().toString().take(8)}",
                        agentId = agentId,
                        agentName = updatedAgent.codename,
                        taskPrompt = resolvedPrompt,
                        status = if (deliverable != null) "COMPLETED" else "FINISHED",
                        usedInternet = updatedAgent.internetEnabled,
                        localModelId = updatedAgent.localModelId,
                        resultSummary = summary,
                        durationMs = elapsed
                    )

                    _uiState.update { state ->
                        state.copy(
                            isMissionRunning = false,
                            commandInput = "",
                            lastDeliverable = deliverable ?: state.lastDeliverable,
                            allKnights = refreshedKnights,
                            recentAgentTasks = (listOf(taskRecord) + state.recentAgentTasks).take(30)
                        )
                    }

                    val uid = Firebase.auth.currentUser?.uid
                    if (uid != null && firestoreRepository != null && !_uiState.value.isTemporaryChat) {
                        viewModelScope.launch {
                            try {
                                firestoreRepository.saveTaskRecord(
                                    userId = uid,
                                    taskId = taskRecord.id,
                                    doc = AgentTaskRecordDoc(
                                        userId = uid,
                                        agentId = agentId,
                                        agentCodename = updatedAgent.codename,
                                        prompt = resolvedPrompt.take(2000),
                                        status = "completed",
                                        output = summary.take(20000),
                                        usedInternet = updatedAgent.internetEnabled,
                                        executionEngine = updatedAgent.localModelId.ifBlank { _uiState.value.activeModel }
                                    )
                                )
                            } catch (_: Exception) {
                            }
                        }
                    }

                    showSnackbar("${updatedAgent.codename} finished (${elapsed}ms)")
                }
            )
        }
    }

    fun triggerTask(agentId: String, taskDescription: String = "") {
        triggerAgentTask(agentId, taskDescription)
    }

    fun customizeAgent(
        agentId: String,
        codename: String,
        description: String,
        instruction: String,
        internetEnabled: Boolean,
        localModelId: String,
        capabilities: List<String>
    ) {
        val existing = _uiState.value.allKnights.find { it.id == agentId } ?: return
        val updated = existing.copy(
            codename = codename.trim().ifBlank { existing.codename },
            description = description.trim().ifBlank { existing.description },
            instruction = instruction.trim().ifBlank { existing.instruction },
            internetEnabled = internetEnabled,
            localModelId = localModelId.ifBlank { "none" },
            capabilities = if (capabilities.isNotEmpty()) capabilities else existing.capabilities
        )
        repository.saveAgentOverride(updated)
        val refreshed = repository.getAllKnights()
        _uiState.update {
            it.copy(
                allKnights = refreshed,
                blueprintJson = generateBlueprintJson(refreshed),
                customizingKnightId = null
            )
        }

        val uid = Firebase.auth.currentUser?.uid
        if (uid != null && firestoreRepository != null) {
            viewModelScope.launch {
                try {
                    firestoreRepository.saveAgentConfig(
                        userId = uid,
                        agentId = agentId,
                        doc = CustomAgentConfigDoc(
                            userId = uid,
                            agentId = agentId,
                            codename = updated.codename.take(100),
                            squadron = updated.squadron.take(40),
                            description = updated.description.take(500),
                            instruction = updated.instruction.take(4000),
                            internetEnabled = updated.internetEnabled,
                            localModelId = updated.localModelId.take(120),
                            capabilities = updated.capabilities.joinToString(", ").ifBlank { "Multi-Domain" }.take(500),
                            lastTaskSummary = (updated.lastTaskSummary ?: "").take(1000)
                        )
                    )
                } catch (_: Exception) {
                }
            }
        }

        addLog(
            TerminalLog(
                level = LogLevel.INFO,
                agentName = updated.codename,
                message = "Agent configuration updated • Internet: ${if (updated.internetEnabled) "ON" else "OFF"} • Local AI: ${updated.localModelId}"
            )
        )
        showSnackbar("Updated ${updated.codename}")
    }

    fun toggleAgentInternet(agentId: String) {
        val existing = _uiState.value.allKnights.find { it.id == agentId } ?: return
        customizeAgent(
            agentId = agentId,
            codename = existing.codename,
            description = existing.description,
            instruction = existing.instruction,
            internetEnabled = !existing.internetEnabled,
            localModelId = existing.localModelId,
            capabilities = existing.capabilities
        )
    }

    fun bindLocalAiToAgent(agentId: String, localModelId: String) {
        val existing = _uiState.value.allKnights.find { it.id == agentId } ?: return
        customizeAgent(
            agentId = agentId,
            codename = existing.codename,
            description = existing.description,
            instruction = existing.instruction,
            internetEnabled = existing.internetEnabled,
            localModelId = localModelId,
            capabilities = existing.capabilities
        )
    }

    fun bindLocalAiToAllAgents(localModelId: String) {
        _uiState.value.allKnights.forEach { agent ->
            val updated = agent.copy(localModelId = localModelId)
            repository.saveAgentOverride(updated)
        }
        val refreshed = repository.getAllKnights()
        val modelName = _uiState.value.localAiModels.find { it.id == localModelId }?.name ?: localModelId
        _uiState.update {
            it.copy(
                allKnights = refreshed,
                blueprintJson = generateBlueprintJson(refreshed)
            )
        }
        addLog(
            TerminalLog(
                level = LogLevel.SYS,
                message = "Bound Local AI Model [$modelName] across all 9 Autonomous Agents."
            )
        )
        showSnackbar("Bound $modelName to all 9 Knights")
    }

    fun installLocalAiModel(modelId: String) {
        val target = _uiState.value.localAiModels.find { it.id == modelId } ?: return
        if (target.isInstalled || target.isInstalling) return

        viewModelScope.launch {
            addLog(
                TerminalLog(
                    level = LogLevel.SYS,
                    message = "Downloading & quantizing On-Device Local AI: ${target.name} (${target.sizeMb} MB, ${target.quantization})..."
                )
            )

            val steps = listOf(0.18f, 0.42f, 0.68f, 0.89f, 1.0f)
            for (progress in steps) {
                _uiState.update { state ->
                    state.copy(
                        localAiModels = state.localAiModels.map { m ->
                            if (m.id == modelId) {
                                m.copy(isInstalling = progress < 1.0f, installProgress = progress)
                            } else {
                                m
                            }
                        }
                    )
                }
                delay(240)
            }

            val updatedInstalledIds = repository.getInstalledLocalModelIds().toMutableSet().apply {
                add(modelId)
            }
            repository.setInstalledLocalModelIds(updatedInstalledIds)

            _uiState.update { state ->
                state.copy(
                    localAiModels = state.localAiModels.map { m ->
                        if (m.id == modelId) {
                            m.copy(isInstalled = true, isInstalling = false, installProgress = 1.0f)
                        } else {
                            m
                        }
                    }
                )
            }

            addLog(
                TerminalLog(
                    level = LogLevel.SUCCESS,
                    message = "✓ Installed Local AI Model: ${target.name} (${target.parameters}) ready for all 9 Knights."
                )
            )
            showSnackbar("Installed ${target.name} on device")
        }
    }

    fun uninstallLocalAiModel(modelId: String) {
        val target = _uiState.value.localAiModels.find { it.id == modelId } ?: return
        val updatedInstalledIds = repository.getInstalledLocalModelIds().toMutableSet().apply {
            remove(modelId)
        }
        repository.setInstalledLocalModelIds(updatedInstalledIds)

        _uiState.update { state ->
            state.copy(
                localAiModels = state.localAiModels.map { m ->
                    if (m.id == modelId) {
                        m.copy(isInstalled = false, isInstalling = false, installProgress = 0f)
                    } else {
                        m
                    }
                }
            )
        }
        showSnackbar("Removed local model ${target.name}")
    }

    fun toggleGlobalMemoryEnabled(enabled: Boolean) {
        repository.setGlobalMemoryEnabled(enabled)
        _uiState.update { it.copy(isGlobalMemoryEnabled = enabled) }
        showSnackbar(if (enabled) "Saved Info memory enabled" else "Saved Info memory paused")
    }

    fun addMemoryItem(content: String, category: String = "Preference") {
        val clean = content.trim()
        if (clean.isBlank()) {
            showSnackbar("Enter info for Knights to remember.")
            return
        }
        val newItem = UserMemoryItem(
            id = "mem_${UUID.randomUUID().toString().take(8)}",
            content = clean,
            category = category.trim().ifBlank { "Preference" },
            isEnabled = true,
            createdAtEpochMs = System.currentTimeMillis()
        )
        val updated = listOf(newItem) + _uiState.value.memories
        repository.saveMemories(updated)
        _uiState.update { it.copy(memories = updated) }

        val uid = Firebase.auth.currentUser?.uid
        if (uid != null && firestoreRepository != null) {
            viewModelScope.launch {
                try {
                    firestoreRepository.saveMemory(
                        userId = uid,
                        memoryId = newItem.id,
                        doc = UserMemoryItemDoc(
                            userId = uid,
                            content = newItem.content.take(1000),
                            category = newItem.category.take(60),
                            enabled = newItem.isEnabled
                        )
                    )
                } catch (_: Exception) {
                }
            }
        }
        showSnackbar("Saved to Memory")
    }

    fun toggleMemoryItem(memoryId: String) {
        val updated = _uiState.value.memories.map { m ->
            if (m.id == memoryId) m.copy(isEnabled = !m.isEnabled) else m
        }
        repository.saveMemories(updated)
        _uiState.update { it.copy(memories = updated) }

        val toggled = updated.find { it.id == memoryId } ?: return
        val uid = Firebase.auth.currentUser?.uid
        if (uid != null && firestoreRepository != null) {
            viewModelScope.launch {
                try {
                    firestoreRepository.saveMemory(
                        userId = uid,
                        memoryId = toggled.id,
                        doc = UserMemoryItemDoc(
                            userId = uid,
                            content = toggled.content.take(1000),
                            category = toggled.category.take(60),
                            enabled = toggled.isEnabled
                        )
                    )
                } catch (_: Exception) {
                }
            }
        }
    }

    fun deleteMemoryItem(memoryId: String) {
        val updated = _uiState.value.memories.filterNot { it.id == memoryId }
        repository.saveMemories(updated)
        _uiState.update { it.copy(memories = updated) }

        val uid = Firebase.auth.currentUser?.uid
        if (uid != null && firestoreRepository != null) {
            viewModelScope.launch {
                try {
                    firestoreRepository.deleteMemory(uid, memoryId)
                } catch (_: Exception) {
                }
            }
        }
        showSnackbar("Memory removed")
    }

    fun openCustomizeAgentModal(knightId: String?) {
        _uiState.update { it.copy(customizingKnightId = knightId) }
    }

    fun selectTab(tab: KnightsTab) {
        _uiState.update { it.copy(currentTab = tab) }
    }

    fun toggleAgentViewLayout() {
        _uiState.update { it.copy(isAgentGridView = !it.isAgentGridView) }
    }

    fun setAgentViewLayout(isGrid: Boolean) {
        _uiState.update { it.copy(isAgentGridView = isGrid) }
    }

    fun setSquadronFilter(filter: String) {
        _uiState.update { it.copy(squadronFilter = filter) }
    }

    fun toggleTerminalConsole(show: Boolean? = null) {
        _uiState.update {
            it.copy(showTerminalConsole = show ?: !it.showTerminalConsole)
        }
    }

    fun inspectKnight(knightId: String?) {
        _uiState.update { it.copy(inspectedKnightId = knightId) }
    }

    fun startNewGeminiSession() {
        _uiState.update {
            it.copy(
                currentTab = KnightsTab.TERMINAL,
                commandInput = "",
                agentExecutionStates = emptyMap(),
                lastDeliverable = null,
                inspectedKnightId = null,
                customizingKnightId = null
            )
        }
        addLog(
            TerminalLog(
                level = LogLevel.SYS,
                message = "New Knights session initialized. All 9 agents ready."
            )
        )
        showSnackbar("New chat started")
    }

    fun updateCommandInput(input: String) {
        _uiState.update { it.copy(commandInput = input) }
    }

    fun selectSquadron(type: SquadronType) {
        _uiState.update {
            it.copy(
                selectedSquadron = type,
                isTaskMode = type != SquadronType.SOLO_KNIGHT
            )
        }
        addLog(
            TerminalLog(
                level = LogLevel.INFO,
                message = "Selected Mode: ${type.title} (${type.subtitle})"
            )
        )
    }

    fun selectSoloKnight(knightId: String) {
        val agent = _uiState.value.allKnights.find { it.id == knightId }
        _uiState.update {
            it.copy(
                selectedSquadron = SquadronType.SOLO_KNIGHT,
                selectedSoloKnightId = knightId,
                isTaskMode = false,
                currentTab = KnightsTab.TERMINAL
            )
        }
        addLog(
            TerminalLog(
                level = LogLevel.INFO,
                message = "Selected ${agent?.codename ?: knightId} for Chat mode"
            )
        )
    }

    fun setTerminalMode(mode: TerminalMode) {
        _uiState.update { it.copy(terminalMode = mode) }
    }

    fun clearTerminalLogs() {
        _uiState.update {
            it.copy(
                terminalLogs = listOf(
                    TerminalLog(
                        level = LogLevel.SYS,
                        message = "Terminal buffer cleared. System online."
                    )
                )
            )
        }
    }

    fun deployMission() {
        val state = _uiState.value
        val prompt = state.commandInput.trim()
        if (prompt.isBlank()) {
            showSnackbar("Describe a task or tap a suggestion to begin.")
            return
        }
        if (state.isMissionRunning) return

        // In Chat mode (not Task mode), talk directly to the selected Knight
        if (!state.isTaskMode) {
            val soloId = state.selectedSoloKnightId ?: state.allKnights.firstOrNull()?.id ?: "knight_1_scout"
            triggerAgentTask(soloId, prompt)
            return
        }

        // In Task mode, run the full 9-agent team (or active squadron)
        val targetId = if (state.selectedSquadron == SquadronType.SOLO_KNIGHT) {
            SquadronType.GRAND_ORDER.id
        } else {
            state.selectedSquadron.id
        }

        _uiState.update {
            it.copy(
                isMissionRunning = true,
                showTerminalConsole = true,
                terminalMode = TerminalMode.CLI_STREAM
            )
        }

        viewModelScope.launch {
            repository.executeMission(
                targetId = targetId,
                prompt = prompt,
                onAgentStateUpdated = { states ->
                    _uiState.update { it.copy(agentExecutionStates = states) }
                },
                onMissionFinished = { deliverable ->
                    if (_uiState.value.isTemporaryChat && deliverable != null) {
                        viewModelScope.launch {
                            repository.deleteDeliverable(deliverable)
                        }
                    }
                    _uiState.update {
                        it.copy(
                            isMissionRunning = false,
                            commandInput = "",
                            lastDeliverable = deliverable
                        )
                    }
                    if (deliverable != null) {
                        showSnackbar("Task completed: \"${deliverable.title}\"")
                    } else {
                        showSnackbar("Task concluded.")
                    }
                }
            )
        }
    }

    fun updateYouTubeViews(views: Long) {
        _uiState.update { it.copy(ytParams = it.ytParams.copy(views = views)) }
    }

    fun updateYouTubeRpm(rpm: Double) {
        _uiState.update { it.copy(ytParams = it.ytParams.copy(rpmUsd = rpm)) }
    }

    fun updateYouTubeCtr(ctr: Double) {
        _uiState.update { it.copy(ytParams = it.ytParams.copy(ctrPercent = ctr)) }
    }

    fun updateYouTubeAvd(avd: Double) {
        _uiState.update { it.copy(ytParams = it.ytParams.copy(avgViewDurationMins = avd)) }
    }

    fun launchYouTubeSquadronWithMetrics() {
        val p = _uiState.value.ytParams
        val prompt = "Create a complete viral YouTube video package targeting ${p.views} views at $${p.rpmUsd} RPM and ${p.ctrPercent}% CTR on: Next-Gen Autonomous AI Agents in 2026"
        _uiState.update {
            it.copy(
                commandInput = prompt,
                isTaskMode = true,
                selectedSquadron = SquadronType.YOUTUBE_PIPELINE,
                selectedSoloKnightId = null,
                currentTab = KnightsTab.TERMINAL
            )
        }
        showSnackbar("Armed 5-Knight YouTube Squadron with your funnel targets!")
        deployMission()
    }

    fun forgeCustomKnight(id: String, codename: String, description: String, prompt: String) {
        val cleanId = id.trim().lowercase().replace(Regex("\\s+"), "_")
        if (cleanId.isBlank() || prompt.isBlank()) {
            showSnackbar("Enter both a Knight ID and system prompt.")
            return
        }

        val newKnight = KnightAgent(
            id = cleanId,
            name = cleanId,
            codename = if (codename.isNotBlank()) codename.trim() else "Custom Knight • $cleanId",
            squadron = "custom",
            description = if (description.isNotBlank()) description.trim() else "Custom multi-domain specialist",
            tools = listOf("google_search", "save_to_library"),
            outputKey = "${cleanId}_output",
            instruction = prompt.trim(),
            orderNumber = _uiState.value.allKnights.size + 1,
            badgeColorHex = "#81C995",
            internetEnabled = true,
            localModelId = "gemma-3-nano-4b-q4"
        )

        repository.addCustomKnight(newKnight)
        val refreshed = repository.getAllKnights()
        _uiState.update {
            it.copy(
                allKnights = refreshed,
                blueprintJson = generateBlueprintJson(refreshed)
            )
        }
        showSnackbar("Created ${newKnight.codename}")
    }

    fun saveBlueprintJson(jsonString: String) {
        val success = repository.saveFullKnightsJson(jsonString)
        if (success) {
            val refreshed = repository.getAllKnights()
            _uiState.update {
                it.copy(
                    allKnights = refreshed,
                    blueprintJson = jsonString
                )
            }
            showSnackbar("Knights blueprint updated")
        } else {
            showSnackbar("Invalid JSON structure. Must contain 'agents' list.")
        }
    }

    fun resetBlueprintToDefault() {
        repository.resetToDefaultOrder()
        val refreshed = repository.getAllKnights()
        _uiState.update {
            it.copy(
                allKnights = refreshed,
                blueprintJson = generateBlueprintJson(refreshed)
            )
        }
        showSnackbar("Reset all 9 Knights to factory configuration.")
    }

    fun updateVaultSearchQuery(query: String) {
        _uiState.update { it.copy(vaultSearchQuery = query) }
        viewModelScope.launch {
            repository.searchDeliverables(query).collectLatest { results ->
                _uiState.update { it.copy(vaultDeliverables = results) }
            }
        }
    }

    fun deleteDeliverable(deliverable: Deliverable) {
        viewModelScope.launch {
            repository.deleteDeliverable(deliverable)
            showSnackbar("Removed \"${deliverable.title}\"")
        }
    }

    fun saveCoreSettings(key: String, model: String, prefs: String) {
        val resolvedModel = model.trim().ifBlank { "gemini-3.5-flash" }
        repository.setApiKey(key.trim())
        repository.setActiveModel(resolvedModel)
        repository.setCommanderPrefs(prefs.trim())
        _uiState.update {
            it.copy(
                apiKey = key.trim(),
                activeModel = resolvedModel,
                commanderPrefs = prefs.trim()
            )
        }
        showSnackbar("Settings saved ($resolvedModel)")
    }

    fun selectActiveModel(model: String) {
        repository.setActiveModel(model)
        _uiState.update { it.copy(activeModel = model) }
        showSnackbar("Switched model to $model")
    }

    fun showSnackbar(message: String) {
        _uiState.update { it.copy(snackbarMessage = message) }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    private fun generateBlueprintJson(agents: List<KnightAgent>): String {
        val root = JSONObject()
        val arr = JSONArray()
        agents.forEach { a ->
            val obj = JSONObject().apply {
                put("id", a.id)
                put("codename", a.codename)
                put("squadron", a.squadron)
                put("description", a.description)
                put("internetEnabled", a.internetEnabled)
                put("localModelId", a.localModelId)
                put("capabilities", JSONArray(a.capabilities))
                put("tools", JSONArray(a.tools))
                put("output_key", a.outputKey)
                put("instruction", a.instruction)
            }
            arr.put(obj)
        }
        root.put("agents", arr)
        return root.toString(2)
    }
}
