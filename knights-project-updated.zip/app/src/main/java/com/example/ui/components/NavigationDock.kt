package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GeminiBorder
import com.example.ui.theme.GeminiLightBlue
import com.example.ui.theme.GeminiSurface
import com.example.ui.theme.GeminiSurfaceBright
import com.example.ui.viewmodel.KnightsTab

@Composable
fun NavigationDock(
    currentTab: KnightsTab,
    onTabSelected: (KnightsTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val tabs = KnightsTab.entries

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(GeminiSurface)
            .border(1.dp, GeminiBorder.copy(alpha = 0.7f), RoundedCornerShape(22.dp))
            .padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        tabs.forEach { tab ->
            val isSelected = tab == currentTab
            val interactionSource = remember { MutableInteractionSource() }

            val containerColor = if (isSelected) {
                GeminiSurfaceBright
            } else {
                Color.Transparent
            }

            val borderColor = if (isSelected) {
                GeminiLightBlue.copy(alpha = 0.35f)
            } else {
                Color.Transparent
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .defaultMinSize(minHeight = 40.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(containerColor)
                    .border(1.dp, borderColor, RoundedCornerShape(18.dp))
                    .clickable(
                        interactionSource = interactionSource,
                        indication = ripple(color = GeminiLightBlue)
                    ) {
                        onTabSelected(tab)
                    }
                    .testTag("nav_tab_${tab.name.lowercase()}")
                    .padding(vertical = 7.dp, horizontal = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = tab.icon,
                        fontSize = 11.5.sp,
                        color = if (isSelected) GeminiLightBlue else Color(0xFF8E918F)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = tab.label,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (isSelected) Color(0xFFE3E3E3) else Color(0xFF8E918F),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
