package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.NoCredentialException
import com.example.R
import com.example.data.model.AuthProviderType
import com.example.ui.theme.GeminiBorder
import com.example.ui.theme.GeminiLightBlue
import com.example.ui.theme.GeminiPurple
import com.example.ui.theme.GeminiRose
import com.example.ui.theme.KnightEmerald
import com.example.ui.theme.KnightsCardPill
import com.example.ui.theme.KnightsChatSendIndigo
import com.example.ui.theme.KnightsIconCircle
import com.example.ui.theme.KnightsPureBlack
import com.example.ui.theme.KnightsSecondaryGray
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.OAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@Composable
fun KnightsAuthModal(
    userId: String?,
    userEmail: String?,
    userName: String?,
    authProvider: AuthProviderType,
    onDismiss: () -> Unit,
    onLoginSuccess: (provider: AuthProviderType, displayName: String, identifier: String, uid: String?) -> Unit,
    onSignOut: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(28.dp))
                .border(1.dp, GeminiBorder, RoundedCornerShape(28.dp)),
            color = KnightsPureBlack
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Sign in to Knights",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Light,
                            color = Color.White
                        )
                        Text(
                            text = "Sync your 9 agents, skills & library across devices",
                            fontSize = 12.5.sp,
                            color = KnightsSecondaryGray
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("close_auth_modal_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Close,
                            contentDescription = "Close",
                            tint = KnightsSecondaryGray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                GoogleCloudSyncCard(
                    userId = userId,
                    userEmail = userEmail,
                    userName = userName,
                    authProvider = authProvider,
                    onAuthChanged = {},
                    onShowMessage = {},
                    onMultiProviderLogin = onLoginSuccess,
                    onSignOut = onSignOut
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = 48.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(KnightsCardPill)
                        .clickable {
                            onDismiss()
                            onOpenSettings()
                        }
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Open Full Engine & Memory Settings",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Medium,
                        color = GeminiLightBlue
                    )
                }
            }
        }
    }
}

@Composable
fun GoogleCloudSyncCard(
    userId: String?,
    userEmail: String?,
    userName: String?,
    authProvider: AuthProviderType = AuthProviderType.NONE,
    onAuthChanged: () -> Unit,
    onShowMessage: (String) -> Unit,
    onMultiProviderLogin: ((AuthProviderType, String, String, String?) -> Unit)? = null,
    onSignOut: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }
    val webClientId = stringResource(R.string.default_web_client_id)

    var selectedMethodTab by remember { mutableStateOf("GOOGLE") } // GOOGLE, GITHUB, EMAIL, PHONE
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Form states for GitHub, Email, and Phone login
    var githubHandle by remember { mutableStateOf("") }
    var githubToken by remember { mutableStateOf("") }

    var emailAddress by remember { mutableStateOf("") }
    var emailDisplayName by remember { mutableStateOf("") }
    var emailPassword by remember { mutableStateOf("") }
    var emailCreateMode by remember { mutableStateOf(false) }

    var phoneNumber by remember { mutableStateOf("") }
    var otpCodeSent by remember { mutableStateOf(false) }
    var otpCode by remember { mutableStateOf("") }

    suspend fun firebaseSignInWithGoogleCredential(credential: androidx.credentials.Credential) {
        if (credential is CustomCredential &&
            credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
        ) {
            val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
            val firebaseCredential = GoogleAuthProvider.getCredential(googleIdTokenCredential.idToken, null)
            val authResult = Firebase.auth.signInWithCredential(firebaseCredential).await()
            val user = authResult.user
            onMultiProviderLogin?.invoke(
                AuthProviderType.GOOGLE,
                user?.displayName ?: googleIdTokenCredential.displayName ?: "Commander",
                user?.email ?: googleIdTokenCredential.id,
                user?.uid
            )
            onAuthChanged()
            onShowMessage("Signed in with Google")
        }
    }

    // Attempt silent auto-sign-in when not yet signed in
    LaunchedEffect(userId) {
        if (userId == null) {
            val activityContext = context.findActivity() ?: return@LaunchedEffect
            try {
                val googleIdOption = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(true)
                    .setServerClientId(webClientId)
                    .setAutoSelectEnabled(true)
                    .build()
                val request = GetCredentialRequest.Builder()
                    .addCredentialOption(googleIdOption)
                    .build()
                val result = credentialManager.getCredential(activityContext, request)
                firebaseSignInWithGoogleCredential(result.credential)
            } catch (_: NoCredentialException) {
            } catch (_: Exception) {
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(KnightsCardPill)
            .border(1.dp, GeminiBorder, RoundedCornerShape(28.dp))
            .padding(18.dp)
    ) {
        // Header Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(KnightsIconCircle)
                        .border(
                            width = 1.5.dp,
                            brush = Brush.linearGradient(listOf(GeminiLightBlue, GeminiPurple, GeminiRose)),
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (userId != null) Icons.Outlined.CheckCircle else Icons.Outlined.AccountCircle,
                        contentDescription = "Account status",
                        tint = if (userId != null) KnightEmerald else Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (userId != null) {
                                userName?.takeIf { it.isNotBlank() } ?: "Commander"
                            } else {
                                "Account & Cloud Login"
                            },
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Medium),
                            color = Color.White
                        )
                        if (userId != null) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(KnightsChatSendIndigo)
                                    .padding(horizontal = 7.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "PRO",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White
                                )
                            }
                        }
                    }
                    Text(
                        text = if (userId != null) {
                            "${authProvider.label} • ${userEmail ?: "Synced"}"
                        } else {
                            "Sign in with Google, GitHub, Email, or Phone number"
                        },
                        fontSize = 12.sp,
                        color = KnightsSecondaryGray
                    )
                }
            }

            if (userId != null) {
                IconButton(
                    onClick = {
                        coroutineScope.launch {
                            try {
                                Firebase.auth.signOut()
                                credentialManager.clearCredentialState(ClearCredentialStateRequest())
                            } catch (_: Exception) {
                            }
                            onSignOut?.invoke()
                            onAuthChanged()
                            onShowMessage("Signed out")
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("google_sign_out_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Logout,
                        contentDescription = "Sign out",
                        tint = KnightsSecondaryGray,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        if (errorMessage != null) {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = errorMessage!!,
                fontSize = 12.sp,
                color = GeminiRose
            )
        }

        if (userId == null) {
            Spacer(modifier = Modifier.height(14.dp))

            // 4 Provider Method Selector Pills: Google | GitHub | Email | Phone
            val methods = listOf(
                "GOOGLE" to "Google",
                "GITHUB" to "GitHub",
                "EMAIL" to "Email",
                "PHONE" to "Phone"
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(KnightsPureBlack)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                methods.forEach { (key, label) ->
                    val selected = selectedMethodTab == key
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 40.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (selected) KnightsCardPill else Color.Transparent)
                            .clickable {
                                selectedMethodTab = key
                                errorMessage = null
                            }
                            .testTag("auth_tab_${key.lowercase()}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            fontSize = 12.5.sp,
                            fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal,
                            color = if (selected) Color.White else KnightsSecondaryGray
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            when (selectedMethodTab) {
                "GOOGLE" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Use your Google account via Android Credential Manager to sync all 9 Knights, skills, and memories to Cloud Firestore.",
                            fontSize = 12.sp,
                            color = KnightsSecondaryGray
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 52.dp)
                                .clip(RoundedCornerShape(26.dp))
                                .background(KnightsChatSendIndigo)
                                .clickable(enabled = !isLoading) {
                                    val activityContext = context.findActivity()
                                    if (activityContext == null) {
                                        errorMessage = "Activity context unavailable."
                                        return@clickable
                                    }
                                    coroutineScope.launch {
                                        isLoading = true
                                        errorMessage = null
                                        try {
                                            val signInWithGoogleOption = GetSignInWithGoogleOption.Builder(webClientId)
                                                .build()
                                            val request = GetCredentialRequest.Builder()
                                                .addCredentialOption(signInWithGoogleOption)
                                                .build()
                                            val result = credentialManager.getCredential(activityContext, request)
                                            firebaseSignInWithGoogleCredential(result.credential)
                                        } catch (e: GetCredentialCancellationException) {
                                            // User cancelled
                                        } catch (e: NoCredentialException) {
                                            errorMessage = "No Google account configured on this device. Add a Google account in Android Settings or sign in via Email, GitHub, or Phone."
                                        } catch (e: Exception) {
                                            Log.e("GoogleCloudSyncCard", "Google Sign-In error", e)
                                            errorMessage = "Google Sign-In unavailable on this device: ${e.localizedMessage ?: "Try Email, GitHub, or Phone tab"}"
                                        } finally {
                                            isLoading = false
                                        }
                                    }
                                }
                                .testTag("google_sign_in_button")
                                .padding(horizontal = 18.dp, vertical = 14.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Connecting Google...",
                                    fontSize = 14.sp,
                                    color = Color.White
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Outlined.AccountCircle,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Continue with Google",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }

                "GITHUB" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = githubHandle,
                            onValueChange = { githubHandle = it },
                            placeholder = { Text("GitHub username (e.g. octocat)", color = KnightsSecondaryGray, fontSize = 13.sp) },
                            leadingIcon = {
                                Icon(Icons.Outlined.Code, contentDescription = null, tint = KnightsSecondaryGray)
                            },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GeminiLightBlue,
                                unfocusedBorderColor = GeminiBorder,
                                focusedContainerColor = KnightsPureBlack,
                                unfocusedContainerColor = KnightsPureBlack,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("github_username_input")
                        )

                        OutlinedTextField(
                            value = githubToken,
                            onValueChange = { githubToken = it },
                            placeholder = { Text("Personal Access Token or OAuth passkey (optional)", color = KnightsSecondaryGray, fontSize = 13.sp) },
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GeminiLightBlue,
                                unfocusedBorderColor = GeminiBorder,
                                focusedContainerColor = KnightsPureBlack,
                                unfocusedContainerColor = KnightsPureBlack,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 52.dp)
                                .clip(RoundedCornerShape(26.dp))
                                .background(KnightsChatSendIndigo)
                                .clickable(enabled = !isLoading) {
                                    val cleanHandle = githubHandle.trim().removePrefix("@")
                                    val activity = context.findActivity()
                                    if (activity != null) {
                                        coroutineScope.launch {
                                            isLoading = true
                                            errorMessage = null
                                            try {
                                                val provider = OAuthProvider.newBuilder("github.com").build()
                                                val res = Firebase.auth.startActivityForSignInWithProvider(activity, provider).await()
                                                val u = res.user
                                                onMultiProviderLogin?.invoke(
                                                    AuthProviderType.GITHUB,
                                                    u?.displayName ?: "GitHub Developer",
                                                    u?.email ?: "github-oauth",
                                                    u?.uid
                                                )
                                                onAuthChanged()
                                            } catch (_: Exception) {
                                                errorMessage = "GitHub sign-in is not set up yet. Enable the GitHub provider in Firebase console, or use Google or Email."
                                            } finally {
                                                isLoading = false
                                            }
                                        }
                                    }
                                }
                                .testTag("github_sign_in_button")
                                .padding(horizontal = 18.dp, vertical = 14.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Code,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Continue with GitHub",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color.White
                            )
                        }
                    }
                }

                "EMAIL" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = emailDisplayName,
                            onValueChange = { emailDisplayName = it },
                            placeholder = { Text("Display name (optional)", color = KnightsSecondaryGray, fontSize = 13.sp) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GeminiLightBlue,
                                unfocusedBorderColor = GeminiBorder,
                                focusedContainerColor = KnightsPureBlack,
                                unfocusedContainerColor = KnightsPureBlack,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = emailAddress,
                            onValueChange = { emailAddress = it },
                            placeholder = { Text("Email address (name@domain.com)", color = KnightsSecondaryGray, fontSize = 13.sp) },
                            leadingIcon = {
                                Icon(Icons.Outlined.Email, contentDescription = null, tint = KnightsSecondaryGray)
                            },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GeminiLightBlue,
                                unfocusedBorderColor = GeminiBorder,
                                focusedContainerColor = KnightsPureBlack,
                                unfocusedContainerColor = KnightsPureBlack,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("email_address_input")
                        )

                        OutlinedTextField(
                            value = emailPassword,
                            onValueChange = { emailPassword = it },
                            placeholder = { Text("Password (6+ characters)", color = KnightsSecondaryGray, fontSize = 13.sp) },
                            visualTransformation = PasswordVisualTransformation(),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GeminiLightBlue,
                                unfocusedBorderColor = GeminiBorder,
                                focusedContainerColor = KnightsPureBlack,
                                unfocusedContainerColor = KnightsPureBlack,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("email_password_input")
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 52.dp)
                                .clip(RoundedCornerShape(26.dp))
                                .background(KnightsChatSendIndigo)
                                .clickable {
                                    val cleanEmail = emailAddress.trim()
                                    if (isLoading) return@clickable
                                    if (!cleanEmail.contains("@") || emailPassword.length < 6) {
                                        errorMessage = "Enter a valid email and a password of at least 6 characters."
                                        return@clickable
                                    }
                                    errorMessage = null
                                    isLoading = true
                                    coroutineScope.launch {
                                        try {
                                            val auth = Firebase.auth
                                            val result = if (emailCreateMode) {
                                                auth.createUserWithEmailAndPassword(cleanEmail, emailPassword).await()
                                            } else {
                                                auth.signInWithEmailAndPassword(cleanEmail, emailPassword).await()
                                            }
                                            val user = result.user
                                            val name = emailDisplayName.trim().ifBlank {
                                                user?.displayName ?: cleanEmail.substringBefore("@").replaceFirstChar { it.uppercase() }
                                            }
                                            onMultiProviderLogin?.invoke(AuthProviderType.EMAIL, name, cleanEmail, user?.uid)
                                            onAuthChanged()
                                            onShowMessage("Signed in as $cleanEmail")
                                        } catch (e: FirebaseAuthException) {
                                            errorMessage = when (e.errorCode) {
                                                "ERROR_OPERATION_NOT_ALLOWED" -> "Email sign-in is switched off. In Firebase console open Authentication, Sign-in method, and enable Email/Password."
                                                "ERROR_EMAIL_ALREADY_IN_USE" -> "That email already has an account. Tap Sign in."
                                                "ERROR_WEAK_PASSWORD" -> "Choose a stronger password (6+ characters)."
                                                "ERROR_INVALID_CREDENTIAL", "ERROR_WRONG_PASSWORD", "ERROR_USER_NOT_FOUND", "ERROR_INVALID_EMAIL" ->
                                                    "Wrong email or password. New here? Tap Create account."
                                                else -> e.localizedMessage ?: "Sign-in failed."
                                            }
                                        } catch (e: Exception) {
                                            errorMessage = e.localizedMessage ?: "Sign-in failed. Check your connection."
                                        } finally {
                                            isLoading = false
                                        }
                                    }
                                }
                                .testTag("email_sign_in_button")
                                .padding(horizontal = 18.dp, vertical = 14.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Email,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (emailCreateMode) "Create account" else "Sign in with Email",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color.White
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(
                                text = if (emailCreateMode) "Have an account? Sign in" else "New here? Create account",
                                fontSize = 12.5.sp,
                                color = GeminiLightBlue,
                                modifier = Modifier
                                    .clickable { emailCreateMode = !emailCreateMode; errorMessage = null }
                                    .padding(8.dp)
                                    .testTag("email_toggle_mode")
                            )
                            Text(
                                text = "Forgot password?",
                                fontSize = 12.5.sp,
                                color = KnightsSecondaryGray,
                                modifier = Modifier
                                    .clickable {
                                        val e = emailAddress.trim()
                                        if (!e.contains("@")) {
                                            errorMessage = "Enter your email first."
                                            return@clickable
                                        }
                                        coroutineScope.launch {
                                            try {
                                                Firebase.auth.sendPasswordResetEmail(e).await()
                                                onShowMessage("Password reset email sent to $e")
                                            } catch (ex: Exception) {
                                                errorMessage = ex.localizedMessage ?: "Could not send the reset email."
                                            }
                                        }
                                    }
                                    .padding(8.dp)
                                    .testTag("email_forgot_password")
                            )
                        }
                    }
                }

                "PHONE" -> {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = phoneNumber,
                            onValueChange = { phoneNumber = it },
                            placeholder = { Text("Phone number (e.g. +1 555 234 5678)", color = KnightsSecondaryGray, fontSize = 13.sp) },
                            leadingIcon = {
                                Icon(Icons.Outlined.Phone, contentDescription = null, tint = KnightsSecondaryGray)
                            },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GeminiLightBlue,
                                unfocusedBorderColor = GeminiBorder,
                                focusedContainerColor = KnightsPureBlack,
                                unfocusedContainerColor = KnightsPureBlack,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("phone_number_input")
                        )

                        if (otpCodeSent) {
                            OutlinedTextField(
                                value = otpCode,
                                onValueChange = { otpCode = it.take(6) },
                                placeholder = { Text("6-digit verification code (e.g. 123456)", color = KnightsSecondaryGray, fontSize = 13.sp) },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GeminiLightBlue,
                                    unfocusedBorderColor = GeminiBorder,
                                    focusedContainerColor = KnightsPureBlack,
                                    unfocusedContainerColor = KnightsPureBlack,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                shape = RoundedCornerShape(18.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("phone_otp_input")
                            )
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 52.dp)
                                .clip(RoundedCornerShape(26.dp))
                                .background(KnightsChatSendIndigo)
                                .clickable {
                                    val cleanPhone = phoneNumber.trim()
                                    if (cleanPhone.length < 7) {
                                        errorMessage = "Enter a valid phone number with country code."
                                        return@clickable
                                    }
                                    errorMessage = null
                                    errorMessage = "Phone sign-in is not available yet (it needs Firebase billing). Please use Google or Email."
                                }
                                .testTag("phone_sign_in_button")
                                .padding(horizontal = 18.dp, vertical = 14.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Phone,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (!otpCodeSent) "Send Verification Code" else "Verify & Sign In",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}
