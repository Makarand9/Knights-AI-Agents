package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DeviceHardwareInfo
import com.example.ui.theme.KnightCyan
import com.example.ui.theme.KnightEmerald
import com.example.ui.theme.KnightIndigo
import com.example.ui.theme.KnightRose
import com.example.ui.theme.KnightSurface
import com.example.ui.theme.KnightViolet

@Composable
fun TopHeader(
    hardwareInfo: DeviceHardwareInfo?,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orbPulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orbScale"
    )

    val geminiGradient = Brush.linearGradient(
        colors = listOf(KnightIndigo, KnightViolet, KnightRose, KnightCyan)
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(KnightSurface)
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    listOf(KnightIndigo.copy(alpha = 0.4f), KnightCyan.copy(alpha = 0.4f))
                ),
                shape = RoundedCornerShape(20.dp)
            )
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Pulsing Knight Orb
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .scale(scale)
                        .shadow(12.dp, RoundedCornerShape(14.dp), ambientColor = KnightViolet, spotColor = KnightCyan)
                        .clip(RoundedCornerShape(14.dp))
                        .background(geminiGradient),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "⚔️",
                        fontSize = 20.sp
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "KNIGHTS",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        ),
                        color = Color.White
                    )
                    Text(
                        text = "Gemini 9-Agent Order • YouTube & Universal",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF94A3B8),
                        maxLines = 1
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Hardware RAM Verification Pill
        val ramText = hardwareInfo?.totalRamGbFormatted ?: "6.0+ GB"
        val isSufficient = hardwareInfo?.isRamSufficient ?: true
        val pillBg = if (isSufficient) Color(0x2210B981) else Color(0x22F59E0B)
        val pillBorder = if (isSufficient) KnightEmerald.copy(alpha = 0.5f) else Color(0xFFF59E0B)
        val pillText = if (isSufficient) KnightEmerald else Color(0xFFFBBF24)

        Row(
            modifier = Modifier
                .clip(CircleShape)
                .background(pillBg)
                .border(1.dp, pillBorder, CircleShape)
                .padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "🛡️ Hardware Verified: $ramText RAM",
                fontSize = 11.5.sp,
                fontWeight = FontWeight.SemiBold,
                color = pillText
            )
            if (hardwareInfo != null) {
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "• ${hardwareInfo.cpuCores} Cores",
                    fontSize = 11.sp,
                    color = pillText.copy(alpha = 0.8f)
                )
            }
        }
    }
}
