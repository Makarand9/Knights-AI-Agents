package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.KnightAgent
import com.example.data.model. KnightExecutionState
import com.example.data.model.LocalAiModel
import com.example.ui.screens.AgentVisualStatusIndicator
import com.example.ui.theme.GeminiBorder
import com.example.ui.theme.GeminiDarkBg
import com.example.ui.theme.GeminiLightBlue
import com.example.ui.theme.GeminiPurple
import com.example.ui.theme.GeminiSurface
import com.example.ui.theme.GeminiSurfaceBright
import com.example.ui.theme.GeminiSurfaceHigh
import com.example.ui.theme.KnightEmerald

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AgentCustomizerModal(
    agent: KnightAgent,
    execState: KnightExecutionState?,
    localAiModels: List<LocalAiModel>,
    onDismiss: () -> Unit,
    onSaveCustomization: (
        codename: String,
        description: String,
        instruction: String,
        internetEnabled: Boolean,
        localModelId: String,
        capabilities: List<String>
    ) -> Unit,
    onInstallLocalModel: (String) -> Unit,
    onTriggerTask: (taskPrompt: String) -> Unit
) {
    var codename by remember(agent.id) { mutableStateOf(agent.codename) }
    var description by remember(agent.id) { mutableStateOf(agent.description) }
    var instruction by remember(agent.id) { mutableStateOf(agent.instruction) }
    var internetEnabled by remember(agent.id) { mutableStateOf(agent.internetEnabled) }
    var selectedLocalModelId by remember(agent.id) { mutableStateOf(agent.localModelId) }
    var capabilitiesText by remember(agent.id) {
        mutableStateOf(agent.capabilities.joinToString(", "))
    }
    var quickTaskInput by remember(agent.id) { mutableStateOf("") }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, GeminiBorder, RoundedCornerShape(24.dp)),
            color = GeminiSurface,
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Agent #${agent.orderNumber}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = GeminiLightBlue
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            AgentVisualStatusIndicator(execState = execState, compact = false)
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = agent.codename,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color(0xFF9AA0A6)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Quick Task Dispatch Card for this Specific Agent
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(GeminiDarkBg)
                        .border(1.dp, GeminiBorder, RoundedCornerShape(16.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = "✦ Trigger Multi-Domain Task on ${agent.codename}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = GeminiLightBlue
                    )
                    Text(
                        text = "Not limited to one task — ask this agent to research, code, analyze, or create anything.",
                        fontSize = 11.sp,
                        color = Color(0xFF8E918F)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = quickTaskInput,
                            onValueChange = { quickTaskInput = it },
                            placeholder = {
                                Text(
                                    "Enter any task for this agent...",
                                    fontSize = 12.sp,
                                    color = Color(0xFF6E7175)
                                )
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GeminiLightBlue,
                                unfocusedBorderColor = GeminiBorder,
                                focusedContainerColor = GeminiSurface,
                                unfocusedContainerColor = GeminiSurface,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("modal_agent_task_input")
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(GeminiSurfaceBright)
                                .border(1.dp, GeminiLightBlue.copy(alpha = 0.5f), CircleShape)
                                .clickable {
                                    onTriggerTask(quickTaskInput)
                                    onDismiss()
                                }
                                .testTag("modal_trigger_task_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Run Task",
                                tint = GeminiLightBlue,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Live Internet Connectivity Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(GeminiSurfaceHigh)
                        .border(1.dp, GeminiBorder, RoundedCornerShape(16.dp))
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = null,
                            tint = if (internetEnabled) KnightEmerald else Color(0xFF8E918F),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Live Internet & Web Grounding",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFFE3E3E3)
                            )
                            Text(
                                text = if (internetEnabled) "Connected to live web search & citations" else "Air-gapped offline mode",
                                fontSize = 11.sp,
                                color = Color(0xFF8E918F)
                            )
                        }
                    }
                    Switch(
                        checked = internetEnabled,
                        onCheckedChange = { internetEnabled = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF0B0B0C),
                            checkedTrackColor = KnightEmerald,
                            uncheckedThumbColor = Color(0xFF8E918F),
                            uncheckedTrackColor = GeminiDarkBg
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Bound On-Device Local AI Model Selector
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(GeminiSurfaceHigh)
                        .border(1.dp, GeminiBorder, RoundedCornerShape(16.dp))
                        .padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Memory,
                            contentDescription = null,
                            tint = GeminiPurple,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "On-Device Local AI Engine",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFE3E3E3)
                        )
                    }
                    Text(
                        text = "Select or install a local neural model inside this agent for instant on-device execution:",
                        fontSize = 11.sp,
                        color = Color(0xFF8E918F)
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        localAiModels.forEach { model ->
                            val isSelected = selectedLocalModelId == model.id
                            Column(
                                modifier = Modifier
                                    .width(165.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSelected) GeminiSurfaceBright else GeminiDarkBg)
                                    .border(
                                        1.dp,
                                        if (isSelected) GeminiLightBlue else GeminiBorder,
                                        RoundedCornerShape(12.dp)
                                    )
                                    .clickable {
                                        if (!model.isInstalled && !model.isInstalling) {
                                            onInstallLocalModel(model.id)
                                        }
                                        selectedLocalModelId = model.id
                                    }
                                    .padding(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = model.name,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color.White,
                                        maxLines = 1
                                    )
                                }
                                Text(
                                    text = "${model.parameters} • ${model.quantization}",
                                    fontSize = 10.sp,
                                    color = Color(0xFF8E918F)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (model.isInstalled) {
                                        Text(
                                            text = if (isSelected) "✓ Bound" else "● Installed",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (isSelected) GeminiLightBlue else KnightEmerald
                                        )
                                    } else if (model.isInstalling) {
                                        Text(
                                            text = "Installing ${(model.installProgress * 100).toInt()}%...",
                                            fontSize = 10.sp,
                                            color = GeminiPurple
                                        )
                                    } else {
                                        Icon(
                                            imageVector = Icons.Default.Download,
                                            contentDescription = null,
                                            tint = GeminiLightBlue,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Install (${model.sizeMb} MB)",
                                            fontSize = 10.sp,
                                            color = GeminiLightBlue
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Editable Agent Identity & Instructions
                OutlinedTextField(
                    value = codename,
                    onValueChange = { codename = it },
                    label = { Text("Agent Name / Title", fontSize = 11.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GeminiLightBlue,
                        unfocusedBorderColor = GeminiBorder,
                        focusedContainerColor = GeminiDarkBg,
                        unfocusedContainerColor = GeminiDarkBg,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Role Description", fontSize = 11.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GeminiLightBlue,
                        unfocusedBorderColor = GeminiBorder,
                        focusedContainerColor = GeminiDarkBg,
                        unfocusedContainerColor = GeminiDarkBg,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = capabilitiesText,
                    onValueChange = { capabilitiesText = it },
                    label = { Text("Multi-Domain Capabilities (comma-separated)", fontSize = 11.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GeminiLightBlue,
                        unfocusedBorderColor = GeminiBorder,
                        focusedContainerColor = GeminiDarkBg,
                        unfocusedContainerColor = GeminiDarkBg,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = instruction,
                    onValueChange = { instruction = it },
                    label = { Text("Custom System Instructions & Persona", fontSize = 11.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GeminiLightBlue,
                        unfocusedBorderColor = GeminiBorder,
                        focusedContainerColor = GeminiDarkBg,
                        unfocusedContainerColor = GeminiDarkBg,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 90.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 46.dp)
                            .clip(RoundedCornerShape(22.dp))
                            .background(GeminiSurfaceHigh)
                            .border(1.dp, GeminiBorder, RoundedCornerShape(22.dp))
                            .clickable { onDismiss() }
                            .padding(vertical = 11.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Cancel",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF9AA0A6)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1.4f)
                            .defaultMinSize(minHeight = 46.dp)
                            .clip(RoundedCornerShape(22.dp))
                            .background(GeminiSurfaceBright)
                            .border(1.dp, GeminiLightBlue.copy(alpha = 0.55f), RoundedCornerShape(22.dp))
                            .clickable {
                                val parsedCaps = capabilitiesText
                                    .split(",")
                                    .map { it.trim() }
                                    .filter { it.isNotBlank() }
                                onSaveCustomization(
                                    codename,
                                    description,
                                    instruction,
                                    internetEnabled,
                                    selectedLocalModelId,
                                    parsedCaps
                                )
                            }
                            .testTag("save_agent_customization_button")
                            .padding(vertical = 11.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Save Agent Settings",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = GeminiLightBlue
                        )
                    }
                }
            }
        }
    }
}
