package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.components.AgentCustomizerModal
import com.example.ui.components.GeminiDrawerContent
import com.example.ui.components.GeminiTopBar
import com.example.ui.screens.ForgeScreen
import com.example.ui.screens.KnightsAuthModal
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.RosterScreen
import com.example.ui.screens.ScheduledScreen
import com.example.ui.screens.TerminalScreen
import com.example.ui.screens.VaultScreen
import com.example.ui.screens.YouTubeLabScreen
import com.example.ui.theme.KnightsPureBlack
import com.example.ui.theme.KnightsTheme
import com.example.ui.viewmodel.KnightsTab
import com.example.ui.viewmodel.KnightsViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val viewModel: KnightsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            KnightsTheme {
                val uiState by viewModel.uiState.collectAsState()
                val snackbarHostState = remember { SnackbarHostState() }
                val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
                val coroutineScope = rememberCoroutineScope()

                LaunchedEffect(uiState.snackbarMessage) {
                    uiState.snackbarMessage?.let { msg ->
                        snackbarHostState.showSnackbar(msg)
                        viewModel.clearSnackbar()
                    }
                }

                BackHandler(
                    enabled = uiState.showAuthModal ||
                        uiState.customizingKnightId != null ||
                        drawerState.isOpen ||
                        uiState.currentTab != KnightsTab.TERMINAL
                ) {
                    when {
                        uiState.showAuthModal -> viewModel.setShowAuthModal(false)
                        uiState.customizingKnightId != null -> viewModel.openCustomizeAgentModal(null)
                        drawerState.isOpen -> coroutineScope.launch { drawerState.close() }
                        uiState.currentTab != KnightsTab.TERMINAL -> viewModel.selectTab(KnightsTab.TERMINAL)
                    }
                }

                // Multi-Provider Authentication Modal (Google, GitHub, Email, Phone Number)
                if (uiState.showAuthModal) {
                    KnightsAuthModal(
                        userId = uiState.currentUserId,
                        userEmail = uiState.currentUserEmail,
                        userName = uiState.currentUserName,
                        authProvider = uiState.authProvider,
                        onDismiss = { viewModel.setShowAuthModal(false) },
                        onLoginSuccess = { provider, name, identifier, uid ->
                            viewModel.completeMultiProviderLogin(provider, name, identifier, uid)
                        },
                        onSignOut = { viewModel.signOutAllProviders() },
                        onOpenSettings = {
                            viewModel.selectTab(KnightsTab.VAULT)
                        }
                    )
                }

                // Per-Agent Customization, Internet Toggle, Local AI Binding & Task Trigger Modal
                val customizingAgent = uiState.allKnights.find { it.id == uiState.customizingKnightId }
                if (customizingAgent != null) {
                    AgentCustomizerModal(
                        agent = customizingAgent,
                        execState = uiState.agentExecutionStates[customizingAgent.id],
                        localAiModels = uiState.localAiModels,
                        onDismiss = { viewModel.openCustomizeAgentModal(null) },
                        onSaveCustomization = { codename, description, instruction, internetEnabled, localModelId, capabilities ->
                            viewModel.customizeAgent(
                                agentId = customizingAgent.id,
                                codename = codename,
                                description = description,
                                instruction = instruction,
                                internetEnabled = internetEnabled,
                                localModelId = localModelId,
                                capabilities = capabilities
                            )
                        },
                        onInstallLocalModel = { modelId ->
                            viewModel.installLocalAiModel(modelId)
                        },
                        onTriggerTask = { taskPrompt ->
                            viewModel.triggerAgentTask(customizingAgent.id, taskPrompt)
                        }
                    )
                }

                ModalNavigationDrawer(
                    drawerState = drawerState,
                    drawerContent = {
                        GeminiDrawerContent(
                            currentTab = uiState.currentTab,
                            selectedSquadron = uiState.selectedSquadron,
                            hardwareInfo = uiState.deviceHardwareInfo,
                            recentDeliverables = uiState.vaultDeliverables,
                            activeMemoryCount = if (uiState.isGlobalMemoryEnabled) uiState.memories.count { it.isEnabled } else 0,
                            installedLocalModelsCount = uiState.localAiModels.count { it.isInstalled },
                            userName = uiState.currentUserName,
                            userEmail = uiState.currentUserEmail,
                            isSignedIn = uiState.currentUserId != null,
                            onNewSessionClick = {
                                viewModel.startNewGeminiSession()
                                coroutineScope.launch { drawerState.close() }
                            },
                            onCloseDrawer = {
                                coroutineScope.launch { drawerState.close() }
                            },
                            onTabSelected = { tab ->
                                viewModel.selectTab(tab)
                                coroutineScope.launch { drawerState.close() }
                            },
                            onSquadronSelected = { squadron ->
                                viewModel.selectSquadron(squadron)
                                viewModel.selectTab(KnightsTab.TERMINAL)
                                coroutineScope.launch { drawerState.close() }
                            },
                            onDeliverableSelected = { _ ->
                                viewModel.selectTab(KnightsTab.LIBRARY)
                                coroutineScope.launch { drawerState.close() }
                            },
                            onOpenAuthModal = {
                                coroutineScope.launch { drawerState.close() }
                                viewModel.setShowAuthModal(true)
                            }
                        )
                    }
                ) {
                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        snackbarHost = { SnackbarHost(snackbarHostState) },
                        contentWindowInsets = WindowInsets.safeDrawing,
                        containerColor = KnightsPureBlack
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(KnightsPureBlack)
                                .padding(innerPadding)
                                .padding(horizontal = 8.dp)
                        ) {
                            Column(modifier = Modifier.fillMaxSize()) {
                                GeminiTopBar(
                                    activeModel = uiState.activeModel,
                                    isGridView = uiState.isAgentGridView,
                                    isMissionRunning = uiState.isMissionRunning,
                                    showTerminalConsole = uiState.showTerminalConsole,
                                    hardwareInfo = uiState.deviceHardwareInfo,
                                    activeMemoryCount = if (uiState.isGlobalMemoryEnabled) uiState.memories.count { it.isEnabled } else 0,
                                    installedLocalAiCount = uiState.localAiModels.count { it.isInstalled },
                                    isCloudSignedIn = uiState.currentUserId != null,
                                    isTemporaryChat = uiState.isTemporaryChat,
                                    userName = uiState.currentUserName,
                                    allKnights = uiState.allKnights,
                                    onMenuClick = {
                                        coroutineScope.launch { drawerState.open() }
                                    },
                                    onModelSelected = { model ->
                                        viewModel.selectActiveModel(model)
                                    },
                                    onToggleGridList = {
                                        viewModel.toggleAgentViewLayout()
                                    },
                                    onToggleTerminal = {
                                        viewModel.selectTab(KnightsTab.TERMINAL)
                                        viewModel.toggleTerminalConsole()
                                    },
                                    onToggleTemporaryChat = {
                                        viewModel.toggleTemporaryChat()
                                    },
                                    onSelectSoloKnight = { knightId ->
                                        viewModel.selectSoloKnight(knightId)
                                    },
                                    onOpenAuthModal = {
                                        viewModel.setShowAuthModal(true)
                                    },
                                    onOpenSettings = {
                                        viewModel.selectTab(KnightsTab.VAULT)
                                    }
                                )

                                // Prompt E: Subtle motion (fade + slide on screen changes)
                                AnimatedContent(
                                    targetState = uiState.currentTab,
                                    transitionSpec = {
                                        (fadeIn(animationSpec = tween(220)) +
                                            slideInVertically(animationSpec = tween(220)) { it / 18 })
                                            .togetherWith(
                                                fadeOut(animationSpec = tween(160)) +
                                                    slideOutVertically(animationSpec = tween(160)) { -it / 24 }
                                            )
                                    },
                                    label = "knightsScreenTransition",
                                    modifier = Modifier.weight(1f)
                                ) { targetTab ->
                                    when (targetTab) {
                                        KnightsTab.TERMINAL -> {
                                            TerminalScreen(
                                                uiState = uiState,
                                                onCommandChanged = { viewModel.updateCommandInput(it) },
                                                onSquadronSelected = { viewModel.selectSquadron(it) },
                                                onSoloKnightSelected = { viewModel.selectSoloKnight(it) },
                                                onModeChanged = { viewModel.setTerminalMode(it) },
                                                onDeployClicked = { viewModel.deployMission() },
                                                onClearLogsClicked = { viewModel.clearTerminalLogs() },
                                                onTaskModeChanged = { viewModel.setTaskMode(it) },
                                                onToggleGridList = { viewModel.toggleAgentViewLayout() },
                                                onSquadronFilterChanged = { viewModel.setSquadronFilter(it) },
                                                onToggleTerminalConsole = { show -> viewModel.toggleTerminalConsole(show) },
                                                onTriggerAgentTask = { agentId -> viewModel.triggerAgentTask(agentId) },
                                                onCustomizeAgent = { agentId -> viewModel.openCustomizeAgentModal(agentId) },
                                                onOpenMemorySettings = { viewModel.selectTab(KnightsTab.VAULT) },
                                                onOpenLocalAiHub = { viewModel.selectTab(KnightsTab.FORGE) }
                                            )
                                        }

                                        KnightsTab.LIBRARY -> {
                                            LibraryScreen(
                                                deliverables = uiState.vaultDeliverables,
                                                searchQuery = uiState.vaultSearchQuery,
                                                onSearchChanged = { viewModel.updateVaultSearchQuery(it) },
                                                onDeleteDeliverable = { viewModel.deleteDeliverable(it) }
                                            )
                                        }

                                        KnightsTab.SCHEDULED -> {
                                            ScheduledScreen(
                                                scheduledTasks = uiState.scheduledTasks,
                                                onToggleSchedule = { viewModel.toggleScheduledTask(it) },
                                                onRunNow = { viewModel.runScheduledTaskNow(it) }
                                            )
                                        }

                                        KnightsTab.ROSTER -> {
                                            RosterScreen(
                                                knights = uiState.allKnights,
                                                executionStates = uiState.agentExecutionStates,
                                                isGridView = uiState.isAgentGridView,
                                                onSelectKnightSolo = { viewModel.selectSoloKnight(it) },
                                                onTriggerTaskForKnight = { agentId ->
                                                    viewModel.triggerAgentTask(agentId)
                                                },
                                                onCustomizeKnight = { agentId ->
                                                    viewModel.openCustomizeAgentModal(agentId)
                                                },
                                                onToggleInternetForKnight = { agentId ->
                                                    viewModel.toggleAgentInternet(agentId)
                                                },
                                                onToggleGridList = {
                                                    viewModel.toggleAgentViewLayout()
                                                },
                                                onOpenYouTubeLab = {
                                                    viewModel.selectTab(KnightsTab.YT_LAB)
                                                }
                                            )
                                        }

                                        KnightsTab.YT_LAB -> {
                                            YouTubeLabScreen(
                                                params = uiState.ytParams,
                                                onViewsChanged = { viewModel.updateYouTubeViews(it) },
                                                onRpmChanged = { viewModel.updateYouTubeRpm(it) },
                                                onCtrChanged = { viewModel.updateYouTubeCtr(it) },
                                                onAvdChanged = { viewModel.updateYouTubeAvd(it) },
                                                onLaunchSquadronClicked = { viewModel.launchYouTubeSquadronWithMetrics() }
                                            )
                                        }

                                        KnightsTab.FORGE -> {
                                            ForgeScreen(
                                                blueprintJson = uiState.blueprintJson,
                                                localAiModels = uiState.localAiModels,
                                                selectedSubTab = uiState.customizeSubTab,
                                                skillPacks = uiState.skillPacks,
                                                installedSkills = uiState.installedSkills,
                                                connectors = uiState.connectors,
                                                skillDraftName = uiState.skillDraftName,
                                                skillDraftMarkdown = uiState.skillDraftMarkdown,
                                                onSubTabSelected = { viewModel.setCustomizeSubTab(it) },
                                                onToggleSkillPack = { viewModel.toggleSkillPack(it) },
                                                onAddConnector = { name, type, url ->
                                                    viewModel.addConnector(name, type, url)
                                                },
                                                onRemoveConnector = { viewModel.removeConnector(it) },
                                                onToggleInstalledSkill = { viewModel.toggleInstalledSkill(it) },
                                                onImportSkillFromGithub = { viewModel.importSkillFromGithubUrl(it) },
                                                onPasteSkillMarkdown = { name, md ->
                                                    viewModel.pasteSkillMarkdown(name, md)
                                                },
                                                onDraftSkillWithPrompt = { viewModel.draftSkillWithPrompt(it) },
                                                onApproveSkillDraft = { viewModel.approveSkillDraft() },
                                                onDiscardSkillDraft = { viewModel.discardSkillDraft() },
                                                onInstallLocalModel = { viewModel.installLocalAiModel(it) },
                                                onUninstallLocalModel = { viewModel.uninstallLocalAiModel(it) },
                                                onBindLocalModelToAll = { viewModel.bindLocalAiToAllAgents(it) },
                                                onForgeCustomKnight = { id, code, desc, prompt ->
                                                    viewModel.forgeCustomKnight(id, code, desc, prompt)
                                                },
                                                onSaveBlueprint = { viewModel.saveBlueprintJson(it) },
                                                onResetBlueprint = { viewModel.resetBlueprintToDefault() }
                                            )
                                        }

                                        KnightsTab.VAULT -> {
                                            VaultScreen(
                                                deliverables = uiState.vaultDeliverables,
                                                searchQuery = uiState.vaultSearchQuery,
                                                onSearchChanged = { viewModel.updateVaultSearchQuery(it) },
                                                onDeleteDeliverable = { viewModel.deleteDeliverable(it) },
                                                apiKey = uiState.apiKey,
                                                modelName = uiState.activeModel,
                                                commanderPrefs = uiState.commanderPrefs,
                                                onSaveSettings = { key, model, prefs ->
                                                    viewModel.saveCoreSettings(key, model, prefs)
                                                },
                                                memories = uiState.memories,
                                                isGlobalMemoryEnabled = uiState.isGlobalMemoryEnabled,
                                                onToggleGlobalMemory = { viewModel.toggleGlobalMemoryEnabled(it) },
                                                onAddMemory = { content, category ->
                                                    viewModel.addMemoryItem(content, category)
                                                },
                                                onToggleMemoryItem = { viewModel.toggleMemoryItem(it) },
                                                onDeleteMemoryItem = { viewModel.deleteMemoryItem(it) },
                                                currentUserId = uiState.currentUserId,
                                                currentUserEmail = uiState.currentUserEmail,
                                                currentUserName = uiState.currentUserName,
                                                authProvider = uiState.authProvider,
                                                onMultiProviderLogin = { provider, name, identifier, uid ->
                                                    viewModel.completeMultiProviderLogin(provider, name, identifier, uid)
                                                },
                                                onSignOut = { viewModel.signOutAllProviders() },
                                                onAuthChanged = { viewModel.refreshAuthState() },
                                                onShowMessage = { viewModel.showSnackbar(it) }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
