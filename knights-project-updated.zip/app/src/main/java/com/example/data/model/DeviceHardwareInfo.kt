package com.example.data.model

data class DeviceHardwareInfo(
    val totalRamBytes: Long,
    val availableRamBytes: Long,
    val isRamSufficient: Boolean, // >= 6.0 GB (e.g. 6_000_000_000 bytes)
    val totalRamGbFormatted: String,
    val availableRamGbFormatted: String,
    val cpuCores: Int,
    val deviceModel: String,
    val androidVersion: String
) {
    val telemetrySummary: String
        get() = "$totalRamGbFormatted Physical RAM • $cpuCores Cores • Android $androidVersion"
}
