package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.Deliverable

@Database(entities = [Deliverable::class], version = 1, exportSchema = false)
abstract class KnightsDatabase : RoomDatabase() {
    abstract fun deliverableDao(): DeliverableDao

    companion object {
        @Volatile
        private var INSTANCE: KnightsDatabase? = null

        fun getInstance(context: Context): KnightsDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    KnightsDatabase::class.java,
                    "knights_vault.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
