package com.example.data.repository

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * "auto" = ask the Gemini API which models this key can use and pick the newest stable Flash model.
 * Falls back to the gemini-flash-latest alias if the list cannot be read. Result is cached for 6 hours.
 */
object ModelResolver {
    const val AUTO = "auto"
    private const val FALLBACK = "gemini-flash-latest"
    private const val CACHE_MS = 6 * 60 * 60 * 1000L
    @Volatile private var cached: Pair<Long, String>? = null

    fun resolve(requested: String, apiKey: String): String {
        if (requested != AUTO) return requested
        val c = cached
        if (c != null && System.currentTimeMillis() - c.first < CACHE_MS) return c.second
        val picked = try { newestStableFlash(apiKey) } catch (_: Exception) { null } ?: FALLBACK
        cached = System.currentTimeMillis() to picked
        return picked
    }

    private fun newestStableFlash(apiKey: String): String? {
        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200")
            .openConnection() as HttpURLConnection
        conn.setRequestProperty("x-goog-api-key", apiKey)
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        try {
            if (conn.responseCode != 200) return null
            val models = JSONObject(conn.inputStream.bufferedReader().readText()).optJSONArray("models") ?: return null
            // Stable Flash only: names like models/gemini-3.5-flash (no -lite, -preview, -image, -live, -tts)
            val rx = Regex("^models/gemini-(\\d+)(?:\\.(\\d+))?-flash$")
            var bestScore = -1
            var best: String? = null
            for (i in 0 until models.length()) {
                val m = models.getJSONObject(i)
                val name = m.optString("name")
                val match = rx.find(name) ?: continue
                val methods = m.optJSONArray("supportedGenerationMethods") ?: continue
                if ((0 until methods.length()).none { methods.getString(it) == "generateContent" }) continue
                val score = match.groupValues[1].toInt() * 1000 + (match.groupValues[2].toIntOrNull() ?: 0)
                if (score > bestScore) { bestScore = score; best = name.removePrefix("models/") }
            }
            return best
        } finally {
            conn.disconnect()
        }
    }
}
