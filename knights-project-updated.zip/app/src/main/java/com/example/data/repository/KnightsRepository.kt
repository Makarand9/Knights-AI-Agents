package com.example.data.repository

import android.content.Context
import com.example.data.local.KnightsDatabase
import com.example.data.local.KnightsPreferences
import com.example.data.model.DEFAULT_GEMINI_MEMORIES
import com.example.data.model.DefaultKnightsOrder
import com.example.data.model.Deliverable
import com.example.data.model.DeviceHardwareInfo
import com.example.data.model.KnightAgent
import com.example.data.model.KnightExecutionState
import com.example.data.model.TerminalLog
import com.example.data.model.UserMemoryItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharedFlow
import org.json.JSONArray
import org.json.JSONObject

class KnightsRepository(context: Context) {
    private val database = KnightsDatabase.getInstance(context)
    private val deliverableDao = database.deliverableDao()
    private val preferences = KnightsPreferences(context)
    private val telemetryService = HardwareTelemetryService(context)
    private val executor = GeminiAgentExecutor(deliverableDao)

    val logStream: SharedFlow<TerminalLog> = executor.logFlow
    val allDeliverables: Flow<List<Deliverable>> = deliverableDao.getAllDeliverables()

    fun searchDeliverables(query: String): Flow<List<Deliverable>> {
        return if (query.isBlank()) {
            deliverableDao.getAllDeliverables()
        } else {
            deliverableDao.searchDeliverables(query)
        }
    }

    suspend fun seedInitialWelcomeDeliverableIfNeeded() {
        if (!preferences.hasInitializedSeed) {
            val count = deliverableDao.getCount()
            if (count == 0) {
                deliverableDao.insertDeliverable(
                    Deliverable(
                        title = "Knights 9-Agent Order Genesis Blueprint",
                        authorKnight = "Grand Commander",
                        category = "system",
                        content = """
# ✦ KNIGHTS GEMINI 9-AGENT STUDIO ONLINE
Welcome to **Knights** — The Autonomous Multi-Domain AI Order with Live Internet Grounding, On-Device Local AI, and Persistent Gemini Memory.

### The 9 Customizable Autonomous Agents:
1. **Knight I • Vanguard Scout:** Trend, Market & Live Web Intelligence
2. **Knight II • Oracle Strategist:** SEO, Packaging, Funnel & Growth Strategy
3. **Knight III • Bard Scriptwriter:** Narrative Architecture, Copy & Retention Scripts
4. **Knight IV • Artificer Visuals:** Multimodal Direction, UI/UX & Visual Prompts
5. **Knight V • Marshal Director:** End-to-End Production & Master Compilation
6. **Knight VI • Strategos Architect:** Systems Design, Roadmaps & Task Decomposition
7. **Knight VII • Scholar Intelligence:** Deep Web Fact-Checking & Primary Citations
8. **Knight VIII • Forgemaster Engineer:** Full-Stack Code, Schemas & Formal Math
9. **Knight IX • Sentinel Auditor:** Security, Stress-Testing & Executive Polish

---
### Full Customization, Internet & Local AI:
- Every agent is **unrestricted** and can execute **any task** across any domain.
- Toggle **Live Internet Access** per agent or bind an **On-Device Local AI Model** (`Gemma 3 Nano 4B`, `Gemini Nano 2`, `Qwen 2.5 Coder 3B`, `DeepSeek R1 1.5B`, `Llama 3.2 3B`).
- Configure **Gemini Saved Info (Memories)** in Settings so all 9 agents remember your standing preferences.
                        """.trimIndent(),
                        timestampMs = System.currentTimeMillis()
                    )
                )
            }
            preferences.hasInitializedSeed = true
        }
    }

    fun getDeviceHardwareInfo(): DeviceHardwareInfo {
        return telemetryService.getDeviceHardwareInfo()
    }

    fun getAllKnights(): List<KnightAgent> {
        val baseList = DefaultKnightsOrder.ALL_9_KNIGHTS.toMutableList()
        val customJson = preferences.customKnightsJson
        if (customJson.isNotBlank()) {
            try {
                val array = JSONArray(customJson)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val id = obj.getString("id")
                    if (baseList.any { it.id == id }) continue
                    val toolsList = mutableListOf<String>()
                    val toolsArr = obj.optJSONArray("tools")
                    if (toolsArr != null) {
                        for (j in 0 until toolsArr.length()) {
                            toolsList.add(toolsArr.getString(j))
                        }
                    }
                    val capsList = mutableListOf<String>()
                    val capsArr = obj.optJSONArray("capabilities")
                    if (capsArr != null) {
                        for (j in 0 until capsArr.length()) {
                            capsList.add(capsArr.getString(j))
                        }
                    }
                    baseList.add(
                        KnightAgent(
                            id = id,
                            name = obj.optString("name", id),
                            codename = obj.optString("codename", "Custom Knight • $id"),
                            squadron = obj.optString("squadron", "custom"),
                            description = obj.optString("description", "Custom multi-domain autonomous agent"),
                            tools = if (toolsList.isNotEmpty()) toolsList else listOf("google_search", "save_to_library"),
                            outputKey = obj.optString("output_key", "${id}_output"),
                            instruction = obj.getString("instruction"),
                            orderNumber = baseList.size + 1,
                            badgeColorHex = "#81C995",
                            internetEnabled = obj.optBoolean("internetEnabled", true),
                            localModelId = obj.optString("localModelId", "gemma-3-nano-4b-q4"),
                            capabilities = if (capsList.isNotEmpty()) capsList else listOf(
                                "Multi-Domain Reasoning",
                                "Live Web Grounding",
                                "Local AI Execution",
                                "Code & Synthesis"
                            )
                        )
                    )
                }
            } catch (_: Exception) {
            }
        }

        // Apply per-agent customization overrides (works for all 9 built-in agents + custom agents)
        val overridesMap = loadAgentOverridesMap()
        return baseList.map { agent ->
            val overrideObj = overridesMap[agent.id] ?: return@map agent
            val capsList = mutableListOf<String>()
            val capsArr = overrideObj.optJSONArray("capabilities")
            if (capsArr != null) {
                for (j in 0 until capsArr.length()) {
                    capsList.add(capsArr.getString(j))
                }
            }
            val toolsList = mutableListOf<String>()
            val toolsArr = overrideObj.optJSONArray("tools")
            if (toolsArr != null) {
                for (j in 0 until toolsArr.length()) {
                    toolsList.add(toolsArr.getString(j))
                }
            }
            agent.copy(
                codename = overrideObj.optString("codename", agent.codename).ifBlank { agent.codename },
                description = overrideObj.optString("description", agent.description).ifBlank { agent.description },
                instruction = overrideObj.optString("instruction", agent.instruction).ifBlank { agent.instruction },
                internetEnabled = overrideObj.optBoolean("internetEnabled", agent.internetEnabled),
                localModelId = overrideObj.optString("localModelId", agent.localModelId).ifBlank { agent.localModelId },
                capabilities = if (capsList.isNotEmpty()) capsList else agent.capabilities,
                tools = if (toolsList.isNotEmpty()) toolsList else agent.tools,
                lastTaskSummary = overrideObj.optString("lastTaskSummary", agent.lastTaskSummary)
                    .takeIf { it.isNotBlank() } ?: agent.lastTaskSummary,
                tasksCompletedCount = overrideObj.optInt("tasksCompletedCount", agent.tasksCompletedCount)
            )
        }
    }

    private fun loadAgentOverridesMap(): MutableMap<String, JSONObject> {
        val map = mutableMapOf<String, JSONObject>()
        val raw = preferences.agentOverridesJson
        if (raw.isBlank()) return map
        try {
            val root = JSONObject(raw)
            val keys = root.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                root.optJSONObject(k)?.let { map[k] = it }
            }
        } catch (_: Exception) {
        }
        return map
    }

    fun saveAgentOverride(updatedAgent: KnightAgent) {
        val map = loadAgentOverridesMap()
        val obj = JSONObject().apply {
            put("codename", updatedAgent.codename)
            put("description", updatedAgent.description)
            put("instruction", updatedAgent.instruction)
            put("internetEnabled", updatedAgent.internetEnabled)
            put("localModelId", updatedAgent.localModelId)
            put("capabilities", JSONArray(updatedAgent.capabilities))
            put("tools", JSONArray(updatedAgent.tools))
            put("lastTaskSummary", updatedAgent.lastTaskSummary ?: "")
            put("tasksCompletedCount", updatedAgent.tasksCompletedCount)
        }
        map[updatedAgent.id] = obj
        val root = JSONObject()
        map.forEach { (k, v) -> root.put(k, v) }
        preferences.agentOverridesJson = root.toString()
    }

    fun addCustomKnight(knight: KnightAgent) {
        val currentJson = preferences.customKnightsJson
        val array = if (currentJson.isNotBlank()) {
            try { JSONArray(currentJson) } catch (_: Exception) { JSONArray() }
        } else {
            JSONArray()
        }

        val obj = JSONObject().apply {
            put("id", knight.id)
            put("name", knight.name)
            put("codename", knight.codename)
            put("description", knight.description)
            put("instruction", knight.instruction)
            put("output_key", knight.outputKey)
            put("tools", JSONArray(knight.tools))
            put("internetEnabled", knight.internetEnabled)
            put("localModelId", knight.localModelId)
            put("capabilities", JSONArray(knight.capabilities))
        }
        array.put(obj)
        preferences.customKnightsJson = array.toString()
    }

    fun saveFullKnightsJson(jsonString: String): Boolean {
        return try {
            val obj = JSONObject(jsonString)
            if (obj.has("agents")) {
                preferences.customKnightsJson = obj.getJSONArray("agents").toString()
                true
            } else {
                false
            }
        } catch (_: Exception) {
            false
        }
    }

    fun resetToDefaultOrder() {
        preferences.customKnightsJson = ""
        preferences.agentOverridesJson = ""
    }

    fun getInstalledLocalModelIds(): Set<String> {
        return preferences.installedLocalModelsCsv
            .split(",")
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .toSet()
    }

    fun setInstalledLocalModelIds(ids: Set<String>) {
        preferences.installedLocalModelsCsv = ids.joinToString(",")
    }

    fun getMemories(): List<UserMemoryItem> {
        val raw = preferences.memoriesJson
        if (raw.isBlank()) {
            saveMemories(DEFAULT_GEMINI_MEMORIES)
            return DEFAULT_GEMINI_MEMORIES
        }
        return try {
            val arr = JSONArray(raw)
            val list = mutableListOf<UserMemoryItem>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    UserMemoryItem(
                        id = o.getString("id"),
                        content = o.getString("content"),
                        category = o.optString("category", "Preference"),
                        isEnabled = o.optBoolean("isEnabled", true),
                        createdAtEpochMs = o.optLong("createdAtEpochMs", System.currentTimeMillis())
                    )
                )
            }
            list
        } catch (_: Exception) {
            DEFAULT_GEMINI_MEMORIES
        }
    }

    fun saveMemories(memories: List<UserMemoryItem>) {
        val arr = JSONArray()
        memories.forEach { m ->
            arr.put(
                JSONObject().apply {
                    put("id", m.id)
                    put("content", m.content)
                    put("category", m.category)
                    put("isEnabled", m.isEnabled)
                    put("createdAtEpochMs", m.createdAtEpochMs)
                }
            )
        }
        preferences.memoriesJson = arr.toString()
    }

    fun isGlobalMemoryEnabled(): Boolean = preferences.isGlobalMemoryEnabled
    fun setGlobalMemoryEnabled(enabled: Boolean) {
        preferences.isGlobalMemoryEnabled = enabled
    }

    fun getApiKey(): String = preferences.customApiKey
    fun setApiKey(key: String) { preferences.customApiKey = key }

    fun getActiveModel(): String = preferences.activeModel
    fun setActiveModel(model: String) { preferences.activeModel = model }

    fun getCommanderPrefs(): String = preferences.commanderPreferences
    fun setCommanderPrefs(prefs: String) { preferences.commanderPreferences = prefs }

    suspend fun saveDeliverable(deliverable: Deliverable): Long {
        return deliverableDao.insertDeliverable(deliverable)
    }

    suspend fun deleteDeliverable(deliverable: Deliverable) {
        deliverableDao.deleteDeliverable(deliverable)
    }

    suspend fun executeMission(
        targetId: String,
        prompt: String,
        onAgentStateUpdated: (Map<String, KnightExecutionState>) -> Unit,
        onMissionFinished: (Deliverable?) -> Unit
    ) {
        val allAgents = getAllKnights()
        val apiKey = getResolvedApiKey()
        val model = getActiveModel()
        val prefs = getCommanderPrefs()
        val activeMemories = if (isGlobalMemoryEnabled()) {
            getMemories().filter { it.isEnabled }
        } else {
            emptyList()
        }

        executor.executeMission(
            targetId = targetId,
            prompt = prompt,
            allAgents = allAgents,
            apiKey = apiKey,
            modelName = model,
            commanderPrefs = prefs,
            activeMemories = activeMemories,
            onAgentStateUpdated = onAgentStateUpdated,
            onMissionFinished = onMissionFinished
        )
    }

    private fun getResolvedApiKey(): String {
        val custom = preferences.customApiKey
        if (custom.isNotBlank()) return custom

        return try {
            val field = com.example.BuildConfig::class.java.getField("GEMINI_API_KEY")
            field.get(null) as? String ?: ""
        } catch (_: Throwable) {
            ""
        }
    }
}
