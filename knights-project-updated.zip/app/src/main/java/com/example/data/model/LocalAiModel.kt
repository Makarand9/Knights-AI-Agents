package com.example.data.model

data class LocalAiModel(
    val id: String,
    val name: String,
    val family: String,
    val parameters: String,
    val quantization: String,
    val sizeMb: Int,
    val contextWindow: String,
    val description: String,
    val capabilities: List<String>,
    val isInstalled: Boolean = false,
    val isInstalling: Boolean = false,
    val installProgress: Float = 0f
)

data class UserMemoryItem(
    val id: String,
    val content: String,
    val category: String = "Preference",
    val isEnabled: Boolean = true,
    val createdAtEpochMs: Long = System.currentTimeMillis()
)

data class AgentTaskExecutionRecord(
    val id: String,
    val agentId: String,
    val agentName: String,
    val taskPrompt: String,
    val status: String,
    val usedInternet: Boolean,
    val localModelId: String,
    val resultSummary: String,
    val durationMs: Long,
    val createdAtEpochMs: Long = System.currentTimeMillis()
)

enum class AuthProviderType(val label: String) {
    NONE("Not Signed In"),
    GOOGLE("Google Account"),
    GITHUB("GitHub Account"),
    EMAIL("Email Account"),
    PHONE("Phone Verified")
}

data class SkillPackItem(
    val id: String,
    val title: String,
    val description: String,
    val section: String, // "Everyday tools" or "Business essentials"
    val iconKey: String,
    val isAdded: Boolean = false
)

data class InstalledSkillItem(
    val id: String,
    val name: String,
    val source: String,
    val markdownContent: String,
    val isEnabled: Boolean = true
)

data class ConnectorItem(
    val id: String,
    val name: String,
    val type: String, // "OpenAPI" or "MCP Server"
    val endpointUrl: String,
    val isConnected: Boolean = true
)

data class ScheduledTaskItem(
    val id: String,
    val title: String,
    val description: String,
    val cadence: String,
    val promptToRun: String,
    val isScheduled: Boolean = false
)

val DEFAULT_SKILL_PACKS = listOf(
    SkillPackItem(
        id = "youtube_studio",
        title = "YouTube Studio",
        description = "Analyze RPM, hooks, scripts, and high-CTR thumbnail concepts.",
        section = "Everyday tools",
        iconKey = "video",
        isAdded = true
    ),
    SkillPackItem(
        id = "deep_research",
        title = "Research",
        description = "Multi-source synthesis, citation verification, and web grounding.",
        section = "Everyday tools",
        iconKey = "search",
        isAdded = true
    ),
    SkillPackItem(
        id = "writing_style",
        title = "Writing style",
        description = "Adapt tone, executive clarity, and structured storytelling.",
        section = "Everyday tools",
        iconKey = "edit",
        isAdded = false
    ),
    SkillPackItem(
        id = "meeting_prep",
        title = "Meeting prep",
        description = "Briefings, stakeholder talking points, and follow-up actions.",
        section = "Business essentials",
        iconKey = "calendar",
        isAdded = false
    ),
    SkillPackItem(
        id = "code_architect",
        title = "Systems & API Architect",
        description = "Production Kotlin, Python, OpenAPI schemas, and security audits.",
        section = "Business essentials",
        iconKey = "code",
        isAdded = true
    ),
    SkillPackItem(
        id = "market_intel",
        title = "Market intelligence",
        description = "Competitor matrices, pricing benchmarks, and growth funnels.",
        section = "Business essentials",
        iconKey = "analytics",
        isAdded = false
    )
)

val DEFAULT_INSTALLED_SKILLS = listOf(
    InstalledSkillItem(
        id = "skill_yt_viral",
        name = "youtube-viral-packager",
        source = "Built-in • Sir Gawain & Sir Percivale",
        markdownContent = "---\nname: youtube-viral-packager\ndescription: Builds high-retention scripts, 3-second hooks, and SEO metadata.\n---\nAlways structure scripts with Hook (0-15s), Tension Loop, Proof, and CTA.",
        isEnabled = true
    ),
    InstalledSkillItem(
        id = "skill_web_grounding",
        name = "live-web-grounding",
        source = "Built-in • Sir Tristan & Sir Galahad",
        markdownContent = "---\nname: live-web-grounding\ndescription: Connects all 9 Knights to live search and verifiable citations.\n---\nVerify all claims against live web data and cite primary sources.",
        isEnabled = true
    ),
    InstalledSkillItem(
        id = "skill_local_npu",
        name = "on-device-npu-router",
        source = "Built-in • Sir Lancelot",
        markdownContent = "---\nname: on-device-npu-router\ndescription: Routes tasks to installed Gemma 3 Nano / Qwen local models when offline.\n---\nPrefer hybrid cloud + on-device NPU co-processing.",
        isEnabled = true
    )
)

val DEFAULT_CONNECTORS = listOf(
    ConnectorItem(
        id = "conn_yt_data",
        name = "YouTube Analytics OpenAPI",
        type = "OpenAPI",
        endpointUrl = "https://www.googleapis.com/discovery/v1/apis/youtube/v3/rest",
        isConnected = true
    ),
    ConnectorItem(
        id = "conn_mcp_github",
        name = "GitHub Repository MCP Server",
        type = "MCP Server",
        endpointUrl = "https://mcp.github.com/v1/sse",
        isConnected = true
    )
)

val DEFAULT_SCHEDULED_SUGGESTIONS = listOf(
    ScheduledTaskItem(
        id = "sched_yt_trends",
        title = "Weekly YouTube trend report",
        description = "Every Monday at 8:00 AM • Scans breakout topics, RPM shifts, and 5 viral video angles.",
        cadence = "Weekly • Mon 8:00 AM",
        promptToRun = "Generate this week's YouTube trend report with 5 breakout topics, RPM analysis, and high-CTR titles.",
        isScheduled = true
    ),
    ScheduledTaskItem(
        id = "sched_daily_research",
        title = "Daily research digest",
        description = "Every day at 7:30 AM • Summarizes AI, engineering, and market breakthroughs with citations.",
        cadence = "Daily • 7:30 AM",
        promptToRun = "Compile today's executive research digest across AI models, developer tools, and market shifts.",
        isScheduled = false
    ),
    ScheduledTaskItem(
        id = "sched_skill_audit",
        title = "Autonomous skill & security audit",
        description = "Every Friday at 5:00 PM • Audits installed SKILL.md files, API connectors, and agent prompts.",
        cadence = "Weekly • Fri 5:00 PM",
        promptToRun = "Audit all 9 Knights configurations, active SKILL.md definitions, and API connectors for optimization.",
        isScheduled = false
    )
)

val DEFAULT_LOCAL_AI_MODELS = listOf(
    LocalAiModel(
        id = "gemma-3-nano-4b-q4",
        name = "Gemma 3 Nano 4B",
        family = "Google DeepMind On-Device",
        parameters = "4.0B",
        quantization = "INT4 AWQ",
        sizeMb = 2140,
        contextWindow = "32K tokens",
        description = "Ultra-fast local NPU reasoning, coding, and tool-use engine optimized for mobile neural accelerators.",
        capabilities = listOf("Reasoning", "Code Synthesis", "Offline Execution", "Function Calling"),
        isInstalled = true,
        isInstalling = false,
        installProgress = 1.0f
    ),
    LocalAiModel(
        id = "gemini-nano-2-multimodal",
        name = "Gemini Nano 2 Multimodal",
        family = "Google AICore Runtime",
        parameters = "3.25B",
        quantization = "INT4 LoRA",
        sizeMb = 1780,
        contextWindow = "16K tokens",
        description = "Low-latency on-device multimodal model for summarization, context grounding, and memory extraction.",
        capabilities = listOf("Summarization", "Memory Grounding", "Low Latency", "Privacy First"),
        isInstalled = false,
        isInstalling = false,
        installProgress = 0f
    ),
    LocalAiModel(
        id = "qwen-2.5-coder-3b-gguf",
        name = "Qwen 2.5 Coder 3B",
        family = "Local GGUF Runtime",
        parameters = "3.1B",
        quantization = "Q4_K_M",
        sizeMb = 1920,
        contextWindow = "32K tokens",
        description = "Specialized local code generation, static security analysis, and shell automation model.",
        capabilities = listOf("Kotlin/Python/Rust", "Security Audit", "AST Refactoring"),
        isInstalled = false,
        isInstalling = false,
        installProgress = 0f
    ),
    LocalAiModel(
        id = "deepseek-r1-distill-1.5b",
        name = "DeepSeek R1 Distill 1.5B",
        family = "Chain-of-Thought NPU",
        parameters = "1.5B",
        quantization = "Q4_0",
        sizeMb = 1050,
        contextWindow = "16K tokens",
        description = "Compact mathematical and formal logic verifier with local step-by-step chain-of-thought verification.",
        capabilities = listOf("Math & Logic", "Step Verification", "Ultra Lightweight"),
        isInstalled = false,
        isInstalling = false,
        installProgress = 0f
    ),
    LocalAiModel(
        id = "llama-3.2-3b-instruct-npu",
        name = "Llama 3.2 3B Instruct",
        family = "ExecuTorch Mobile",
        parameters = "3.2B",
        quantization = "SPINQUANT INT4",
        sizeMb = 1890,
        contextWindow = "128K tokens",
        description = "Long-context local instruction model for multi-agent planning and offline research synthesis.",
        capabilities = listOf("128K Context", "Agentic Planning", "Offline Research"),
        isInstalled = false,
        isInstalling = false,
        installProgress = 0f
    )
)

val DEFAULT_GEMINI_MEMORIES = listOf(
    UserMemoryItem(
        id = "mem-default-1",
        content = "Prefer clean, production-grade Kotlin with Jetpack Compose and Material 3 dark black styling.",
        category = "Coding Style",
        isEnabled = true
    ),
    UserMemoryItem(
        id = "mem-default-2",
        content = "All 9 autonomous agents can collaborate across any domain, browse live web sources, and fall back to installed local NPU models when offline.",
        category = "Agent Behavior",
        isEnabled = true
    ),
    UserMemoryItem(
        id = "mem-default-3",
        content = "Always include concise executive summaries and verifiable citations when Live Web Grounding is enabled.",
        category = "Output Format",
        isEnabled = true
    )
)
