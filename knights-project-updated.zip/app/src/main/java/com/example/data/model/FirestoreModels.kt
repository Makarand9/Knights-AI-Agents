package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class CustomAgentConfigDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val agentId: String = "",
    val codename: String = "",
    val squadron: String = "universal",
    val description: String = "",
    val instruction: String = "",
    val internetEnabled: Boolean = true,
    val localModelId: String = "none",
    val capabilities: String = "",
    val lastTaskSummary: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class UserMemoryItemDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val content: String = "",
    val category: String = "Preference",
    val enabled: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class AgentTaskRecordDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val agentId: String = "",
    val agentCodename: String = "",
    val prompt: String = "",
    val status: String = "completed",
    val output: String = "",
    val usedInternet: Boolean = true,
    val executionEngine: String = "gemini-3.5-flash",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
