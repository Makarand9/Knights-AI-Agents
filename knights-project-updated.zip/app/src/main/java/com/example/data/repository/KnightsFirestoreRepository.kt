package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.AgentTaskRecordDoc
import com.example.data.model.CustomAgentConfigDoc
import com.example.data.model.UserMemoryItemDoc
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class KnightsFirestoreRepository(
    private val db: FirebaseFirestore
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(context.getString(R.string.firestore_database_id))
    )

    fun observeAgentConfigs(userId: String): Flow<List<CustomAgentConfigDoc>> = callbackFlow {
        val path = "users/$userId/agents"
        val registration = db.collection("users")
            .document(userId)
            .collection("agents")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    try {
                        handleFirestoreError(error, OperationType.LIST, path)
                    } catch (e: Exception) {
                        close(e)
                    }
                    return@addSnapshotListener
                }
                val docs = snapshot?.toObjects(CustomAgentConfigDoc::class.java).orEmpty()
                trySend(docs)
            }
        awaitClose { registration.remove() }
    }

    suspend fun saveAgentConfig(userId: String, agentId: String, doc: CustomAgentConfigDoc) {
        val path = "users/$userId/agents/$agentId"
        try {
            db.collection("users")
                .document(userId)
                .collection("agents")
                .document(agentId)
                .set(doc.copy(userId = userId, agentId = agentId))
                .await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
        }
    }

    suspend fun getAgentConfig(userId: String, agentId: String): CustomAgentConfigDoc? {
        val path = "users/$userId/agents/$agentId"
        return try {
            val snap = db.collection("users")
                .document(userId)
                .collection("agents")
                .document(agentId)
                .get()
                .await()
            snap.toObject(CustomAgentConfigDoc::class.java)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            null
        }
    }

    suspend fun deleteAgentConfig(userId: String, agentId: String) {
        val path = "users/$userId/agents/$agentId"
        try {
            db.collection("users")
                .document(userId)
                .collection("agents")
                .document(agentId)
                .delete()
                .await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
        }
    }

    fun observeMemories(userId: String): Flow<List<UserMemoryItemDoc>> = callbackFlow {
        val path = "users/$userId/memories"
        val registration = db.collection("users")
            .document(userId)
            .collection("memories")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    try {
                        handleFirestoreError(error, OperationType.LIST, path)
                    } catch (e: Exception) {
                        close(e)
                    }
                    return@addSnapshotListener
                }
                val docs = snapshot?.toObjects(UserMemoryItemDoc::class.java).orEmpty()
                trySend(docs)
            }
        awaitClose { registration.remove() }
    }

    suspend fun saveMemory(userId: String, memoryId: String, doc: UserMemoryItemDoc) {
        val path = "users/$userId/memories/$memoryId"
        try {
            db.collection("users")
                .document(userId)
                .collection("memories")
                .document(memoryId)
                .set(doc.copy(userId = userId))
                .await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
        }
    }

    suspend fun deleteMemory(userId: String, memoryId: String) {
        val path = "users/$userId/memories/$memoryId"
        try {
            db.collection("users")
                .document(userId)
                .collection("memories")
                .document(memoryId)
                .delete()
                .await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
        }
    }

    fun observeTasks(userId: String): Flow<List<AgentTaskRecordDoc>> = callbackFlow {
        val path = "users/$userId/tasks"
        val registration = db.collection("users")
            .document(userId)
            .collection("tasks")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(40)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    try {
                        handleFirestoreError(error, OperationType.LIST, path)
                    } catch (e: Exception) {
                        close(e)
                    }
                    return@addSnapshotListener
                }
                val docs = snapshot?.toObjects(AgentTaskRecordDoc::class.java).orEmpty()
                trySend(docs)
            }
        awaitClose { registration.remove() }
    }

    suspend fun saveTaskRecord(userId: String, taskId: String, doc: AgentTaskRecordDoc) {
        val path = "users/$userId/tasks/$taskId"
        try {
            db.collection("users")
                .document(userId)
                .collection("tasks")
                .document(taskId)
                .set(doc.copy(userId = userId))
                .await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
        }
    }

    suspend fun deleteTaskRecord(userId: String, taskId: String) {
        val path = "users/$userId/tasks/$taskId"
        try {
            db.collection("users")
                .document(userId)
                .collection("tasks")
                .document(taskId)
                .delete()
                .await()
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
        }
    }
}
