package com.example.data.local

import android.content.Context
import android.content.SharedPreferences

class KnightsPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("knights_order_prefs", Context.MODE_PRIVATE)

    var customApiKey: String
        get() = prefs.getString(KEY_API_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_API_KEY, value).apply()

    var activeModel: String
        get() = prefs.getString(KEY_MODEL, "auto") ?: "auto"
        set(value) = prefs.edit().putString(KEY_MODEL, value).apply()

    var commanderPreferences: String
        get() = prefs.getString(KEY_COMMANDER_PREFS, "Clean, minimal, high-precision, zero fluff, data-backed.") ?: ""
        set(value) = prefs.edit().putString(KEY_COMMANDER_PREFS, value).apply()

    var customKnightsJson: String
        get() = prefs.getString(KEY_CUSTOM_KNIGHTS, "") ?: ""
        set(value) = prefs.edit().putString(KEY_CUSTOM_KNIGHTS, value).apply()

    var agentOverridesJson: String
        get() = prefs.getString(KEY_AGENT_OVERRIDES, "") ?: ""
        set(value) = prefs.edit().putString(KEY_AGENT_OVERRIDES, value).apply()

    var installedLocalModelsCsv: String
        get() = prefs.getString(KEY_INSTALLED_LOCAL_MODELS, "gemma-3-nano-4b-q4") ?: "gemma-3-nano-4b-q4"
        set(value) = prefs.edit().putString(KEY_INSTALLED_LOCAL_MODELS, value).apply()

    var memoriesJson: String
        get() = prefs.getString(KEY_MEMORIES_JSON, "") ?: ""
        set(value) = prefs.edit().putString(KEY_MEMORIES_JSON, value).apply()

    var isGlobalMemoryEnabled: Boolean
        get() = prefs.getBoolean(KEY_GLOBAL_MEMORY_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_GLOBAL_MEMORY_ENABLED, value).apply()

    var hasInitializedSeed: Boolean
        get() = prefs.getBoolean(KEY_SEEDED, false)
        set(value) = prefs.edit().putBoolean(KEY_SEEDED, value).apply()

    var authProvider: String
        get() = prefs.getString(KEY_AUTH_PROVIDER, "") ?: ""
        set(value) = prefs.edit().putString(KEY_AUTH_PROVIDER, value).apply()

    var authDisplayName: String
        get() = prefs.getString(KEY_AUTH_DISPLAY_NAME, "") ?: ""
        set(value) = prefs.edit().putString(KEY_AUTH_DISPLAY_NAME, value).apply()

    var authIdentifier: String
        get() = prefs.getString(KEY_AUTH_IDENTIFIER, "") ?: ""
        set(value) = prefs.edit().putString(KEY_AUTH_IDENTIFIER, value).apply()

    var installedSkillPacksCsv: String
        get() = prefs.getString(KEY_SKILL_PACKS, "youtube_studio,deep_research") ?: "youtube_studio,deep_research"
        set(value) = prefs.edit().putString(KEY_SKILL_PACKS, value).apply()

    companion object {
        private const val KEY_API_KEY = "custom_gemini_api_key"
        private const val KEY_MODEL = "selected_gemini_model"
        private const val KEY_COMMANDER_PREFS = "commander_instructions"
        private const val KEY_CUSTOM_KNIGHTS = "custom_knights_json"
        private const val KEY_AGENT_OVERRIDES = "agent_overrides_json"
        private const val KEY_INSTALLED_LOCAL_MODELS = "installed_local_models_csv"
        private const val KEY_MEMORIES_JSON = "gemini_saved_memories_json"
        private const val KEY_GLOBAL_MEMORY_ENABLED = "gemini_global_memory_enabled"
        private const val KEY_SEEDED = "initial_seed_completed"
        private const val KEY_AUTH_PROVIDER = "knights_auth_provider"
        private const val KEY_AUTH_DISPLAY_NAME = "knights_auth_display_name"
        private const val KEY_AUTH_IDENTIFIER = "knights_auth_identifier"
        private const val KEY_SKILL_PACKS = "knights_installed_skill_packs"
    }
}
