package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Deliverable
import kotlinx.coroutines.flow.Flow

@Dao
interface DeliverableDao {
    @Query("SELECT * FROM deliverables ORDER BY timestampMs DESC")
    fun getAllDeliverables(): Flow<List<Deliverable>>

    @Query("SELECT * FROM deliverables WHERE title LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%' ORDER BY timestampMs DESC")
    fun searchDeliverables(query: String): Flow<List<Deliverable>>

    @Query("SELECT * FROM deliverables WHERE id = :id LIMIT 1")
    suspend fun getDeliverableById(id: Long): Deliverable?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDeliverable(deliverable: Deliverable): Long

    @Update
    suspend fun updateDeliverable(deliverable: Deliverable)

    @Delete
    suspend fun deleteDeliverable(deliverable: Deliverable)

    @Query("DELETE FROM deliverables WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT COUNT(*) FROM deliverables")
    suspend fun getCount(): Int
}
