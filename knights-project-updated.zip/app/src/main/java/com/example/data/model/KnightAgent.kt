package com.example.data.model

data class KnightAgent(
    val id: String,
    val name: String,
    val codename: String,
    val squadron: String, // "youtube", "universal", "custom"
    val description: String,
    val tools: List<String> = listOf("google_search", "local_ai_runtime", "save_to_library"),
    val outputKey: String,
    val instruction: String,
    val orderNumber: Int = 1,
    val badgeColorHex: String = "#A8C7FA",
    val internetEnabled: Boolean = true,
    val localModelId: String = "", // "" = Cloud Gemini, or installed local AI model ID
    val capabilities: List<String> = listOf(
        "Web Research",
        "Code & Systems",
        "YouTube & Media",
        "Strategy & Planning",
        "Data & Math"
    ),
    val lastTaskSummary: String = "Standing by for multi-domain tasks",
    val tasksCompletedCount: Int = 0
) {
    val isYouTube: Boolean get() = squadron.equals("youtube", ignoreCase = true)
    val isUniversal: Boolean get() = squadron.equals("universal", ignoreCase = true)
    val isCustom: Boolean get() = !isYouTube && !isUniversal
    val hasLocalAiBound: Boolean get() = localModelId.isNotBlank()
}

object DefaultKnightsOrder {
    val ALL_9_KNIGHTS = listOf(
        KnightAgent(
            id = "vanguard_trend_knight",
            name = "vanguard_trend_knight",
            codename = "Knight I • Vanguard",
            squadron = "youtube",
            description = "Autonomous web intelligence, breakout trend analysis, and multi-domain synthesis.",
            tools = listOf("google_search", "local_ai_runtime", "save_to_library"),
            outputKey = "research_brief",
            instruction = "You are Knight I (Vanguard). You are an unrestricted multi-purpose autonomous agent specializing in live internet intelligence, trend scouting, and deep synthesis across any topic.",
            orderNumber = 1,
            badgeColorHex = "#A8C7FA",
            internetEnabled = true
        ),
        KnightAgent(
            id = "oracle_seo_knight",
            name = "oracle_seo_knight",
            codename = "Knight II • Oracle",
            squadron = "youtube",
            description = "Strategic packaging, growth modeling, quantitative forecasting, and SEO architecture.",
            tools = listOf("google_search", "calculate_youtube_metrics", "local_ai_runtime"),
            outputKey = "seo_strategy",
            instruction = "You are Knight II (Oracle). You handle strategic positioning, growth analytics, forecasting, high-CTR packaging, and any analytical or creative task.",
            orderNumber = 2,
            badgeColorHex = "#C58AF9",
            internetEnabled = true
        ),
        KnightAgent(
            id = "bard_script_knight",
            name = "bard_script_knight",
            codename = "Knight III • Bard",
            squadron = "youtube",
            description = "Long-form narrative engineering, scripts, technical documentation, and copywriting.",
            tools = listOf("google_search", "local_ai_runtime", "save_to_library"),
            outputKey = "video_script",
            instruction = "You are Knight III (Bard). You craft high-retention narratives, scripts, executive essays, documentation, and persuasive communications across any domain.",
            orderNumber = 3,
            badgeColorHex = "#A8C7FA",
            internetEnabled = true
        ),
        KnightAgent(
            id = "artificer_visual_knight",
            name = "artificer_visual_knight",
            codename = "Knight IV • Artificer",
            squadron = "youtube",
            description = "Design systems, UI/UX blueprints, visual storyboards, and generative prompt engineering.",
            tools = listOf("google_search", "local_ai_runtime"),
            outputKey = "visual_storyboard",
            instruction = "You are Knight IV (Artificer). You architect UI/UX design systems, scene storyboards, multimodal prompts, and creative direction for any project.",
            orderNumber = 4,
            badgeColorHex = "#81C995",
            internetEnabled = true
        ),
        KnightAgent(
            id = "marshal_production_knight",
            name = "marshal_production_knight",
            codename = "Knight V • Marshal",
            squadron = "youtube",
            description = "End-to-end release orchestration, workflow automation, and master deliverable compilation.",
            tools = listOf("google_search", "save_to_library", "local_ai_runtime"),
            outputKey = "production_package",
            instruction = "You are Knight V (Marshal). You orchestrate end-to-end production pipelines, synthesis, launch checklists, and multi-agent task coordination.",
            orderNumber = 5,
            badgeColorHex = "#A8C7FA",
            internetEnabled = true
        ),
        KnightAgent(
            id = "strategos_planner_knight",
            name = "strategos_planner_knight",
            codename = "Knight VI • Strategos",
            squadron = "universal",
            description = "Complex system decomposition, milestone roadmaps, and autonomous decision trees.",
            tools = listOf("google_search", "local_ai_runtime"),
            outputKey = "universal_task_plan",
            instruction = "You are Knight VI (Strategos). Decompose any complex goal—software, business, research, or operations—into actionable execution phases and architecture.",
            orderNumber = 6,
            badgeColorHex = "#C58AF9",
            internetEnabled = true
        ),
        KnightAgent(
            id = "scholar_research_knight",
            name = "scholar_research_knight",
            codename = "Knight VII • Scholar",
            squadron = "universal",
            description = "Live internet grounding, academic & technical verification, and deep web dossier creation.",
            tools = listOf("google_search", "local_ai_runtime", "save_to_library"),
            outputKey = "universal_research_findings",
            instruction = "You are Knight VII (Scholar). Connect to live web sources, verify technical documentation, benchmark data, and produce grounded research reports.",
            orderNumber = 7,
            badgeColorHex = "#81C995",
            internetEnabled = true
        ),
        KnightAgent(
            id = "forgemaster_code_knight",
            name = "forgemaster_code_knight",
            codename = "Knight VIII • Forgemaster",
            squadron = "universal",
            description = "Full-stack software engineering, APIs, database schemas, and quantitative algorithms.",
            tools = listOf("google_search", "local_ai_runtime", "save_to_library"),
            outputKey = "engineered_solution",
            instruction = "You are Knight VIII (Forgemaster). Write clean, production-grade code, architectures, database schemas, and automated tests in any language.",
            orderNumber = 8,
            badgeColorHex = "#FDD663",
            internetEnabled = true
        ),
        KnightAgent(
            id = "sentinel_critic_knight",
            name = "sentinel_critic_knight",
            codename = "Knight IX • Sentinel",
            squadron = "universal",
            description = "Security auditing, adversarial stress-testing, code review, and executive refinement.",
            tools = listOf("google_search", "save_to_library", "local_ai_runtime"),
            outputKey = "final_deliverable",
            instruction = "You are Knight IX (Sentinel). Perform deep security audits, logic verification, performance optimization, and polish deliverables to perfection.",
            orderNumber = 9,
            badgeColorHex = "#81C995",
            internetEnabled = true
        )
    )
}
