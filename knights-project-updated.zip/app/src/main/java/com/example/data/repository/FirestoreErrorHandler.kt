package com.example.data.repository

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import org.json.JSONArray
import org.json.JSONObject

enum class OperationType {
    CREATE, UPDATE, DELETE, LIST, GET, WRITE
}

fun handleFirestoreError(
    error: Exception,
    operationType: OperationType,
    path: String?
) {
    val auth = try {
        Firebase.auth
    } catch (e: Exception) {
        null
    }
    val currentUser = auth?.currentUser

    val providerInfo = JSONArray().apply {
        currentUser?.providerData?.forEach { profile ->
            put(
                JSONObject().apply {
                    put("providerId", profile.providerId)
                    put("displayName", profile.displayName)
                    put("email", profile.email)
                    put("photoUrl", profile.photoUrl?.toString())
                }
            )
        }
    }

    val errInfo = JSONObject().apply {
        put("error", error.message ?: error.toString())
        put("operationType", operationType.name.lowercase())
        put("path", path)
        put(
            "authInfo",
            JSONObject().apply {
                put("userId", currentUser?.uid)
                put("email", currentUser?.email)
                put("emailVerified", currentUser?.isEmailVerified)
                put("isAnonymous", currentUser?.isAnonymous)
                put("tenantId", currentUser?.tenantId)
                put("providerInfo", providerInfo)
            }
        )
    }

    val jsonString = errInfo.toString()
    Log.e("FirestoreError", jsonString, error)
    throw RuntimeException(jsonString, error)
}
