package com.example.data.model

data class YouTubeFunnelParams(
    val views: Long = 150_000L,
    val rpmUsd: Double = 9.50,
    val ctrPercent: Double = 7.2,
    val avgViewDurationMins: Double = 5.8
) {
    val estimatedAdRevenueUsd: Double
        get() = (views / 1000.0) * rpmUsd

    val projectedWatchTimeHours: Double
        get() = (views * avgViewDurationMins) / 60.0

    val requiredImpressions: Long
        get() = if (ctrPercent > 0.0) (views / (ctrPercent / 100.0)).toLong() else 0L

    val isMonetizationEligible: Boolean
        get() = projectedWatchTimeHours >= 4000.0
}
