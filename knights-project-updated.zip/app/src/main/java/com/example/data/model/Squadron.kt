package com.example.data.model

enum class SquadronType(
    val id: String,
    val title: String,
    val subtitle: String,
    val icon: String,
    val stages: List<List<String>>
) {
    GRAND_COMMANDER(
        id = "auto",
        title = "Grand Commander",
        subtitle = "Auto-routes to the best Squadron or single Knight",
        icon = "✨",
        stages = emptyList() // Evaluated dynamically based on prompt
    ),
    YOUTUBE_PIPELINE(
        id = "youtube_pipeline",
        title = "YouTube Squadron",
        subtitle = "5 Knights: Trend + SEO → Script → Visuals → Production",
        icon = "🎬",
        stages = listOf(
            listOf("vanguard_trend_knight", "oracle_seo_knight"),
            listOf("bard_script_knight"),
            listOf("artificer_visual_knight"),
            listOf("marshal_production_knight")
        )
    ),
    UNIVERSAL_PIPELINE(
        id = "universal_pipeline",
        title = "Universal Squadron",
        subtitle = "4 Knights: Plan + Research → Code → Audit",
        icon = "🧠",
        stages = listOf(
            listOf("strategos_planner_knight", "scholar_research_knight"),
            listOf("forgemaster_code_knight"),
            listOf("sentinel_critic_knight")
        )
    ),
    GRAND_ORDER(
        id = "grand_order",
        title = "All 9 Knights Order",
        subtitle = "Full 9-Agent sequential & parallel sweep",
        icon = "⚔️",
        stages = listOf(
            listOf("strategos_planner_knight", "scholar_research_knight", "vanguard_trend_knight"),
            listOf("forgemaster_code_knight", "oracle_seo_knight"),
            listOf("bard_script_knight", "artificer_visual_knight"),
            listOf("sentinel_critic_knight", "marshal_production_knight")
        )
    ),
    SOLO_KNIGHT(
        id = "solo",
        title = "Solo Knight",
        subtitle = "Deploy an individual specialist Knight directly",
        icon = "👤",
        stages = emptyList()
    );

    companion object {
        fun fromId(id: String): SquadronType {
            return entries.find { it.id == id } ?: GRAND_COMMANDER
        }
    }
}
