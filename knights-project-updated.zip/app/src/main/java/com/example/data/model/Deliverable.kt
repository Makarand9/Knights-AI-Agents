package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Entity(tableName = "deliverables")
data class Deliverable(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val title: String,
    val authorKnight: String,
    val category: String, // "youtube", "universal", "system"
    val content: String,
    val timestampMs: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false
) {
    val formattedDate: String
        get() {
            val sdf = SimpleDateFormat("MMM dd, yyyy • HH:mm", Locale.getDefault())
            return sdf.format(Date(timestampMs))
        }

    val previewText: String
        get() {
            val cleaned = content.replace("#", "").trim()
            return if (cleaned.length > 140) cleaned.substring(0, 140) + "..." else cleaned
        }
}
