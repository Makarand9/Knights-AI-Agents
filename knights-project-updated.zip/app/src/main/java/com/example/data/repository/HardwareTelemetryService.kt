package com.example.data.repository

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import com.example.data.model.DeviceHardwareInfo
import java.util.Locale

class HardwareTelemetryService(private val context: Context) {

    fun getDeviceHardwareInfo(): DeviceHardwareInfo {
        val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        actManager?.getMemoryInfo(memInfo)

        val totalBytes = memInfo.totalMem
        val availBytes = memInfo.availMem
        // Check if device satisfies 6.0 GB RAM requirement (~5.0 GB reported RAM threshold)
        val isSufficient = totalBytes >= 5_000_000_000L

        val totalGb = totalBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
        val availGb = availBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)

        val totalGbFormatted = String.format(Locale.US, "%.1f GB", totalGb)
        val availGbFormatted = String.format(Locale.US, "%.1f GB", availGb)
        val cores = Runtime.getRuntime().availableProcessors()
        val model = "${Build.MANUFACTURER} ${Build.MODEL}".trim()
        val androidVer = Build.VERSION.RELEASE ?: "Unknown"

        return DeviceHardwareInfo(
            totalRamBytes = totalBytes,
            availableRamBytes = availBytes,
            isRamSufficient = isSufficient,
            totalRamGbFormatted = totalGbFormatted,
            availableRamGbFormatted = availGbFormatted,
            cpuCores = cores,
            deviceModel = model,
            androidVersion = androidVer
        )
    }
}
