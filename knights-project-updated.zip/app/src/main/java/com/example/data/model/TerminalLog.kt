package com.example.data.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class LogLevel(val tag: String, val badgeColorHex: String) {
    SYS("[SYS]", "#818CF8"),
    INFO("[INF]", "#38BDF8"),
    EXEC("[RUN]", "#C084FC"),
    TOOL("[TOOL]", "#FBBF24"),
    SUCCESS("[DONE]", "#34D399"),
    WARN("[WARN]", "#FB923C"),
    ERROR("[ERR]", "#F87171")
}

data class TerminalLog(
    val id: String = java.util.UUID.randomUUID().toString(),
    val timestampMs: Long = System.currentTimeMillis(),
    val level: LogLevel,
    val agentName: String? = null,
    val message: String,
    val details: String? = null,
    val latencyMs: Long? = null
) {
    val formattedTime: String
        get() {
            val sdf = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
            return sdf.format(Date(timestampMs))
        }
}

enum class TerminalMode {
    CLI_STREAM,
    PIPELINE_DAG,
    DELIVERABLE_PREVIEW
}

data class KnightExecutionState(
    val knightId: String,
    val codename: String,
    val status: AgentStatus = AgentStatus.QUEUED,
    val output: String = "",
    val activeTool: String? = null,
    val durationMs: Long = 0L
)

enum class AgentStatus {
    QUEUED,
    EXECUTING,
    COMPLETED,
    FAILED
}
