const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write memories or tasks", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("memories").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("tasks").get());
});

test("Authenticated user can create and query their own memories and tasks, but Bob is blocked", async () => {
  const now = new Date();
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  const memRef = aliceDb.collection("users").doc(ALICE_UID).collection("memories").doc("mem_1");
  await assertSucceeds(
    memRef.set({
      userId: ALICE_UID,
      content: "Always write idiomatic Kotlin with Jetpack Compose",
      category: "preference",
      enabled: true,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Alice can read and list her own memories
  await assertSucceeds(memRef.get());
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("memories").where("userId", "==", ALICE_UID).get()
  );

  // Bob cannot read or list Alice's memories
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("memories").doc("mem_1").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("memories").get());
});

test("Shadow update with ghost field is rejected", async () => {
  const now = new Date();
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const taskRef = aliceDb.collection("users").doc(ALICE_UID).collection("tasks").doc("task_1");

  await assertFails(
    taskRef.set({
      userId: ALICE_UID,
      agentId: "vanguard_trend_knight",
      agentCodename: "Knight I • Vanguard Scout",
      prompt: "Analyze AI trends",
      status: "executing",
      output: "",
      usedInternet: true,
      executionEngine: "gemini-2.5-flash",
      isVerifiedGhostField: true,
      createdAt: now,
      updatedAt: now,
    })
  );
});
