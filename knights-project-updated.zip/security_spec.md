# Security Specification — Knights Gemini 9-Agent Order

## 1. Data Invariants
1. **Strict User Multi-Tenancy Isolation**: Every collection lives under `/users/{userId}/...` (`agents`, `memories`, `tasks`). Only an authenticated user whose `request.auth.uid == userId` may read, list, create, update, or delete documents in their own user namespace.
2. **Identity Integrity**: On `create` and `update`, `incoming().userId == request.auth.uid` and `request.auth.uid == userId`. On `update`, `incoming().userId == existing().userId` and `incoming().createdAt == existing().createdAt`.
3. **Path Variable Hardening**: Every document ID (`{userId}`, `{agentId}`, `{memoryId}`, `{taskId}`) is validated with `isValidId(id)` (`id is string && id.size() <= 128 && id.matches('^[a-zA-Z0-9_\\-]+$')`) on single-document operations (`get`, `create`, `update`, `delete`).
4. **Strict Key Allowlisting & Schema Bounds**: Every `create` and `update` call validates exact allowed keys via `hasAll` / `hasOnly` / `affectedKeys().hasOnly` and calls `isValidAgentConfig(incoming())`, `isValidMemoryItem(incoming())`, or `isValidAgentTask(incoming())`.
5. **Temporal Integrity**: `createdAt` and `updatedAt` must be Firestore `timestamp` (`<= request.time`).

## 2. The "Dirty Dozen" Adversarial Payloads
1. **Unauthenticated Read/Write**: Caller with `request.auth == null` attempts `get` or `list` on `/users/alice_123/tasks`. -> Rejected (`isSignedIn()` fails).
2. **Cross-User Read (`Bob` reads `Alice`)**: Authenticated `bob_456` attempts `get` or `list` on `/users/alice_123/memories`. -> Rejected (`request.auth.uid == userId` fails).
3. **Identity Spoofing on Create**: `alice_123` writes to `/users/alice_123/tasks/t1` with `{"userId": "bob_456"}`. -> Rejected (`incoming().userId == request.auth.uid` fails).
4. **Shadow Field Injection ("Ghost Field")**: `alice_123` creates or updates a memory item with `{"isAdmin": true}`. -> Rejected (`keys().hasOnly(...)` / `affectedKeys().hasOnly(...)` fails).
5. **Immutable `createdAt` Tampering**: `alice_123` updates an existing task with a modified `createdAt` timestamp. -> Rejected (`incoming().createdAt == existing().createdAt` fails).
6. **Immutable `userId` Reassignment**: `alice_123` updates `userId` on an existing agent config. -> Rejected (`incoming().userId == existing().userId` fails).
7. **Oversized String DoS ("Denial of Wallet")**: `alice_123` submits a 50KB `content` string into `memories`. -> Rejected (`data.content.size() <= 1000` fails).
8. **Type Poisoning**: `alice_123` submits an integer `12345` for `prompt` or string `"true"` for `internetEnabled`. -> Rejected (`isValidAgentTask` / `isValidAgentConfig` fails).
9. **Invalid Status Enum**: `alice_123` sets task `status` to `"hacked_state"`. -> Rejected (`data.status in ['queued', 'executing', 'completed', 'failed']` fails).
10. **Future Timestamp Spoofing**: Client sets `createdAt` to year 2099. -> Rejected (`incoming().createdAt <= request.time` fails).
11. **Malformed Document ID Poisoning**: Document ID contains spaces or special characters. -> Rejected (`isValidId` fails).
12. **Required Field Deletion via Update**: `alice_123` attempts `FieldValue.delete()` on `codename` or `content`. -> Rejected (`isValid*` checks projected post-write document state).
